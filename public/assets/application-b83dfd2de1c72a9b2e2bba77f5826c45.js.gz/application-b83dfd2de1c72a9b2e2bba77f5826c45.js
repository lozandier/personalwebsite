/*!
 * imagesLoaded PACKAGED v3.0.4
 * JavaScript is all like "You images are done yet or what?"
 */


(function(){"use strict";function e(){}function t(e,t){for(var n=e.length;n--;)if(e[n].listener===t)return n;return-1}var n=e.prototype;n.getListeners=function(e){var t,n,i=this._getEvents();if("object"==typeof e){t={};for(n in i)i.hasOwnProperty(n)&&e.test(n)&&(t[n]=i[n])}else t=i[e]||(i[e]=[]);return t},n.flattenListeners=function(e){var t,n=[];for(t=0;e.length>t;t+=1)n.push(e[t].listener);return n},n.getListenersAsObject=function(e){var t,n=this.getListeners(e);return n instanceof Array&&(t={},t[e]=n),t||n},n.addListener=function(e,n){var i,r=this.getListenersAsObject(e),o="object"==typeof n;for(i in r)r.hasOwnProperty(i)&&-1===t(r[i],n)&&r[i].push(o?n:{listener:n,once:!1});return this},n.on=n.addListener,n.addOnceListener=function(e,t){return this.addListener(e,{listener:t,once:!0})},n.once=n.addOnceListener,n.defineEvent=function(e){return this.getListeners(e),this},n.defineEvents=function(e){for(var t=0;e.length>t;t+=1)this.defineEvent(e[t]);return this},n.removeListener=function(e,n){var i,r,o=this.getListenersAsObject(e);for(r in o)o.hasOwnProperty(r)&&(i=t(o[r],n),-1!==i&&o[r].splice(i,1));return this},n.off=n.removeListener,n.addListeners=function(e,t){return this.manipulateListeners(!1,e,t)},n.removeListeners=function(e,t){return this.manipulateListeners(!0,e,t)},n.manipulateListeners=function(e,t,n){var i,r,o=e?this.removeListener:this.addListener,s=e?this.removeListeners:this.addListeners;if("object"!=typeof t||t instanceof RegExp)for(i=n.length;i--;)o.call(this,t,n[i]);else for(i in t)t.hasOwnProperty(i)&&(r=t[i])&&("function"==typeof r?o.call(this,i,r):s.call(this,i,r));return this},n.removeEvent=function(e){var t,n=typeof e,i=this._getEvents();if("string"===n)delete i[e];else if("object"===n)for(t in i)i.hasOwnProperty(t)&&e.test(t)&&delete i[t];else delete this._events;return this},n.emitEvent=function(e,t){var n,i,r,o,s=this.getListenersAsObject(e);for(r in s)if(s.hasOwnProperty(r))for(i=s[r].length;i--;)n=s[r][i],o=n.listener.apply(this,t||[]),(o===this._getOnceReturnValue()||n.once===!0)&&this.removeListener(e,s[r][i].listener);return this},n.trigger=n.emitEvent,n.emit=function(e){var t=Array.prototype.slice.call(arguments,1);return this.emitEvent(e,t)},n.setOnceReturnValue=function(e){return this._onceReturnValue=e,this},n._getOnceReturnValue=function(){return this.hasOwnProperty("_onceReturnValue")?this._onceReturnValue:!0},n._getEvents=function(){return this._events||(this._events={})},"function"==typeof define&&define.amd?define(function(){return e}):"undefined"!=typeof module&&module.exports?module.exports=e:this.EventEmitter=e}).call(this),function(e){"use strict";var t=document.documentElement,n=function(){};t.addEventListener?n=function(e,t,n){e.addEventListener(t,n,!1)}:t.attachEvent&&(n=function(t,n,i){t[n+i]=i.handleEvent?function(){var t=e.event;t.target=t.target||t.srcElement,i.handleEvent.call(i,t)}:function(){var n=e.event;n.target=n.target||n.srcElement,i.call(t,n)},t.attachEvent("on"+n,t[n+i])});var i=function(){};t.removeEventListener?i=function(e,t,n){e.removeEventListener(t,n,!1)}:t.detachEvent&&(i=function(e,t,n){e.detachEvent("on"+t,e[t+n]);try{delete e[t+n]}catch(i){e[t+n]=void 0}});var r={bind:n,unbind:i};"function"==typeof define&&define.amd?define(r):e.eventie=r}(this),function(e){"use strict";function t(e,t){for(var n in t)e[n]=t[n];return e}function n(e){return"[object Array]"===c.call(e)}function i(e){var t=[];if(n(e))t=e;else if("number"==typeof e.length)for(var i=0,r=e.length;r>i;i++)t.push(e[i]);else t.push(e);return t}function r(e,n){function r(e,n,s){if(!(this instanceof r))return new r(e,n);"string"==typeof e&&(e=document.querySelectorAll(e)),this.elements=i(e),this.options=t({},this.options),"function"==typeof n?s=n:t(this.options,n),s&&this.on("always",s),this.getImages(),o&&(this.jqDeferred=new o.Deferred);var a=this;setTimeout(function(){a.check()})}function c(e){this.img=e}r.prototype=new e,r.prototype.options={},r.prototype.getImages=function(){this.images=[];for(var e=0,t=this.elements.length;t>e;e++){var n=this.elements[e];"IMG"===n.nodeName&&this.addImage(n);for(var i=n.querySelectorAll("img"),r=0,o=i.length;o>r;r++){var s=i[r];this.addImage(s)}}},r.prototype.addImage=function(e){var t=new c(e);this.images.push(t)},r.prototype.check=function(){function e(e,r){return t.options.debug&&a&&s.log("confirm",e,r),t.progress(e),n++,n===i&&t.complete(),!0}var t=this,n=0,i=this.images.length;if(this.hasAnyBroken=!1,!i)return this.complete(),void 0;for(var r=0;i>r;r++){var o=this.images[r];o.on("confirm",e),o.check()}},r.prototype.progress=function(e){this.hasAnyBroken=this.hasAnyBroken||!e.isLoaded;var t=this;setTimeout(function(){t.emit("progress",t,e),t.jqDeferred&&t.jqDeferred.notify(t,e)})},r.prototype.complete=function(){var e=this.hasAnyBroken?"fail":"done";this.isComplete=!0;var t=this;setTimeout(function(){if(t.emit(e,t),t.emit("always",t),t.jqDeferred){var n=t.hasAnyBroken?"reject":"resolve";t.jqDeferred[n](t)}})},o&&(o.fn.imagesLoaded=function(e,t){var n=new r(this,e,t);return n.jqDeferred.promise(o(this))});var f={};return c.prototype=new e,c.prototype.check=function(){var e=f[this.img.src];if(e)return this.useCached(e),void 0;if(f[this.img.src]=this,this.img.complete&&void 0!==this.img.naturalWidth)return this.confirm(0!==this.img.naturalWidth,"naturalWidth"),void 0;var t=this.proxyImage=new Image;n.bind(t,"load",this),n.bind(t,"error",this),t.src=this.img.src},c.prototype.useCached=function(e){if(e.isConfirmed)this.confirm(e.isLoaded,"cached was confirmed");else{var t=this;e.on("confirm",function(e){return t.confirm(e.isLoaded,"cache emitted confirmed"),!0})}},c.prototype.confirm=function(e,t){this.isConfirmed=!0,this.isLoaded=e,this.emit("confirm",this,t)},c.prototype.handleEvent=function(e){var t="on"+e.type;this[t]&&this[t](e)},c.prototype.onload=function(){this.confirm(!0,"onload"),this.unbindProxyEvents()},c.prototype.onerror=function(){this.confirm(!1,"onerror"),this.unbindProxyEvents()},c.prototype.unbindProxyEvents=function(){n.unbind(this.proxyImage,"load",this),n.unbind(this.proxyImage,"error",this)},r}var o=e.jQuery,s=e.console,a=s!==void 0,c=Object.prototype.toString;"function"==typeof define&&define.amd?define(["eventEmitter/EventEmitter","eventie/eventie"],r):e.imagesLoaded=r(e.EventEmitter,e.eventie)}(window);
/*!
 * Masonry PACKAGED v3.1.2
 * Cascading grid layout library
 * http://masonry.desandro.com
 * MIT License
 * by David DeSandro
 */


(function(t){"use strict";function e(t){if(t){if("string"==typeof n[t])return t;t=t.charAt(0).toUpperCase()+t.slice(1);for(var e,o=0,r=i.length;r>o;o++)if(e=i[o]+t,"string"==typeof n[e])return e}}var i="Webkit Moz ms Ms O".split(" "),n=document.documentElement.style;"function"==typeof define&&define.amd?define(function(){return e}):t.getStyleProperty=e})(window),function(t){"use strict";function e(t){var e=parseFloat(t),i=-1===t.indexOf("%")&&!isNaN(e);return i&&e}function i(){for(var t={width:0,height:0,innerWidth:0,innerHeight:0,outerWidth:0,outerHeight:0},e=0,i=s.length;i>e;e++){var n=s[e];t[n]=0}return t}function n(t){function n(t){if("string"==typeof t&&(t=document.querySelector(t)),t&&"object"==typeof t&&t.nodeType){var n=r(t);if("none"===n.display)return i();var h={};h.width=t.offsetWidth,h.height=t.offsetHeight;for(var p=h.isBorderBox=!(!a||!n[a]||"border-box"!==n[a]),u=0,f=s.length;f>u;u++){var c=s[u],d=n[c],l=parseFloat(d);h[c]=isNaN(l)?0:l}var m=h.paddingLeft+h.paddingRight,y=h.paddingTop+h.paddingBottom,g=h.marginLeft+h.marginRight,v=h.marginTop+h.marginBottom,_=h.borderLeftWidth+h.borderRightWidth,b=h.borderTopWidth+h.borderBottomWidth,E=p&&o,L=e(n.width);L!==!1&&(h.width=L+(E?0:m+_));var T=e(n.height);return T!==!1&&(h.height=T+(E?0:y+b)),h.innerWidth=h.width-(m+_),h.innerHeight=h.height-(y+b),h.outerWidth=h.width+g,h.outerHeight=h.height+v,h}}var o,a=t("boxSizing");return function(){if(a){var t=document.createElement("div");t.style.width="200px",t.style.padding="1px 2px 3px 4px",t.style.borderStyle="solid",t.style.borderWidth="1px 2px 3px 4px",t.style[a]="border-box";var i=document.body||document.documentElement;i.appendChild(t);var n=r(t);o=200===e(n.width),i.removeChild(t)}}(),n}var o=document.defaultView,r=o&&o.getComputedStyle?function(t){return o.getComputedStyle(t,null)}:function(t){return t.currentStyle},s=["paddingLeft","paddingRight","paddingTop","paddingBottom","marginLeft","marginRight","marginTop","marginBottom","borderLeftWidth","borderRightWidth","borderTopWidth","borderBottomWidth"];"function"==typeof define&&define.amd?define(["get-style-property/get-style-property"],n):t.getSize=n(t.getStyleProperty)}(window),function(t){"use strict";var e=document.documentElement,i=function(){};e.addEventListener?i=function(t,e,i){t.addEventListener(e,i,!1)}:e.attachEvent&&(i=function(e,i,n){e[i+n]=n.handleEvent?function(){var e=t.event;e.target=e.target||e.srcElement,n.handleEvent.call(n,e)}:function(){var i=t.event;i.target=i.target||i.srcElement,n.call(e,i)},e.attachEvent("on"+i,e[i+n])});var n=function(){};e.removeEventListener?n=function(t,e,i){t.removeEventListener(e,i,!1)}:e.detachEvent&&(n=function(t,e,i){t.detachEvent("on"+e,t[e+i]);try{delete t[e+i]}catch(n){t[e+i]=void 0}});var o={bind:i,unbind:n};"function"==typeof define&&define.amd?define(o):t.eventie=o}(this),function(t){"use strict";function e(t){"function"==typeof t&&(e.isReady?t():r.push(t))}function i(t){var i="readystatechange"===t.type&&"complete"!==o.readyState;if(!e.isReady&&!i){e.isReady=!0;for(var n=0,s=r.length;s>n;n++){var a=r[n];a()}}}function n(n){return n.bind(o,"DOMContentLoaded",i),n.bind(o,"readystatechange",i),n.bind(t,"load",i),e}var o=t.document,r=[];e.isReady=!1,"function"==typeof define&&define.amd?(e.isReady="function"==typeof requirejs,define(["eventie/eventie"],n)):t.docReady=n(t.eventie)}(this),function(){"use strict";function t(){}function e(t,e){for(var i=t.length;i--;)if(t[i].listener===e)return i;return-1}function i(t){return function(){return this[t].apply(this,arguments)}}var n=t.prototype;n.getListeners=function(t){var e,i,n=this._getEvents();if("object"==typeof t){e={};for(i in n)n.hasOwnProperty(i)&&t.test(i)&&(e[i]=n[i])}else e=n[t]||(n[t]=[]);return e},n.flattenListeners=function(t){var e,i=[];for(e=0;t.length>e;e+=1)i.push(t[e].listener);return i},n.getListenersAsObject=function(t){var e,i=this.getListeners(t);return i instanceof Array&&(e={},e[t]=i),e||i},n.addListener=function(t,i){var n,o=this.getListenersAsObject(t),r="object"==typeof i;for(n in o)o.hasOwnProperty(n)&&-1===e(o[n],i)&&o[n].push(r?i:{listener:i,once:!1});return this},n.on=i("addListener"),n.addOnceListener=function(t,e){return this.addListener(t,{listener:e,once:!0})},n.once=i("addOnceListener"),n.defineEvent=function(t){return this.getListeners(t),this},n.defineEvents=function(t){for(var e=0;t.length>e;e+=1)this.defineEvent(t[e]);return this},n.removeListener=function(t,i){var n,o,r=this.getListenersAsObject(t);for(o in r)r.hasOwnProperty(o)&&(n=e(r[o],i),-1!==n&&r[o].splice(n,1));return this},n.off=i("removeListener"),n.addListeners=function(t,e){return this.manipulateListeners(!1,t,e)},n.removeListeners=function(t,e){return this.manipulateListeners(!0,t,e)},n.manipulateListeners=function(t,e,i){var n,o,r=t?this.removeListener:this.addListener,s=t?this.removeListeners:this.addListeners;if("object"!=typeof e||e instanceof RegExp)for(n=i.length;n--;)r.call(this,e,i[n]);else for(n in e)e.hasOwnProperty(n)&&(o=e[n])&&("function"==typeof o?r.call(this,n,o):s.call(this,n,o));return this},n.removeEvent=function(t){var e,i=typeof t,n=this._getEvents();if("string"===i)delete n[t];else if("object"===i)for(e in n)n.hasOwnProperty(e)&&t.test(e)&&delete n[e];else delete this._events;return this},n.removeAllListeners=i("removeEvent"),n.emitEvent=function(t,e){var i,n,o,r,s=this.getListenersAsObject(t);for(o in s)if(s.hasOwnProperty(o))for(n=s[o].length;n--;)i=s[o][n],i.once===!0&&this.removeListener(t,i.listener),r=i.listener.apply(this,e||[]),r===this._getOnceReturnValue()&&this.removeListener(t,i.listener);return this},n.trigger=i("emitEvent"),n.emit=function(t){var e=Array.prototype.slice.call(arguments,1);return this.emitEvent(t,e)},n.setOnceReturnValue=function(t){return this._onceReturnValue=t,this},n._getOnceReturnValue=function(){return this.hasOwnProperty("_onceReturnValue")?this._onceReturnValue:!0},n._getEvents=function(){return this._events||(this._events={})},"function"==typeof define&&define.amd?define(function(){return t}):"object"==typeof module&&module.exports?module.exports=t:this.EventEmitter=t}.call(this),function(t){"use strict";function e(){}function i(t){function i(e){e.prototype.option||(e.prototype.option=function(e){t.isPlainObject(e)&&(this.options=t.extend(!0,this.options,e))})}function o(e,i){t.fn[e]=function(o){if("string"==typeof o){for(var s=n.call(arguments,1),a=0,h=this.length;h>a;a++){var p=this[a],u=t.data(p,e);if(u)if(t.isFunction(u[o])&&"_"!==o.charAt(0)){var f=u[o].apply(u,s);if(void 0!==f)return f}else r("no such method '"+o+"' for "+e+" instance");else r("cannot call methods on "+e+" prior to initialization; "+"attempted to call '"+o+"'")}return this}return this.each(function(){var n=t.data(this,e);n?(n.option(o),n._init()):(n=new i(this,o),t.data(this,e,n))})}}if(t){var r="undefined"==typeof console?e:function(t){console.error(t)};t.bridget=function(t,e){i(e),o(t,e)}}}var n=Array.prototype.slice;"function"==typeof define&&define.amd?define(["jquery"],i):i(t.jQuery)}(window),function(t,e){"use strict";function i(t,e){return t[a](e)}function n(t){if(!t.parentNode){var e=document.createDocumentFragment();e.appendChild(t)}}function o(t,e){n(t);for(var i=t.parentNode.querySelectorAll(e),o=0,r=i.length;r>o;o++)if(i[o]===t)return!0;return!1}function r(t,e){return n(t),i(t,e)}var s,a=function(){if(e.matchesSelector)return"matchesSelector";for(var t=["webkit","moz","ms","o"],i=0,n=t.length;n>i;i++){var o=t[i],r=o+"MatchesSelector";if(e[r])return r}}();if(a){var h=document.createElement("div"),p=i(h,"div");s=p?i:r}else s=o;"function"==typeof define&&define.amd?define(function(){return s}):window.matchesSelector=s}(this,Element.prototype),function(t){"use strict";function e(t,e){for(var i in e)t[i]=e[i];return t}function i(t){for(var e in t)return!1;return e=null,!0}function n(t){return t.replace(/([A-Z])/g,function(t){return"-"+t.toLowerCase()})}function o(t,o,r){function a(t,e){t&&(this.element=t,this.layout=e,this.position={x:0,y:0},this._create())}var h=r("transition"),p=r("transform"),u=h&&p,f=!!r("perspective"),c={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"otransitionend",transition:"transitionend"}[h],d=["transform","transition","transitionDuration","transitionProperty"],l=function(){for(var t={},e=0,i=d.length;i>e;e++){var n=d[e],o=r(n);o&&o!==n&&(t[n]=o)}return t}();e(a.prototype,t.prototype),a.prototype._create=function(){this._transition={ingProperties:{},clean:{},onEnd:{}},this.css({position:"absolute"})},a.prototype.handleEvent=function(t){var e="on"+t.type;this[e]&&this[e](t)},a.prototype.getSize=function(){this.size=o(this.element)},a.prototype.css=function(t){var e=this.element.style;for(var i in t){var n=l[i]||i;e[n]=t[i]}},a.prototype.getPosition=function(){var t=s(this.element),e=this.layout.options,i=e.isOriginLeft,n=e.isOriginTop,o=parseInt(t[i?"left":"right"],10),r=parseInt(t[n?"top":"bottom"],10);o=isNaN(o)?0:o,r=isNaN(r)?0:r;var a=this.layout.size;o-=i?a.paddingLeft:a.paddingRight,r-=n?a.paddingTop:a.paddingBottom,this.position.x=o,this.position.y=r},a.prototype.layoutPosition=function(){var t=this.layout.size,e=this.layout.options,i={};e.isOriginLeft?(i.left=this.position.x+t.paddingLeft+"px",i.right=""):(i.right=this.position.x+t.paddingRight+"px",i.left=""),e.isOriginTop?(i.top=this.position.y+t.paddingTop+"px",i.bottom=""):(i.bottom=this.position.y+t.paddingBottom+"px",i.top=""),this.css(i),this.emitEvent("layout",[this])};var m=f?function(t,e){return"translate3d("+t+"px, "+e+"px, 0)"}:function(t,e){return"translate("+t+"px, "+e+"px)"};a.prototype._transitionTo=function(t,e){this.getPosition();var i=this.position.x,n=this.position.y,o=parseInt(t,10),r=parseInt(e,10),s=o===this.position.x&&r===this.position.y;if(this.setPosition(t,e),s&&!this.isTransitioning)return this.layoutPosition(),void 0;var a=t-i,h=e-n,p={},u=this.layout.options;a=u.isOriginLeft?a:-a,h=u.isOriginTop?h:-h,p.transform=m(a,h),this.transition({to:p,onTransitionEnd:{transform:this.layoutPosition},isCleaning:!0})},a.prototype.goTo=function(t,e){this.setPosition(t,e),this.layoutPosition()},a.prototype.moveTo=u?a.prototype._transitionTo:a.prototype.goTo,a.prototype.setPosition=function(t,e){this.position.x=parseInt(t,10),this.position.y=parseInt(e,10)},a.prototype._nonTransition=function(t){this.css(t.to),t.isCleaning&&this._removeStyles(t.to);for(var e in t.onTransitionEnd)t.onTransitionEnd[e].call(this)},a.prototype._transition=function(t){if(!parseFloat(this.layout.options.transitionDuration))return this._nonTransition(t),void 0;var e=this._transition;for(var i in t.onTransitionEnd)e.onEnd[i]=t.onTransitionEnd[i];for(i in t.to)e.ingProperties[i]=!0,t.isCleaning&&(e.clean[i]=!0);if(t.from){this.css(t.from);var n=this.element.offsetHeight;n=null}this.enableTransition(t.to),this.css(t.to),this.isTransitioning=!0};var y=p&&n(p)+",opacity";a.prototype.enableTransition=function(){this.isTransitioning||(this.css({transitionProperty:y,transitionDuration:this.layout.options.transitionDuration}),this.element.addEventListener(c,this,!1))},a.prototype.transition=a.prototype[h?"_transition":"_nonTransition"],a.prototype.onwebkitTransitionEnd=function(t){this.ontransitionend(t)},a.prototype.onotransitionend=function(t){this.ontransitionend(t)};var g={"-webkit-transform":"transform","-moz-transform":"transform","-o-transform":"transform"};a.prototype.ontransitionend=function(t){if(t.target===this.element){var e=this._transition,n=g[t.propertyName]||t.propertyName;if(delete e.ingProperties[n],i(e.ingProperties)&&this.disableTransition(),n in e.clean&&(this.element.style[t.propertyName]="",delete e.clean[n]),n in e.onEnd){var o=e.onEnd[n];o.call(this),delete e.onEnd[n]}this.emitEvent("transitionEnd",[this])}},a.prototype.disableTransition=function(){this.removeTransitionStyles(),this.element.removeEventListener(c,this,!1),this.isTransitioning=!1},a.prototype._removeStyles=function(t){var e={};for(var i in t)e[i]="";this.css(e)};var v={transitionProperty:"",transitionDuration:""};return a.prototype.removeTransitionStyles=function(){this.css(v)},a.prototype.removeElem=function(){this.element.parentNode.removeChild(this.element),this.emitEvent("remove",[this])},a.prototype.remove=function(){if(!h||!parseFloat(this.layout.options.transitionDuration))return this.removeElem(),void 0;var t=this;this.on("transitionEnd",function(){return t.removeElem(),!0}),this.hide()},a.prototype.reveal=function(){delete this.isHidden,this.css({display:""});var t=this.layout.options;this.transition({from:t.hiddenStyle,to:t.visibleStyle,isCleaning:!0})},a.prototype.hide=function(){this.isHidden=!0,this.css({display:""});var t=this.layout.options;this.transition({from:t.visibleStyle,to:t.hiddenStyle,isCleaning:!0,onTransitionEnd:{opacity:function(){this.css({display:"none"})}}})},a.prototype.destroy=function(){this.css({position:"",left:"",right:"",top:"",bottom:"",transition:"",transform:""})},a}var r=document.defaultView,s=r&&r.getComputedStyle?function(t){return r.getComputedStyle(t,null)}:function(t){return t.currentStyle};"function"==typeof define&&define.amd?define(["eventEmitter/EventEmitter","get-size/get-size","get-style-property/get-style-property"],o):(t.Outlayer={},t.Outlayer.Item=o(t.EventEmitter,t.getSize,t.getStyleProperty))}(window),function(t){"use strict";function e(t,e){for(var i in e)t[i]=e[i];return t}function i(t){return"[object Array]"===f.call(t)}function n(t){var e=[];if(i(t))e=t;else if(t&&"number"==typeof t.length)for(var n=0,o=t.length;o>n;n++)e.push(t[n]);else e.push(t);return e}function o(t,e){var i=d(e,t);-1!==i&&e.splice(i,1)}function r(t){return t.replace(/(.)([A-Z])/g,function(t,e,i){return e+"-"+i}).toLowerCase()}function s(i,s,f,d,l,m){function y(t,i){if("string"==typeof t&&(t=a.querySelector(t)),!t||!c(t))return h&&h.error("Bad "+this.settings.namespace+" element: "+t),void 0;this.element=t,this.options=e({},this.options),this.option(i);var n=++v;this.element.outlayerGUID=n,_[n]=this,this._create(),this.options.isInitLayout&&this.layout()}function g(t,i){t.prototype[i]=e({},y.prototype[i])}var v=0,_={};return y.prototype.settings={namespace:"outlayer",item:m},y.prototype.options={containerStyle:{position:"relative"},isInitLayout:!0,isOriginLeft:!0,isOriginTop:!0,isResizeBound:!0,transitionDuration:"0.4s",hiddenStyle:{opacity:0,transform:"scale(0.001)"},visibleStyle:{opacity:1,transform:"scale(1)"}},e(y.prototype,f.prototype),y.prototype.option=function(t){e(this.options,t)},y.prototype._create=function(){this.reloadItems(),this.stamps=[],this.stamp(this.options.stamp),e(this.element.style,this.options.containerStyle),this.options.isResizeBound&&this.bindResize()},y.prototype.reloadItems=function(){this.items=this._itemize(this.element.children)},y.prototype._itemize=function(t){for(var e=this._filterFindItemElements(t),i=this.settings.item,n=[],o=0,r=e.length;r>o;o++){var s=e[o],a=new i(s,this);n.push(a)}return n},y.prototype._filterFindItemElements=function(t){t=n(t);for(var e=this.options.itemSelector,i=[],o=0,r=t.length;r>o;o++){var s=t[o];if(c(s))if(e){l(s,e)&&i.push(s);for(var a=s.querySelectorAll(e),h=0,p=a.length;p>h;h++)i.push(a[h])}else i.push(s)}return i},y.prototype.getItemElements=function(){for(var t=[],e=0,i=this.items.length;i>e;e++)t.push(this.items[e].element);return t},y.prototype.layout=function(){this._resetLayout(),this._manageStamps();var t=void 0!==this.options.isLayoutInstant?this.options.isLayoutInstant:!this._isLayoutInited;this.layoutItems(this.items,t),this._isLayoutInited=!0},y.prototype._init=y.prototype.layout,y.prototype._resetLayout=function(){this.getSize()},y.prototype.getSize=function(){this.size=d(this.element)},y.prototype._getMeasurement=function(t,e){var i,n=this.options[t];n?("string"==typeof n?i=this.element.querySelector(n):c(n)&&(i=n),this[t]=i?d(i)[e]:n):this[t]=0},y.prototype.layoutItems=function(t,e){t=this._getItemsForLayout(t),this._layoutItems(t,e),this._postLayout()},y.prototype._getItemsForLayout=function(t){for(var e=[],i=0,n=t.length;n>i;i++){var o=t[i];o.isIgnored||e.push(o)}return e},y.prototype._layoutItems=function(t,e){if(!t||!t.length)return this.emitEvent("layoutComplete",[this,t]),void 0;this._itemsOn(t,"layout",function(){this.emitEvent("layoutComplete",[this,t])});for(var i=[],n=0,o=t.length;o>n;n++){var r=t[n],s=this._getItemLayoutPosition(r);s.item=r,s.isInstant=e,i.push(s)}this._processLayoutQueue(i)},y.prototype._getItemLayoutPosition=function(){return{x:0,y:0}},y.prototype._processLayoutQueue=function(t){for(var e=0,i=t.length;i>e;e++){var n=t[e];this._positionItem(n.item,n.x,n.y,n.isInstant)}},y.prototype._positionItem=function(t,e,i,n){n?t.goTo(e,i):t.moveTo(e,i)},y.prototype._postLayout=function(){var t=this._getContainerSize();t&&(this._setContainerMeasure(t.width,!0),this._setContainerMeasure(t.height,!1))},y.prototype._getContainerSize=u,y.prototype._setContainerMeasure=function(t,e){if(void 0!==t){var i=this.size;i.isBorderBox&&(t+=e?i.paddingLeft+i.paddingRight+i.borderLeftWidth+i.borderRightWidth:i.paddingBottom+i.paddingTop+i.borderTopWidth+i.borderBottomWidth),t=Math.max(t,0),this.element.style[e?"width":"height"]=t+"px"}},y.prototype._itemsOn=function(t,e,i){function n(){return o++,o===r&&i.call(s),!0}for(var o=0,r=t.length,s=this,a=0,h=t.length;h>a;a++){var p=t[a];p.on(e,n)}},y.prototype.ignore=function(t){var e=this.getItem(t);e&&(e.isIgnored=!0)},y.prototype.unignore=function(t){var e=this.getItem(t);e&&delete e.isIgnored},y.prototype.stamp=function(t){if(t=this._find(t)){this.stamps=this.stamps.concat(t);for(var e=0,i=t.length;i>e;e++){var n=t[e];this.ignore(n)}}},y.prototype.unstamp=function(t){if(t=this._find(t))for(var e=0,i=t.length;i>e;e++){var n=t[e];o(n,this.stamps),this.unignore(n)}},y.prototype._find=function(t){return t?("string"==typeof t&&(t=this.element.querySelectorAll(t)),t=n(t)):void 0},y.prototype._manageStamps=function(){if(this.stamps&&this.stamps.length){this._getBoundingRect();for(var t=0,e=this.stamps.length;e>t;t++){var i=this.stamps[t];this._manageStamp(i)}}},y.prototype._getBoundingRect=function(){var t=this.element.getBoundingClientRect(),e=this.size;this._boundingRect={left:t.left+e.paddingLeft+e.borderLeftWidth,top:t.top+e.paddingTop+e.borderTopWidth,right:t.right-(e.paddingRight+e.borderRightWidth),bottom:t.bottom-(e.paddingBottom+e.borderBottomWidth)}},y.prototype._manageStamp=u,y.prototype._getElementOffset=function(t){var e=t.getBoundingClientRect(),i=this._boundingRect,n=d(t),o={left:e.left-i.left-n.marginLeft,top:e.top-i.top-n.marginTop,right:i.right-e.right-n.marginRight,bottom:i.bottom-e.bottom-n.marginBottom};return o},y.prototype.handleEvent=function(t){var e="on"+t.type;this[e]&&this[e](t)},y.prototype.bindResize=function(){this.isResizeBound||(i.bind(t,"resize",this),this.isResizeBound=!0)},y.prototype.unbindResize=function(){i.unbind(t,"resize",this),this.isResizeBound=!1},y.prototype.onresize=function(){function t(){e.resize(),delete e.resizeTimeout}this.resizeTimeout&&clearTimeout(this.resizeTimeout);var e=this;this.resizeTimeout=setTimeout(t,100)},y.prototype.resize=function(){var t=d(this.element),e=this.size&&t;e&&t.innerWidth===this.size.innerWidth||this.layout()},y.prototype.addItems=function(t){var e=this._itemize(t);return e.length&&(this.items=this.items.concat(e)),e},y.prototype.appended=function(t){var e=this.addItems(t);e.length&&(this.layoutItems(e,!0),this.reveal(e))},y.prototype.prepended=function(t){var e=this._itemize(t);if(e.length){var i=this.items.slice(0);this.items=e.concat(i),this._resetLayout(),this._manageStamps(),this.layoutItems(e,!0),this.reveal(e),this.layoutItems(i)}},y.prototype.reveal=function(t){if(t&&t.length)for(var e=0,i=t.length;i>e;e++){var n=t[e];n.reveal()}},y.prototype.hide=function(t){if(t&&t.length)for(var e=0,i=t.length;i>e;e++){var n=t[e];n.hide()}},y.prototype.getItem=function(t){for(var e=0,i=this.items.length;i>e;e++){var n=this.items[e];if(n.element===t)return n}},y.prototype.getItems=function(t){if(t&&t.length){for(var e=[],i=0,n=t.length;n>i;i++){var o=t[i],r=this.getItem(o);r&&e.push(r)}return e}},y.prototype.remove=function(t){t=n(t);var e=this.getItems(t);if(e&&e.length){this._itemsOn(e,"remove",function(){this.emitEvent("removeComplete",[this,e])});for(var i=0,r=e.length;r>i;i++){var s=e[i];s.remove(),o(s,this.items)}}},y.prototype.destroy=function(){var t=this.element.style;t.height="",t.position="",t.width="";for(var e=0,i=this.items.length;i>e;e++){var n=this.items[e];n.destroy()}this.unbindResize(),delete this.element.outlayerGUID,p&&p.removeData(this.element,this.settings.namespace)},y.data=function(t){var e=t&&t.outlayerGUID;return e&&_[e]},y.create=function(t,i){function n(){y.apply(this,arguments)}return e(n.prototype,y.prototype),g(n,"options"),g(n,"settings"),e(n.prototype.options,i),n.prototype.settings.namespace=t,n.data=y.data,n.Item=function(){m.apply(this,arguments)},n.Item.prototype=new m,n.prototype.settings.item=n.Item,s(function(){for(var e=r(t),i=a.querySelectorAll(".js-"+e),o="data-"+e+"-options",s=0,u=i.length;u>s;s++){var f,c=i[s],d=c.getAttribute(o);try{f=d&&JSON.parse(d)}catch(l){h&&h.error("Error parsing "+o+" on "+c.nodeName.toLowerCase()+(c.id?"#"+c.id:"")+": "+l);continue}var m=new n(c,f);p&&p.data(c,t,m)}}),p&&p.bridget&&p.bridget(t,n),n},y.Item=m,y}var a=t.document,h=t.console,p=t.jQuery,u=function(){},f=Object.prototype.toString,c="object"==typeof HTMLElement?function(t){return t instanceof HTMLElement}:function(t){return t&&"object"==typeof t&&1===t.nodeType&&"string"==typeof t.nodeName},d=Array.prototype.indexOf?function(t,e){return t.indexOf(e)}:function(t,e){for(var i=0,n=t.length;n>i;i++)if(t[i]===e)return i;return-1};"function"==typeof define&&define.amd?define(["eventie/eventie","doc-ready/doc-ready","eventEmitter/EventEmitter","get-size/get-size","matches-selector/matches-selector","./item"],s):t.Outlayer=s(t.eventie,t.docReady,t.EventEmitter,t.getSize,t.matchesSelector,t.Outlayer.Item)}(window),function(t){"use strict";function e(t,e){var n=t.create("masonry");return n.prototype._resetLayout=function(){this.getSize(),this._getMeasurement("columnWidth","outerWidth"),this._getMeasurement("gutter","outerWidth"),this.measureColumns();var t=this.cols;for(this.colYs=[];t--;)this.colYs.push(0);this.maxY=0},n.prototype.measureColumns=function(){if(this.getContainerWidth(),!this.columnWidth){var t=this.items[0],i=t&&t.element;this.columnWidth=i&&e(i).outerWidth||this.containerWidth}this.columnWidth+=this.gutter,this.cols=Math.floor((this.containerWidth+this.gutter)/this.columnWidth),this.cols=Math.max(this.cols,1)},n.prototype.getContainerWidth=function(){var t=this.options.isFitWidth?this.element.parentNode:this.element,i=e(t);this.containerWidth=i&&i.innerWidth},n.prototype._getItemLayoutPosition=function(t){t.getSize();var e=Math.ceil(t.size.outerWidth/this.columnWidth);e=Math.min(e,this.cols);for(var n=this._getColGroup(e),o=Math.min.apply(Math,n),r=i(n,o),s={x:this.columnWidth*r,y:o},a=o+t.size.outerHeight,h=this.cols+1-n.length,p=0;h>p;p++)this.colYs[r+p]=a;return s},n.prototype._getColGroup=function(t){if(2>t)return this.colYs;for(var e=[],i=this.cols+1-t,n=0;i>n;n++){var o=this.colYs.slice(n,n+t);e[n]=Math.max.apply(Math,o)}return e},n.prototype._manageStamp=function(t){var i=e(t),n=this._getElementOffset(t),o=this.options.isOriginLeft?n.left:n.right,r=o+i.outerWidth,s=Math.floor(o/this.columnWidth);s=Math.max(0,s);var a=Math.floor(r/this.columnWidth);a=Math.min(this.cols-1,a);for(var h=(this.options.isOriginTop?n.top:n.bottom)+i.outerHeight,p=s;a>=p;p++)this.colYs[p]=Math.max(h,this.colYs[p])},n.prototype._getContainerSize=function(){this.maxY=Math.max.apply(Math,this.colYs);var t={height:this.maxY};return this.options.isFitWidth&&(t.width=this._getContainerFitWidth()),t},n.prototype._getContainerFitWidth=function(){for(var t=0,e=this.cols;--e&&0===this.colYs[e];)t++;return(this.cols-t)*this.columnWidth-this.gutter},n.prototype.resize=function(){var t=this.containerWidth;this.getContainerWidth(),t!==this.containerWidth&&this.layout()},n}var i=Array.prototype.indexOf?function(t,e){return t.indexOf(e)}:function(t,e){for(var i=0,n=t.length;n>i;i++){var o=t[i];if(o===e)return i}return-1};"function"==typeof define&&define.amd?define(["outlayer/outlayer","get-size/get-size"],e):t.Masonry=e(t.Outlayer,t.getSize)}(window);
/*!
 * Fresco - A Beautiful Responsive Lightbox - v1.3.0
 * (c) 2012-2013 Nick Stakenburg
 *
 * http://www.frescojs.com
 *
 * License: http://www.frescojs.com/license
 */

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(G($){G 1e(i){H t={};1X(H e 4C i)t[e]=i[e]+"1e";P t}G 5k(){H i=x.2I();P i.L>i.K?"2Y":"3H"}G 6i(i){P 5l.7A.2B(5l,i.3t(","))}G 6j(){1X(H i="",t=6i("9A,97,9B,7B,9C,9D");!/^([a-5m-Z])+/.6k(i);)i=13[t]().9E(36).5n(2,5);P i}G 6i(i){P 5l.7A.2B(5l,i.3t(","))}G 5o(i){16.6l&&6l[6l.5o?"5o":"9F"](i)}G 6m(i,t){U(!26.7C)P t(!1,1),2C 0;H e={K:i.K,L:i.L},s={K:43,L:43},o=1,n=1;e.K>s.K&&(o=s.K/e.K),e.L>s.L&&(n=s.L/e.L);H a=13.2e(o,n);1>a&&(e.K*=a,e.L*=a);H h=1Y 6n,r=$("<4D>").2q(e)[0],d=r.6o("2d");d.9G=.8,d.9H(i,0,0,e.K,e.L),h.3I=G(){t(h,a)};5p{h.3k=r.6p("1p/7D")}5q(u){t(!1,1)}}G 5r(i,t){1X(H e 4C t)t[e]&&t[e].7E&&t[e].7E===9I?(i[e]=$.1f({},i[e])||{},5r(i[e],t[e])):i[e]=t[e];P i}G 3u(i,t){P 5r($.1f({},i),t)}G 44(){F.1A.2B(F,k.2k(1M))}G 6q(){F.1A.2B(F,k.2k(1M))}G 6r(){F.1A.2B(F,k.2k(1M))}G 6s(){F.1A.2B(F,k.2k(1M))}G 6t(){F.1A.2B(F,k.2k(1M))}G 46(){F.1A.2B(F,k.2k(1M))}G 6u(){F.1A.2B(F,k.2k(1M))}G 4E(i){H t={Y:"1p"};P $.1h(E,G(e,s){H o=s.1b(i);o&&(t=o,t.Y=e,t.1w=i)}),t}G 5s(i){H t=(i||"").9J(/\\?.*/g,"").6v(/\\.([^.]{3,4})$/);P t?t[1].6w():1o}H j=16.6x||{};$.1f(j,{6y:"1.3.0"}),j.3J={7F:{1t:{1q:{1i:0,19:0,1G:9K,5t:!0},1N:{1i:0,19:6z,2J:6A},1c:{1i:43,2Z:0,28:6z,2J:6A},1T:{7G:43,7H:43},16:{1i:9L,19:6z,1v:9M},Q:{1i:6A,19:43,2J:9N}},5u:{Q:{1i:7I,19:7I,2J:9O}},2v:"4F",5v:{1u:!0,47:!0,5w:!0},2K:!1,3K:"1U-1K",1P:{1Z:!0},1v:!1,3L:!0,7J:{4F:{48:20,3v:20},K:{48:0,3v:0},L:{48:0,3v:0},4G:{48:0,3v:0}},1c:!0,11:{K:{2Y:.8,3H:.6}},Q:"29",1Q:{5x:1,4H:1,9P:1,9Q:1,2Y:0,2K:0},2a:{5x:1,31:1,9R:1,6B:1,9S:3,2K:0,9T:1,9U:0},5y:{1p:{},1Q:{K:7K},2a:{K:7K,L:9V}}},7L:{},2f:{},7M:{}};H k=9W.32.9X,2L={5z:G(i){P i&&1==i.7N},12:{9Y:G(){G i(i){1X(H t=i;t&&t.7O;)t=t.7O;P t}P G(t){H e=i(t);P!(!e||!e.4I)}}()}};(G(){G i(i){H t;U(i.3l.7P?t=i.3l.7P/9Z:i.3l.7Q&&(t=-i.3l.7Q/3),t){H e=$.a0("2f:5A");$(i.2D).a1(e,t),e.a2()&&i.2r(),e.a3()&&i.2l()}}$(2o.4J).1x("5A a4",i)})();H q=G(){H i=0,t=6j()+6j();P G(e){1X(e=e||t,i++;$("#"+e+i)[0];)i++;P e+i}}(),3w={};(G(){H i={};$.1h(["a5","a6","a7","a8","a9"],G(t,e){i[e]=G(i){P 13.7R(i,t+2)}}),$.1f(i,{aa:G(i){P 1-13.ab(i*13.ac/2)}}),$.1h(i,G(i,t){3w["ad"+i]=t,3w["ae"+i]=G(i){P 1-t(1-i)},3w["af"+i]=G(i){P.5>i?t(2*i)/2:1-t(-2*i+2)/2}}),$.1h(3w,G(i,t){$.3w[i]||($.3w[i]=t)})})();H x={2I:G(){H i={L:$(16).L(),K:$(16).K()};P 1a.4K&&(i.K=16.ag,i.L=16.3M),i}},3x={3y:G(i){H t=$.1f({2v:"4F"},1M[1]||{});t.2M||(t.2M=$.1f({},R.21));H e=t.2M,s=$.1f({},i),o=1,n=5;t.3m&&(e.K-=2*t.3m,e.L-=2*t.3m);H a={L:!0,K:!0};2E(t.2v){1D"4G":a={};1D"K":1D"L":a={},a[t.2v]=!0}1X(;n>0&&(a.K&&s.K>e.K||a.L&&s.L>e.L);){H h=1,r=1;a.K&&s.K>e.K&&(h=e.K/s.K),a.L&&s.L>e.L&&(r=e.L/s.L);H o=13.2e(h,r);s={K:13.3N(i.K*o),L:13.3N(i.L*o)},n--}P s.K=13.1B(s.K,0),s.L=13.1B(s.L,0),s}},1a=G(i){G t(t){H e=ah(t+"([\\\\d.]+)").5B(i);P e?4L(e[1]):!0}P{1m:!(!16.ai||-1!==i.33("6C"))&&t("aj "),6C:i.33("6C")>-1&&(!!16.6D&&6D.6y&&4L(6D.6y())||7.55),49:i.33("7S/")>-1&&t("7S/"),7T:i.33("7T")>-1&&-1===i.33("ak")&&t("al:"),4K:!!i.6v(/am.*an.*ao/),6E:i.33("6E")>-1&&t("6E/"),7U:i.33("7V")>-1&&t("7V/"),3z:i.33("3z")>-1&&t("3z "),5C:i.33("5C")>-1&&t("5C/")}}(7W.ap),26=G(){G i(i){P e(i,"7X")}G t(i,t){1X(H e 4C i)U(2C 0!==s.3A[i[e]])P"7X"==t?i[e]:!0;P!1}G e(i,e){H s=i.aq(0).7Y()+i.5n(1),n=(i+" "+o.ar(s+" ")+s).3t(" ");P t(n,e)}H s=2o.6F("X"),o="as at O au av".3t(" ");P{4D:G(){H i=2o.6F("4D");P!(!i.6o||!i.6o("2d"))}(),11:G(){5p{P!!("aw"4C 16||16.7Z&&2o ax 7Z)}5q(i){P!1}}(),6G:!(!16.6G||1a.1m&&9>1a.1m),17:{80:e("80"),ay:i}}}();26.2N=26.11&&(1a.4K||1a.3z||1a.5C||1a.7U||!/^(az|aA|aB)/.6k(7W.aC)),26.7C=26.4D&&G(){H i=2o.6F("4D");P i.6p&&0===i.6p("1p/6H").33("1b:1p/6H")}();H y={3O:{22:{6I:"1.4.4",6J:16.22&&22.aD.aE}},81:G(){G i(i){1X(H e=i.6v(t),s=e&&e[1]&&e[1].3t(".")||[],o=0,n=0,a=s.1n;a>n;n++)o+=4M(s[n]*13.7R(10,6-2*n));P e&&e[3]?o-1:o}H t=/^(\\d+(\\.?\\d+){0,3})([A-82-aF-]+[A-82-aG-9]+)?/;P G(t){(!F.3O[t].6J||i(F.3O[t].6J)<i(F.3O[t].6I)&&!F.3O[t].83)&&(F.3O[t].83=!0,5o("6x aH "+t+" >= "+F.3O[t].6I))}}()},3n={4a:G(i){P{4b:i?"4b":"5D",5E:i?"5E":"aI",5F:i?"5F":"aJ"}}(26.2N),1x:G(i){G t(t){G s(t){U(e.2l&&t.2l(),p){l=t.3l.5G?t.3l.5G[0]:t,d=(1Y 6K).6L(),h=l.34,r=l.35,n=h-m,a=r-v;H s=(1Y 6K).6L();g&&(e.aK&&13.4c(n)<e.6M||e.aL&&13.4c(a)<e.6M||p&&aM>s-p)||(w&&(w=!1,g=!1,m=l.34,v=l.35,n=h-m,a=r-v),"G"==$.Y(e.1G)&&e.1G({2D:i,x:n,y:a}))}}G o(){U(u.4d(3n.4a.4b),p&&d){H t=!1;e.84>d-p&&13.4c(c-h)>e.85&&13.4c(f-r)<e.86&&(t=!0,"G"==$.Y(e.4e)&&e.4e({2D:i,87:c>h?"1u":"47",x:n,y:a})),"G"==$.Y(e.4N)&&e.4N({2D:i,88:t,x:n,y:a})}p=d=1o}H n,a,h,r,d,u=$(F),p=(1Y 6K).6L(),l=t.3l.5G?t.3l.5G[0]:t,c=l.34,f=l.35,m=l.34,v=l.35,w=!0,g=!0;e.2r&&t.aN(),"G"==$.Y(e.3P)&&e.3P({2D:i}),u.1b("I-4b",s).1b("I-5F",o),u.1x(3n.4a.4b,s).aO(3n.4a.5F,o)}H e=$.1f({85:15,86:75,6M:10,89:!1,aP:!1,84:aQ,2r:!1,2l:!1,3P:!1,1G:!1,4N:!1,4e:!1},1M[1]||{});$(i).1b("I-5E",t),$(i).1x(3n.4a.5E,t)},4d:G(i){H t={3P:0,1G:0,4N:0};$.1h(t,G(e){t[e]=$(i).1b("I-11"+e),t[e]&&$(i).4d(3n.4a["11"+e],t[e]).aR("I-11"+e)})}},1s={1I:G(i,t,e){"G"==$.Y(t)&&(e=t,t={}),t=$.1f({3Q:!1,Y:!1,aS:aT,38:!0},t||{});H s=1s.1C.1I(i),o=t.Y||4E(i).Y,n={Y:o,4f:e};U(!s){H a;(a=1s.3B.1I(i))&&a.1g&&(s=a,1s.1C.23(i,a.1g,a.1b))}U(s)e&&e($.1f({},s.1g),s.1b);24 2E(t.3Q&&1s.1N.2g(i),o){1D"1p":H h=1Y 6n;h.3I=G(){h.3I=G(){},s={1g:{K:h.K,L:h.L}},n.1p=h,t.38?6m(h,G(o,a){n.38=o,n.4O=a,1s.1C.23(i,s.1g,n),t.3Q&&1s.1N.2g(i),e&&e(s.1g,n)}):(1s.1C.23(i,s.1g,n),t.3Q&&1s.1N.2g(i),e&&e(s.1g,n))},h.3k=i,t.3Q&&1s.1N.23(i,{1p:h,Y:o});2O;1D"1Q":H r=4E(i).3o,d="4P"+(16.2P&&"4Q:"==16.2P.4R?"s":"")+":",u=$.8a(d+"//1Q.3a/4H/8b.8c?1w="+d+"//1Q.3a/"+r+"&4f=?",$.V(G(s){H o={1g:{K:s.K,L:s.L}};1s.1C.23(i,o.1g,n),t.3Q&&1s.1N.2g(i),e&&e(o.1g,n)},F));t.3Q&&1s.1N.23(i,{5H:u,Y:o})}}};1s.6N=G(){P F.1A.2B(F,k.2k(1M))},$.1f(1s.6N.32,{1A:G(){F.1C=[]},1I:G(i){1X(H t=1o,e=0;F.1C.1n>e;e++)F.1C[e]&&F.1C[e].1w==i&&(t=F.1C[e]);P t},23:G(i,t,e){F.1R(i),F.1C.2h({1w:i,1g:t,1b:e})},1R:G(i){1X(H t=0;F.1C.1n>t;t++)F.1C[t]&&F.1C[t].1w==i&&4g F.1C[t]},aU:G(i){H t=1I(i.1w);t?$.1f(t,i):F.1C.2h(i)}}),1s.1C=1Y 1s.6N,1s.44=G(){P F.1A.2B(F,k.2k(1M))},$.1f(1s.44.32,{1A:G(){F.1C=[]},23:G(i,t){F.2g(i),F.1C.2h({1w:i,1b:t})},1I:G(i){1X(H t=1o,e=0;F.1C.1n>e;e++)F.1C[e]&&F.1C[e].1w==i&&(t=F.1C[e]);P t},2g:G(i){1X(H t=F.1C,e=0;t.1n>e;e++)U(t[e]&&t[e].1w==i&&t[e].1b){H s=t[e].1b;2E(s.Y){1D"1p":s.1p&&s.1p.3I&&(s.1p.3I=G(){});2O;1D"1Q":s.5H&&(s.5H.aV(),s.5H=1o)}4g t[e]}}}),1s.1N=1Y 1s.44,1s.3L=G(i,t,e){U("G"==$.Y(t)&&(e=t,t={}),t=$.1f({38:!0,6O:!1},t||{}),!t.6O||!1s.3B.1I(i)){H s;U((s=1s.3B.1I(i))&&s.1g)P"G"==$.Y(e)&&e($.1f({},s.1g),s.1b),2C 0;H o={1w:i,1b:{Y:"1p"}},n=1Y 6n;o.1b.1p=n,n.3I=G(){n.3I=G(){},o.1g={K:n.K,L:n.L},t.38?6m(n,G(i,t){$.1f(o.1b,{38:i,4O:t}),"G"==$.Y(e)&&e(o.1g,o.1b)}):"G"==$.Y(e)&&e(o.1g,o.1b)},1s.3B.1C.1O(o),n.3k=i}},1s.3B={1I:G(i){P 1s.3B.1C.1I(i)},8d:G(i){H t=F.1I(i);P t&&t.1g}},1s.3B.1C=G(){G i(i){1X(H t=1o,s=0,o=e.1n;o>s;s++)e[s]&&e[s].1w&&e[s].1w==i&&(t=e[s]);P t}G t(i){e.2h(i)}H e=[];P{1I:i,1O:t}}();H z=G(){G i(i,s,o){i=i||{},o=o||{},i.3R=i.3R||(j.3J[A.4h]?A.4h:"2f"),1a.1m&&7>1a.1m&&(i.3R="7M");H n=i.3R?$.1f({},j.3J[i.3R]||j.3J[A.4h]):{},a=3u(e,n);s&&a.5y[s]&&(a=3u(a.5y[s],a),4g a.5y);H h=3u(a,i);U(26.2N?h.Q="11":"11"==h.Q&&(h.Q="11"!=a.Q?a.Q:"11"!=e.Q?e.Q:"11"!=t.Q?t.Q:"29"),h.2v?"6P"==$.Y(h.2v)&&(h.2v="4F"):h.2v="4G","11"==h.Q&&(h.2v="4F"),h.31&&(h.31="4S"==$.Y(h.31)?3u(a.31||e.31||t.31,{Y:h.31}):3u(t.31,h.31)),!h.1t||26.2N&&!h.5u?(h.1t={},$.1h(t.1t,G(i,t){$.1h(h.1t[i]=$.1f({},t),G(t){h.1t[i][t]=0})})):26.2N&&h.5u&&(h.1t=3u(h.1t,h.5u)),1a.1m&&9>1a.1m&&5r(h.1t,{1q:{1i:0,19:0},1c:{2Z:0},16:{1i:0,19:0},Q:{1i:0,19:0}}),("11"==h.Q||1a.1m&&7>1a.1m)&&(h.1c=!1),h.5v&&"1p"!=s&&$.1f(h.5v,{1u:!1,47:!1}),!h.1d&&"6P"!=$.Y(h.1d)){H r=!1;2E(s){1D"2a":H d="4P"+(16.2P&&"4Q:"==16.2P.4R?"s":"")+":";r=d+"//5I.2a.3a/6Q/"+o.3o+"/0.8e";2O;1D"1p":1D"1Q":r=!0}h.1d=r}P h}H t=j.3J.7F,e=3u(t,j.3J.7L);P{6R:i}}();$.1f(44.32,{1A:G(i){F.4i=i,F.M=$.1f({1c:C,2m:"I-1N"},1M[1]||{}),F.M.1c&&(F.1c=F.M.1c),F.2s(),F.3b()},2s:G(){U($(2o.4I).T(F.12=$("<X>").N(F.M.2m).19().T(F.4T=$("<X>").N(F.M.2m+"-4T").T($("<X>").N(F.M.2m+"-2w")).T($("<X>").N(F.M.2m+"-2F")))),1a.1m&&7>1a.1m){H i=F.12[0].3A;i.1v="6S",i.4j("1y","((!!16.22 ? 22(16).4U() + (.5 * 22(16).L()) : 0) + \'1e\')"),i.4j("1u","((!!16.22 ? 22(16).5J() + (.5 * 22(16).K()): 0) + \'1e\')")}},4k:G(i){F.12[0].2m=F.M.2m+" "+F.M.2m+"-"+i},3b:G(){F.12.1x("1V",$.V(G(){F.4i.19()},F))},3P:G(i){F.6T();H t=R.W&&R.W[R.14-1];F.12.1H(1,0).3S(t?t.J.M.1t.1N.1i:0,1,i)},1H:G(i,t){H e=R.W&&R.W[R.14-1];F.12.1H(1,0).2J(t?0:e?e.J.M.1t.1N.aW:0).4V(e.J.M.1t.1N.19,i)},6T:G(){H i=0;U(F.1c){F.1c.2x();H i=F.1c.1J.1c.L}F.4T.17({"2b-1y":(F.4i.J.M.1c?i*-.5:0)+"1e"})}}),$.1f(6q.32,{1A:G(i){F.M=$.1f({2m:"I-1P"},1M[1]||{}),F.4i=i,F.2s(),1a.1m&&9>1a.1m&&$(16).1x("1L",$.V(G(){F.12&&F.12.2t(":1E")&&F.1B()},F)),F.6U()},2s:G(){U(F.12=$("<X>").N(F.M.2m).T(F.2w=$("<X>").N(F.M.2m+"-2w")),$(2o.4I).3T(F.12),1a.1m&&7>1a.1m){F.12.17({1v:"6S"});H i=F.12[0].3A;i.4j("1y","((!!16.22 ? 22(16).4U() : 0) + \'1e\')"),i.4j("1u","((!!16.22 ? 22(16).5J() : 0) + \'1e\')")}F.12.19(),F.12.1x("1V",$.V(G(){H i=F.4i.J;U(i){H t=i.M;U(t.1P&&!t.1P.1Z||"11"==t.Q)P}F.4i.19()},F)),F.12.1x("2f:5A",G(i){i.2l()})},4k:G(i){F.12[0].2m=F.M.2m+" "+F.M.2m+"-"+i},aX:G(i){F.M=i,F.6U()},6U:G(){F.1B()},1i:G(i){F.1B(),F.12.1H(1,0);H t=R.W&&R.W[R.14-1];P F.4l(1,t?t.J.M.1t.16.1i:0,i),F},19:G(i){H t=R.W&&R.W[R.14-1];P F.12.1H(1,0).4V(t?t.J.M.1t.16.19||0:0,"8f",i),F},4l:G(i,t,e){F.12.3S(t||0,i,"8f",e)},8g:G(){H i={};P $.1h(["K","L"],G(t,e){H s=e.5n(0,1).7Y()+e.5n(1),o=2o.4J;i[e]=(1a.1m?13.1B(o["4T"+s],o["4m"+s]):1a.49?2o.4I["4m"+s]:o["4m"+s])||0}),i},1B:G(){1a.4K&&1a.49&&8h.18>1a.49&&F.12.17(1e(F.8g())),1a.1m&&9>1a.1m&&F.12.17(1e({L:$(16).L(),K:$(16).K()}))}}),$.1f(6r.32,{1A:G(){F.2u={},F.5K=0},23:G(i,t,e){U("4S"==$.Y(i)&&F.2g(i),"G"==$.Y(i)){1X(e=t,t=i;F.2u["8i"+F.5K];)F.5K++;i="8i"+F.5K}F.2u[i]=16.4W($.V(G(){t&&t(),F.2u[i]=1o,4g F.2u[i]},F),e)},1I:G(i){P F.2u[i]},2g:G(i){i||($.1h(F.2u,$.V(G(i,t){16.4X(t),F.2u[i]=1o,4g F.2u[i]},F)),F.2u={}),F.2u[i]&&(16.4X(F.2u[i]),F.2u[i]=1o,4g F.2u[i])}}),$.1f(6s.32,{1A:G(){F.6V={}},23:G(i,t){F.6V[i]=t},1I:G(i){P F.6V[i]||!1}});H A={4h:"2f",1A:G(){F.3C=[],F.3C.6W=$({}),F.3C.8j=$({}),F.2y=1Y 6s,F.3D=1Y 6r,F.2s(),F.3b(),F.4k(F.4h)},2s:G(){U(F.1P=1Y 6q(F),$(2o.4I).3T(F.12=$("<X>").N("I-16").T(F.2Q=$("<X>").N("I-2Q").19().T(F.2p=$("<X>").N("I-2p").T(F.1G=$("<X>").N("I-2p-1G"))).T(F.1c=$("<X>").N("I-1c")).T(F.1T=$("<X>").N("I-11")))),F.1N=1Y 44(F),1a.1m&&7>1a.1m){H i=F.12[0].3A;i.1v="6S",i.4j("1y","((!!16.22 ? 22(16).4U() : 0) + \'1e\')"),i.4j("1u","((!!16.22 ? 22(16).5J() : 0) + \'1e\')")}U(1a.1m){9>1a.1m&&F.12.N("I-aY");1X(H t=6;9>=t;t++)t>1a.1m&&F.12.N("I-aZ"+t)}26.11&&F.12.N("I-11-1W"),26.2N&&F.12.N("I-b0-11-1W"),F.12.1b("8k-8l",F.12[0].2m),C.1A(F.12),R.1A(F.12),D.1A(F.12),B.1A(),F.12.19()},4k:G(i,t){t=t||{},i&&(t.3R=i),F.1P.4k(i);H e=F.12.1b("8k-8l");P F.12[0].2m=e+" I-16-"+i,F},6X:G(i){j.3J[i]&&(F.4h=i)},3b:G(){$(2o.4J).3p(".2f[4Y]","1V",G(i,t){i.2r(),i.2l();H t=i.b1;R.3E({x:i.34,y:i.35}),5L.1i(t)}),$(2o.4J).1x("1V",G(i){R.3E({x:i.34,y:i.35})}),F.12.3p(".I-Q-2i, .I-25-2i","1V",$.V(G(i){i.2r()},F)),$(2o.4J).3p(".I-1P, .I-Q, .I-1j, .I-2Q","1V",$.V(G(i){H t=A.J;U(t){H e=t.M;U(e.1P&&!e.1P.1Z||"11"==e.Q)P}i.2l(),i.2r(),A.19()},F)),F.12.1x("2f:5A",G(i){i.2l()})},28:G(i,t){H e=$.1f({},1M[2]||{});F.4n(),F.2n=!0;H s=2>i.1n;U($.1h(i,G(i,t){P t.M.1d?2C 0:(s=!0,!1)}),s&&$.1h(i,G(i,t){t.M.1d=!1,t.M.1c=!1}),2>i.1n){H o=i[0].M.3K;o&&"1Z"!=o&&(i[0].M.3K="1Z")}F.4o=i,C.28(i),D.28(i),R.28(i),B.1W={5w:!0},t&&F.2G(t,$.V(G(){F.2n&&(F.2n=!1,e.4f&&e.4f())},F))},8m:G(){U(!F.2y.1I("4Z")){H i=$("5M, 6Y, b2"),t=[];i.1h(G(i,e){H s;$(e).2t("6Y, 5M")&&(s=$(e).2z(\'6Z[b3="8n"]\')[0])&&s.8o&&"8p"==s.8o.6w()||$(e).2t("[8n=\'8p\']")||t.2h({12:e,2R:$(e).17("2R")})}),$.1h(t,G(i,t){$(t.12).17({2R:"8q"})}),F.2y.23("4Z",t)}},8r:G(){H i=F.2y.1I("4Z");i&&i.1n>0&&$.1h(i,G(i,t){$(t.12).17({2R:t.2R})}),F.2y.23("4Z",1o)},b4:G(){H i=F.2y.1I("4Z");i&&$.1h(i,$.V(G(i,t){H e;(e=$(t.12).70(".b5-1q")[0])&&e==F.1q[0]&&$(t.12).17({2R:t.2R})},F))},1i:G(){H i=G(){};P G(t){H e=R.W&&R.W[R.14-1],s=F.3C.6W,o=e&&e.J.M.1t.16.19||0;U(F.2y.1I("1E"))P"G"==$.Y(t)&&t(),2C 0;F.2y.23("1E",!0),s.3U([]),F.8m(),e&&"G"==$.Y(e.J.M.8s)&&e.J.M.8s.2k(j);H n=2;s.3U($.V(G(i){e.J.M.1P&&F.1P.1i($.V(G(){1>--n&&i()},F)),F.3D.23("1i-16",$.V(G(){F.8t(G(){1>--n&&i()})},F),o>1?13.2e(.5*o,50):1)},F)),i(),s.3U($.V(G(i){B.4p(),i()},F)),"G"==$.Y(t)&&s.3U($.V(G(i){t(),i()}),F)}}(),8t:G(i){R.1L(),F.12.1i(),F.2Q.1H(!0);H t=R.W&&R.W[R.14-1];P F.4l(1,t.J.M.1t.16.1i,$.V(G(){i&&i()},F)),F},19:G(){H i=R.W&&R.W[R.14-1],t=F.3C.6W;t.3U([]),F.71(),F.1N.1H(1o,!0);H e=1;t.3U($.V(G(t){H s=i.J.M.1t.16.19||0;F.2Q.1H(!0,!0).4V(s,"5N",$.V(G(){F.12.19(),R.8u(),1>--e&&(F.72(),t())},F)),i.J.M.1P&&(e++,F.3D.23("19-1P",$.V(G(){F.1P.19($.V(G(){1>--e&&(F.72(),t())},F))},F),s>1?13.2e(.5*s,b6):1))},F))},72:G(){F.2y.23("1E",!1),F.8r(),B.3V();H i=R.W&&R.W[R.14-1];i&&"G"==$.Y(i.J.M.8v)&&i.J.M.8v.2k(j),F.3D.2g(),F.4n()},4n:G(){H i=$.1f({73:!1,74:!1},1M[0]||{});"G"==$.Y(i.74)&&i.74.2k(j),F.71(),F.3D.2g(),F.1v=-1,F.4o=1o,C.2g(),R.8w(),F.b7=!1,F.2n=!1,A.2y.23("51",!1),F.51&&($(F.51).1H().1R(),F.51=1o),F.76&&($(F.76).1H().1R(),F.76=1o),"G"==$.Y(i.73)&&i.73.2k(j)},4l:G(i,t,e){F.2Q.1H(!0,!0).3S(t||0,i||1,"77",e)},71:G(){F.3C.8j.3U([]),F.2Q.1H(!0)},2G:G(i,t){i&&F.1v!=i&&(F.3D.2g("51"),F.14,F.1v=i,F.J=F.4o[i-1],F.4k(F.J.M&&F.J.M.3R,F.J.M),R.2G(i,t),D.2G(i))}};1a.3z&&3>1a.3z&&$.1h(A,G(i,t){"G"==$.Y(t)&&(A[i]=G(){P F})});H B={1W:!1,52:{1u:37,47:39,5w:27},4p:G(){F.78()},3V:G(){F.1W=!1},1A:G(){F.78(),$(2o).b8($.V(F.8x,F)).b9($.V(F.8y,F)),B.3V()},78:G(){H i=R.W&&R.W[R.14-1];F.1W=i&&i.J.M.5v},8x:G(i){U(F.1W&&A.12.2t(":1E")){H t=F.79(i.52);U(t&&(!t||!F.1W||F.1W[t]))2E(i.2l(),i.2r(),t){1D"1u":R.1U();2O;1D"47":R.1K()}}},8y:G(i){U(F.1W&&A.4o){H t=F.79(i.52);U(t&&(!t||!F.1W||F.1W[t]))2E(t){1D"5w":A.19()}}},79:G(i){1X(H t 4C F.52)U(F.52[t]==i)P t;P 1o}},R={1A:G(i){i&&(F.12=i,F.14=-1,F.2H=[],F.2S=0,F.2T=[],F.4q=[],F.3C=[],F.3C.3c=$({}),F.2p=F.12.2z(".I-2p:4r"),F.1G=F.12.2z(".I-2p-1G:4r"),F.8z=F.12.2z(".I-8z:4r"),F.5O(5k()),F.53(),F.3b())},5O:G(){H i={2Y:"3H",3H:"2Y"};P G(t){F.2p.N("I-2p-"+t).2A("I-2p-"+i[t])}}(),3b:G(){$(16).1x("1L",$.V(G(){A.2y.1I("1E")&&(F.1L(),F.7a())},F)),$(16).1x("8A",$.V(G(){F.5O(5k()),A.2y.1I("1E")&&(F.1L(),F.7a())},F)),F.2p.3p(".I-1l","1V",$.V(G(i){i.2r(),F.3E({x:i.34,y:i.35});H t=$(i.2D).70(".I-1l").1b("1l");F[t]()},F))},ba:G(){3n.1x(F.2p,{3P:$.V(G(){U(!(F.W&&1>=F.W.1n)){H i=4L(F.1G.17("1u"));F.1G.1b("I-8B-1u",i)}},F),1G:$.V(G(i){U(!(F.W&&1>=F.W.1n)){H t=i.x,e=.4*F.21.K;1==F.14&&t>e||F.14==F.W.1n&&-1*e>t||F.1G.17({1u:F.1G.1b("I-8B-1u")+t+"1e"})}},F),4e:$.V(G(i){F.W&&1>=F.W.1n||F["47"==i.87?"1U":"1K"]()},F),4N:$.V(G(i){F.W&&1>=F.W.1n||i.88||(i.x&&13.4c(i.x)>.5*F.21.K?F[i.x>0?"1U":"1K"]():F.3d(F.14),F.bb=1o)},F),89:!0,2r:!0,2l:!0})},8w:G(){3n.4d(F.2p)},28:G(i){F.W&&($.1h(F.W,G(i,t){t.1R()}),F.W=1o,F.7b=!1,F.2T=[],F.4q=[]),F.2S=0,F.1G.8C("3A"),F.W=[],5P=!1,$.1h(i,$.V(G(i,t){5P=5P||"11"==t.M.Q,F.W.2h(1Y 6t(t,i+1))},F)),F[(5P?"1x":"4d")+"3n"](),F.53()},8D:G(i){1a.1m&&9>1a.1m?(F.3E({x:i.34,y:i.35}),F.1v()):F.5Q=4W($.V(G(){F.3E({x:i.34,y:i.35}),F.1v()},F),30)},8E:G(){F.5Q&&(4X(F.5Q),F.5Q=1o)},8F:G(){26.2N||F.54||F.12.1x("5D",F.54=$.V(F.8D,F))},8G:G(){!26.2N&&F.54&&(F.12.4d("5D",F.54),F.54=1o,F.8E())},7a:G(){F.3d(F.14,1o,!0)},3d:G(i,t,e){F.7b||(e=!0,F.7b=!0),F.53();H s=F.W[i-1];U("11"==s.J.M.Q){H o=.5*F.1F.K-.5*F.21.K;o-=(i-1)*F.21.K;H n=e?0:s.J.M.1t.1q.1G,a=4L(F.1G.17("1u")),h=13.4c(a-o);U(F.21.K>h){H r=h/F.21.K;n=13.4s(n*r)}$.1h(F.W,G(i,t){16.5R&&t.3e&&t.56?(t.3e.bc(),t.8H=1o,t.5S(),t.7c()):t.7d&&t.56&&(t.7d.4H("bd"),t.8H=1o,t.5S(),t.7e())}),F.1G.1H().5T({1u:o+"1e"},{7f:e?0:s.J.M.1t.1q.1G,3w:"5N",8I:G(){t&&t()}})}},2G:G(i,t){F.8J(),F.14=i;H e=F.W[i-1],s=e.J.M.Q,o=1;"11"==s?(o++,F.3d(i,G(){"G"==$.Y(e.J.M.5U)&&1>--o&&e.J.M.5U.2k(j,i)})):F.1G.T(e.1j),F.2p.2z(".I-1j").2A("I-1j-4t"),e.1j.N("I-1j-4t"),C.2G(i),e.28($.V(G(){!e||e&&!e.J||F.1i(i,G(){e&&e.J&&(t&&t(),"G"==$.Y(e.J.M.5U)&&1>--o&&e.J.M.5U.2k(j,i))})},F)),F.8K()},8K:G(){U(F.W&&F.W.1n>1){H i=F.57(),t=i.1U,e=i.1K,s={1U:t!=F.14&&F.W[t-1],1K:e!=F.14&&F.W[e-1]};1==F.14&&(s.1U=1o),F.14==F.W.1n&&(s.1K=1o);H o,n=(o=F.W[F.14-1])&&o.J&&"11"==o.J.M.Q;U(n){1X(H a=5,h=13.4s(F.14/a)*a+1,r=0;a>r;r++){H d=h+r,u=F.W[d-1],p=u&&u.J;p&&-1>=$.5V(d,F.4q)&&(F.4q.2h(d),d!=F.14&&u.28(1o,!0))}H l=h-1,c=h+a;$.1h([l-1,l,c,c+1],$.V(G(i,t){H e=F.W[t-1],s=e&&e.J;s&&-1>=$.5V(t,F.4q)&&(F.4q.2h(t),t!=F.14&&e.28(1o,!0))},F))}24 $.1h(s,$.V(G(i,t){H e=t&&t.J;e&&"1p"==e.Y&&e.M.3L&&1s.3L(e.1w,{6O:!0})},F))}},57:G(){U(!F.W)P{};H i=F.14,t=F.W.1n,e=1>=i?t:i-1,s=i>=t?1:i+1;P{1U:e,1K:s}},8L:G(){H i=R.W&&R.W[R.14-1];P i&&i.J.M.2K&&F.W&&F.W.1n>1||1!=F.14},1U:G(i){H t=F.8L();U(i||t)A.2G(F.57().1U);24{H e;!t&&(e=R.W&&R.W[R.14-1])&&"11"==e.J.M.Q&&F.3d(F.14)}},8M:G(){H i=R.W&&R.W[R.14-1];P i&&i.J.M.2K&&F.W&&F.W.1n>1||F.W&&F.W.1n>1&&1!=F.57().1K},1K:G(i){H t=F.8M();U(i||t)A.2G(F.57().1K);24{H e;!t&&(e=R.W&&R.W[R.14-1])&&"11"==e.J.M.Q&&F.3d(F.14)}},8N:G(i){F.8O(i)||F.2H.2h(i)},8P:G(i){F.2H=$.8Q(F.2H,G(t){P t!=i})},8O:G(i){P $.5V(i,F.2H)>-1},3E:G(i){i.y-=$(16).4U(),i.x-=$(16).5J();H t={y:13.2e(13.1B(i.y/F.1F.L,0),1),x:13.2e(13.1B(i.x/F.1F.K,0),1)},e=20,s={x:"K",y:"L"},o={};$.1h("x y".3t(" "),$.V(G(i,n){o[n]=13.2e(13.1B(e/F.1F[s[n]],0),1),t[n]*=1+2*o[n],t[n]-=o[n],t[n]=13.2e(13.1B(t[n],0),1)},F)),F.8R(t)},8R:G(i){F.7g=i},1v:G(){1>F.2T.1n||$.1h(F.2T,G(i,t){t.1v()})},1L:G(){1a.1m&&7>1a.1m||C.1L(),F.53(),F.2p.17(1e(F.1F)),$.1h(F.W,G(i,t){t.1L()}),F.W[0]&&"11"==F.W[0].J.M.Q&&($.1h(F.W,G(i,t){t.1j.17({K:R.5W+"1e"})}),F.1G.17({K:R.5W*F.W.1n+"1e"}))},53:G(){H i=x.2I(),t=F.W&&F.W[0].J.M.Q;C.1E()&&(C.2x(),i.L-=C.1J.1c.L),D.1E()&&(D.2x(),i.L-=D.1J.1r.L);H e=$.1f({},i);2E(F.2S=0,t){1D"29":$.1h(F.W,$.V(G(i,t){H e=t.1Z;F.W.1n>1&&(t.7h&&(e=e.1O(t.7h)),t.4u&&(e=e.1O(t.4u)));H s=0;t.5X(G(){$.1h(e,G(i,t){s=13.1B(s,$(t).2U(!0))})}),F.2S=13.1B(F.2S,s)||0},F)),e.K-=2*(F.2S||0);2O;1D"11":H s=5k();F.W&&F.W[0].1j;H o=F.1G.2q("3A");F.1G.8C("3A");H n,a;F.2p.17(1e({L:e.L})),$.1h(F.W,$.V(G(t,e){H s=e.1j;U(s.1b("2Y"))n=13.4s(i.K*s.1b("2Y")),a=13.4s(i.K*s.1b("3H"));24{H o=e.J.M.11.K;s.1b("2Y",13.1B(o.2Y,.5)).1b("3H",13.1B(o.3H,.5))}},F)),F.5O(s),F.5W="2Y"==s?n:a,$.1f(e,{K:F.5W||0}),F.1G.2q("3A",o)}F.1F=i,F.21=e},bf:G(){P{1U:F.14-1>0,1K:F.14+1<=F.W.1n}},1i:G(i,t){H e=[];$.1h(F.W,G(t,s){s.14!=i&&e.2h(s)});H s=e.1n+1,o=F.W[F.14-1];C[o.J.M.1c?"1i":"19"](),D["11"==o.J.M.Q?"1i":"19"](),("11"!=o.J.M.Q||"1p"!=o.J.Y)&&F.1L();H n=o.J.M.1t.1q.5t;$.1h(e,$.V(G(e,o){o.19($.V(G(){n?t&&1>=s--&&t():2>=s--&&F.W[i-1].1i(t)},F))},F)),n&&F.W[i-1].1i(G(){t&&1>=s--&&t()})},8u:G(){$.1h(F.2H,$.V(G(i,t){F.W[t-1].19()},F)),C.19(),F.3E({x:0,y:0})},bg:G(i){$.1h(F.W,$.V(G(t,e){e.1v!=i&&e.19()},F))},8S:G(i){F.8T(i)||(F.2T.2h(F.W[i-1]),1==F.2T.1n&&F.8F())},bh:G(){F.2T=[]},7i:G(i){F.2T=$.8Q(F.2T,G(t){P t.14!=i}),1>F.2T.1n&&F.8G()},8T:G(i){H t=!1;P $.1h(F.2T,G(e,s){P s.14==i?(t=!0,!1):2C 0}),t},2M:G(){H i=F.1F;P A.bi&&(i.K-=bj),i},8J:G(){$.1h(F.W,$.V(G(i,t){t.7j()},F))}};$.1f(6t.32,{1A:G(i,t){F.J=i,F.14=t,F.1F={},F.2s()},1R:G(){F.5Y(),F.58&&(R.7i(F.14),F.58=!1),F.4n(),F.1j.1R(),F.1j=1o,F.Q&&(F.Q.1R(),F.Q=1o),F.J=1o,F.1F={},F.7j()},2s:G(){H i=F.J.M.Q,t=A.4o.1n;U(R.1G.T(F.1j=$("<X>").N("I-1j").T(F.25=$("<X>").N("I-25").N("I-25-2V-Q-"+i).N("I-25-2V-Y-"+F.J.Y))),F.25.T(F.4v=$("<X>").N("I-25-2i").T(F.7k=$("<X>").N("I-25-3f").T(F.5Z=$("<X>").N("I-25-8U-3m").T(F.3g=$("<X>").N("I-25-1r"))))),"1p"==F.J.Y&&"11"!=i&&(F.3q=$("<X>").N("I-7l-1p")),"11"==i)F.1j.N("I-1j-11").1i(),"1p"==F.J.Y&&"1Z"==F.J.M.3K&&(F.1j.N("I-1j-3h-1Z"),F.3g.1x("1V",G(i){i.2l(),i.2r(),A.19()}));24{F.1j.1i();H e=F.J.M.3K;U("1p"==F.J.Y&&("1K"==e&&(F.J.M.2K||!F.J.M.2K&&F.14!=A.4o.1n)||"1Z"==e)&&F.1j.N("I-1j-3h-"+e.6w()),"29"==i?F.1j.3T(F.Q=$("<X>").N("I-Q I-Q-29")):F.1j.T(F.Q=$("<X>").N("I-Q I-Q-2W")),F.4v.1x("1V",$.V(G(i){i.2D==F.4v[0]&&F.J.M.1P&&F.J.M.1P.1Z&&A.19()},F)),"29"==F.J.M.Q?F.Q.T(F.2j=$("<X>").N("I-Q-1r-29")):(F.Q.T(F.7m=$("<X>").N("I-Q-2i").T(F.60=$("<X>").N("I-Q-3f").T(F.7n=$("<X>").N("I-Q-8U-3m").T(F.8V=$("<X>").N("I-Q-bk").T(F.2j=$("<X>").N("I-Q-1r")))))),F.3q&&F.2j.T(F.3q.61())),t>1&&(F.2j.T(F.3W=$("<X>").N("I-1l I-1l-1K").T(F.4u=$("<X>").N("I-1l-1S").T($("<X>").N("I-1l-1S-2F"))).1b("1l","1K")),F.14!=t||F.J.M.2K||(F.3W.N("I-1l-59"),F.4u.N("I-1l-1S-59")),F.2j.T(F.3X=$("<X>").N("I-1l I-1l-1U").T(F.62=$("<X>").N("I-1l-1S").T($("<X>").N("I-1l-1S-2F"))).1b("1l","1U")),1!=F.14||F.J.M.2K||(F.3X.N("I-1l-59"),F.62.N("I-1l-1S-59"))),F.3q&&"2W"==F.J.M.Q&&F.2j.2z(".I-1l").3T(F.3q.61()),F.1j.N("I-2X-1k"),(F.J.1k||"2W"==F.J.M.Q&&!F.J.1k)&&(F["2W"==F.J.M.Q?"2j":"1j"].T(F.1z=$("<X>").N("I-1z I-1z-"+F.J.M.Q).T(F.bl=$("<X>").N("I-1z-2w")).T(F.63=$("<X>").N("I-1z-3f"))),F.1z.1x("1V",G(i){i.2r()})),F.J.1k&&(F.1j.2A("I-2X-1k").N("I-2V-1k"),F.63.T(F.1k=$("<X>").N("I-1k").64(F.J.1k))),t>1&&F.J.M.1v){H s=F.14+" / "+t;F.1j.N("I-2V-1v");H i=F.J.M.Q;F["2W"==i?"63":"2j"]["2W"==i?"3T":"T"](F.7h=$("<X>").N("I-1v").T($("<X>").N("I-1v-2w")).T($("<3Y>").N("I-1v-bm").64(s)))}F.2j.T(F.1Z=$("<X>").N("I-1Z").1x("1V",G(){A.19()}).T($("<3Y>").N("I-1Z-2w")).T($("<3Y>").N("I-1Z-2F"))),"1p"==F.J.Y&&"1Z"==F.J.M.3K&&F["29"==F.J.M.Q?"3g":"60"].1x("1V",G(i){i.2l(),i.2r(),A.19()}),F.1j.19()}},7o:G(i){U(!F.J.1k)P 0;"29"==F.J.M.Q&&(i=13.2e(i,R.21.K));H t,e=F.1z.17("K");P F.1z.17({K:i+"1e"}),t=4L(F.1z.17("L")),F.1z.17({K:e}),t},5X:G(i,t){H e=[],s=A.12.1O(A.2Q).1O(F.1j).1O(F.Q);t&&(s=s.1O(t)),$.1h(s,G(i,t){e.2h({1E:$(t).2t(":1E"),12:$(t).1i()})}),i(),$.1h(e,G(i,t){t.1E||t.12.19()})},3Z:G(){F.2x();H i=F.1F.1B,t=F.J.M.Q,e=F.7p,s=F.8W,o=F.65,n=3x.3y(i,{2v:e,Q:t,3m:o}),a=$.1f({},n);U(o&&(a=3x.3y(a,{2M:n,Q:t}),n.K+=2*o,n.L+=2*o),s.48||s.3v){H h=$.1f({},R.21);o&&(h.K-=2*o,h.L-=2*o),h={K:13.1B(h.K-2*s.48,0),L:13.1B(h.L-2*s.3v,0)},a=3x.3y(a,{2v:e,2M:h,Q:t})}H r={1k:!0},d=!1;U("29"==t){H s={L:n.L-a.L,K:n.K-a.K},u=$.1f({},a);F.1k&&F.1j.40("I-2X-1k");H p;U(F.1k){p=F.1k,F.1z.2A("I-2X-1k");H l=F.1j.40("I-2X-1k");F.1j.2A("I-2X-1k");H c=F.1j.40("I-2V-1k");F.1j.N("I-2V-1k")}A.12.17({2R:"1E"}),F.5X($.V(G(){1X(H i=0,n=2;n>i;){r.L=F.7o(a.K);H h=.5*(R.21.L-2*o-(s.3v?2*s.3v:0)-a.L);r.L>h&&(a=3x.3y(a,{2M:$.1f({},{K:a.K,L:13.1B(a.L-r.L,0)}),2v:e,Q:t})),i++}r.L=F.7o(a.K);H d=x.2I();(66>=d.L&&67>=d.K||66>=d.K&&67>=d.L||r.L>=.5*a.L||r.L>=.6*a.K)&&(r.1k=!1,r.L=0,a=u)},F),p),A.12.17({2R:"1E"}),l&&F.1j.N("I-2X-1k"),c&&F.1j.N("I-2V-1k");H f={L:n.L-a.L,K:n.K-a.K};n.L+=s.L-f.L,n.K+=s.K-f.K,a.L!=u.L&&(d=!0)}24 r.L=0;H m={K:a.K+2*o,L:a.L+2*o};r.L&&(n.L+=r.L),"2W"==t&&(r.L=0);H v={2i:{1g:n},3f:{1g:m},1r:{1g:a,2M:m,2b:{1y:.5*(n.L-m.L)-.5*r.L,1u:.5*(n.K-m.K)}},1q:{1g:a},1z:r};"29"==t&&(v.1z.1y=v.1r.2b.1y,r.K=13.2e(a.K,R.21.K));H h=$.1f({},R.21);P"29"==t&&(v.25={1g:{K:R.21.K},1v:{1u:.5*(R.1F.K-R.21.K)}}),v.Q={2i:{1g:{K:13.2e(n.K,h.K),L:13.2e(n.L,h.L)}},3f:{1g:m},1r:{1g:{K:13.2e(v.1r.1g.K,h.K-2*o),L:13.2e(v.1r.1g.L,h.L-2*o)},2b:{1y:v.1r.2b.1y+o,1u:v.1r.2b.1u+o}}},v},2x:G(){H i=$.1f({},F.1F.1B),t=4M(F.5Z.17("3m-1y-K"));F.65=t,t&&(i.K-=2*t,i.L-=2*t);H e=F.J.M.2v;"bn"==e?e=i.K>i.L?"L":i.L>i.K?"K":"4G":e||(e="4G"),F.7p=e;H s=F.J.M.7J[F.7p];F.8W=s},7q:G(){F.5a&&(4X(F.5a),F.5a=1o)},7j:G(){F.5a&&F.2n&&!F.3F&&(F.7q(),F.2n=!1)},28:G(i,t){P F.3F||F.2n?(F.3F&&F.68(i),2C 0):(t||1s.1C.1I(F.J.1w)||1s.3B.8d(F.J.1w)||A.1N.3P(),F.2n=!0,F.5a=4W($.V(G(){2E(F.7q(),F.J.Y){1D"1p":H e=F.J.M.Q;1s.1I(F.J.1w,{38:"11"!=e},$.V(G(s,o){U(F.J){F.1F.8X=s,F.1F.1B=s,F.3F=!0,F.2n=!1,F.2x();H n=F.3Z();F.1F.2i=n.2i.1g,F.1F.1q=n.1q.1g,F.1q=$("<5I>").2q({3k:F.J.1w}).N("I-1q I-1q-1p"),F.3g.T(F.1q),"11"==e&&F.1q.1x("8Y",G(i){i.2l()});H a;F.3g.T(a=$("<X>").N("I-1q-1p-1P")),F.3q&&a.T(F.3q.61());H h;"29"==F.J.M.Q&&((h=F.J.M.3K)&&"1K"==h||"1U-1K"==h)&&(F.J.M.2K||F.14==R.W.1n||F.3g.T($("<X>").N("I-3h-1l I-3h-1K").1b("1l","1K")),"1U-1K"!=h||F.J.M.2K||1==F.14||F.3g.T($("<X>").N("I-3h-1l I-3h-1U").1b("1l","1U")),F.3q&&F.3g.2z(".I-3h-1l").1h($.V(G(i,t){H e=$(t).1b("1l");$(t).3T(F.3q.61().1b("1l",e))},F)),F.1j.3p(".I-3h-1l","1V",G(i){H t=$(i.2D).1b("1l");R[t]()}),F.1j.3p(".I-3h-1l","8Z",$.V(G(i){H t=$(i.2D).1b("1l"),e=t&&F["2L"+t+"69"];e&&F["2L"+t+"69"].N("I-1l-1S-4t")},F)).3p(".I-3h-1l","90",$.V(G(i){H t=$(i.2D).1b("1l"),e=t&&F["2L"+t+"69"];e&&F["2L"+t+"69"].2A("I-1l-1S-4t")},F))),F.1j.2z(".I-7l-1p").1h($.V(G(i,t){H e=$("<5I>").N("I-7l-1p").2q({3k:F.J.1w}).17({bo:0}),s=$(t).1b("1l");o.38&&!26.2N&&e.1O(F.1q).1x("8Y",$.V(G(i){U("11"==F.J.M.Q)P i.2l(),2C 0;H t=i.3l,e=t.bp||{};U(o.38&&e.91){H s=t.34||0,n=t.35||0,a=F.1q.4T();s=13.3N(s-a.1u),n=13.3N(n-a.1y),1>o.4O&&(s*=o.4O,n*=o.4O),e.91(o.38,s,n)}24 e.92?e.92(F.1q[0]):i.2l()},F)),s&&e.1b("1l",s),$(t).bq(e)},F)),F.68(i,t)}},F));2O;1D"2a":H s={K:F.J.M.K,L:F.J.M.L};F.J.M.2a&&F.J.M.2a.6B&&(F.J.3i.93=s.K>br?"bs":"bt"),F.7r(s,i);2O;1D"1Q":H s={K:F.J.M.K,L:F.J.M.L};1s.1I(F.J.1w,$.V(G(t){U(F.J){H e=s.K,o=s.L,n=t.K,a=t.L,h=!1;(h=e&&!o||o&&!e)||e&&o?(h&&(e&&!o?s.L=e*a/n:s.K=o*n/a),s=3x.3y(t,{2M:s})):s=t,F.7r(s,i)}},F))}},F),10),2C 0)},7r:G(i,t){F.1F.8X=i,F.1F.1B=i,F.3F=!0,F.2n=!1,F.2x();H e=F.3Z();F.1F.2i=e.2i.1g,F.1F.1q=e.1q.1g,F.3g.T(F.1q=$("<X>").N("I-1q I-1q-"+F.J.Y)),"11"!=F.J.M.Q||"2a"!=F.J.Y&&"1Q"!=F.J.Y||(F.1L(),("2a"==F.J.Y&&16.5R||"1Q"==F.J.Y&&26.6G)&&F.1i()),F.68(t)},68:G(i){H t=F.J.M.Q;F.1L(),"2W"==t&&F.7n.1x("8Z",$.V(F.5b,F)).1x("90",$.V(F.6a,F)),F.Q&&(26.2N?F.25.1x("1V",$.V(G(){F.2j.2t(":1E")||F.5b(),F.5c()},F)):F.Q.3p(".I-Q-3f","5D",$.V(G(){F.2j.2t(":1E")||F.5b(),F.5c()},F)));H e;R.W&&(e=R.W[R.14-1])&&(e.J.1w==F.J.1w||"11"==e.J.M.Q)&&A.1N.1H(),i&&i()},1L:G(){U(F.1q){H i=F.3Z(),t=F.J.M.Q;F.1F.2i=i.2i.1g,F.1F.1q=i.1q.1g,F.4v.17(1e(i.2i.1g)),"2W"==t&&F.7m.17(1e(i.Q.2i.1g)),F.3g.1O(F.5Z).17(1e(i.1r.1g));H e=0;2E("29"==F.J.M.Q&&i.1z.1k&&(e=i.1z.L),F.5Z.17({"7s-94":e+"1e"}),F.7k.17(1e({K:i.3f.1g.K,L:i.3f.1g.L+e})),i.2i.1g.K>("29"==F.J.M.Q?i.25.1g.K:x.2I().K)?F.25.N("I-95-4e"):F.25.2A("I-95-4e"),t){1D"29":F.1k&&F.1z.17(1e({K:i.1z.K}));2O;1D"2W":F.2j.1O(F.7n).1O(F.8V).17(1e(i.Q.1r.1g)),F.60.17(1e(i.Q.3f.1g));H s=0;U(F.1k){H o=F.1j.40("I-2X-1k"),n=F.1j.40("I-2V-1k");F.1j.2A("I-2X-1k"),F.1j.N("I-2V-1k");H s=0;F.5X($.V(G(){s=F.1z.bu()},F),F.2j.1O(F.1k));H a=x.2I();(s>=.45*i.1r.1g.L||66>=a.L&&67>=a.K||66>=a.K&&67>=a.L)&&(i.1z.1k=!1),o&&F.1j.N("I-2X-1k"),n||F.1j.2A("I-2V-1k")}}U(F.1k){H h=i.1z.1k;F.1k[h?"1i":"19"](),F.1j[(h?"1R":"1O")+"4w"]("I-2X-1k"),F.1j[(h?"1O":"1R")+"4w"]("I-2V-1k")}F.7k.1O(F.60).17(1e(i.1r.2b));H r=R.21,d=F.1F.2i;U(F.6b={y:d.L-r.L,x:d.K-r.K},F.58=F.6b.x>0||F.6b.y>0,R[(F.58?"23":"1R")+"bv"](F.14),1a.1m&&8>1a.1m&&"1p"==F.J.Y&&F.1q.17(1e(i.1r.1g)),/^(1Q|2a)$/.6k(F.J.Y)){H u=i.1r.1g;F.3e?F.3e.bw(u.K,u.L):F.3r&&F.3r.2q(u)}}F.1v()},1v:G(){U(F.1q){H i=R.7g,t=R.21,e=F.1F.2i,s={1y:0,1u:0},o=F.6b;s.1y=o.y>0?0-i.y*o.y:.5*t.L-.5*e.L,s.1u=o.x>0?0-i.x*o.x:.5*t.K-.5*e.K,26.2N&&(o.y>0&&(s.1y=0),o.x>0&&(s.1u=0),F.4v.17({1v:"bx"})),F.by=s,F.4v.17({1y:s.1y+"1e",1u:s.1u+"1e"});H n=$.1f({},s);0>n.1y&&(n.1y=0),0>n.1u&&(n.1u=0);H a=F.J.M.Q;2E(a){1D"29":H h=F.3Z();U(F.25.17(1e(h.25.1g)).17(1e(h.25.1v)),F.J.1k){H r=s.1y+h.1r.2b.1y+h.1r.1g.L+F.65;r>R.21.L-h.1z.L&&(r=R.21.L-h.1z.L);H d=R.2S+s.1u+h.1r.2b.1u+F.65;R.2S>d&&(d=R.2S),d+h.1z.K>R.2S+h.25.1g.K&&(d=R.2S),F.1z.17({1y:r+"1e",1u:d+"1e"})}2O;1D"2W":F.7m.17({1u:n.1u+"1e",1y:n.1y+"1e"})}}},bz:G(i){F.1g=i},7c:G(){H i=1a.1m&&8>1a.1m,t=F.3Z(),e=t.1r.1g,s=$.1f({},F.J.M.2a||{}),o="4P"+(16.2P&&"4Q:"==16.2P.4R?"s":"")+":";U("11"==F.J.M.Q&&(s.5x=0),16.5R){H n;F.1q.T(F.5d=$("<X>").T(n=$("<X>")[0])),F.3e=1Y 5R.bA(n,{L:e.L,K:e.K,bB:F.J.3i.3o,bC:s,bD:i?{}:{bE:$.V(G(i){U(F.J.M.2a.6B)5p{i.2D.bF(F.J.3i.93)}5q(t){}F.1L()},F),bG:$.V(G(i){i.1b>-1&&(F.56=!0)},F)}})}24{H a=$.6Z(s);F.1q.T(F.3r=$("<96 98 99 9a>").2q({3k:o+"//bH.2a.3a/5M/"+F.J.3i.3o+"?"+a,L:e.L,K:e.K,9b:0}))}},7e:G(){H i=F.3Z(),t=i.1r.1g,e=$.1f({},F.J.M.1Q||{});"11"==F.J.M.Q&&(e.5x=0);H s="4P"+(16.2P&&"4Q:"==16.2P.4R?"s":"")+":",o=q()+"1Q";e.bI=o,e.4H=1;H n=$.6Z(e);F.1q.T(F.3r=$("<96 98 99 9a>").2q({3k:s+"//3e.1Q.3a/bJ/"+F.J.3i.3o+"?"+n,3o:o,L:t.L,K:t.K,9b:0})),16.bK&&$f(F.3r[0]).9c("9d",$.V(G(i){F.7d=$f(i).9c("bL",$.V(G(){F.56=!0},F))},F))},9e:G(){2E(F.J.Y){1D"2a":F.7c();2O;1D"1Q":F.7e()}},1i:G(i){U("11"==F.J.M.Q){U(F.9f)P i&&i(),2C 0;F.9f=!0}F.9e(),R.8N(F.14),F.1j.1H(1,0),F.Q&&(F.Q.1H(1,0),F.5b(1o,!0)),F.58&&R.8S(F.14),F.4l(1,13.1B(F.J.M.1t.1q.1i,1a.1m&&9>1a.1m?0:10),$.V(G(){i&&i()},F))},9g:G(){F.J&&F.1q&&"11"!=F.J.M.Q&&F.5S()},5S:G(){U(F.56=!1,F.3r&&(F.3r.1R(),F.3r=1o),F.3e){5p{F.3e.bM()}5q(i){}F.3e=1o}F.5d&&(F.5d.1R(),F.5d=1o),("2a"==F.J.Y||"1Q"==F.J.Y)&&(F.1q.64(""),F.5d=1o,F.3e=1o,F.3r=1o)},4n:G(i){R.7i(F.14),R.8P(F.14),F.9g(i)},19:G(i){U("11"==F.J.M.Q)P i&&i(),2C 0;H t=13.1B(F.J.M.1t.1q.19||0,1a.1m&&9>1a.1m?0:10),e=F.J.M.1t.1q.5t?"bN":"77";F.1j.1H(1,0).4V(t,e,$.V(G(){F.4n(),i&&i()},F))},4l:G(i,t,e){H s=F.J.M.1t.1q.5t?"bO":"5N";F.1j.1H(1,0).3S(t||0,i,s,e)},5b:G(i,t){F.Q&&(t?(F.2j.1i(),F.5c(),"G"==$.Y(i)&&i()):F.2j.1H(1,0).3S(t?0:F.J.M.1t.Q.1i,1,"5N",$.V(G(){F.5c(),"G"==$.Y(i)&&i()},F)))},6a:G(i,t){F.Q&&"29"!=F.J.M.Q&&(t?(F.2j.19(),"G"==$.Y(i)&&i()):F.2j.1H(1,0).4V(t?0:F.J.M.1t.Q.19,"77",G(){"G"==$.Y(i)&&i()}))},5Y:G(){F.5e&&(4X(F.5e),F.5e=1o)},5c:G(){F.5Y(),F.5e=4W($.V(G(){F.6a()},F),F.J.M.1t.Q.2J)},bP:G(){F.5Y(),F.5e=4W($.V(G(){F.6a()},F),F.J.M.1t.Q.2J)}}),$.1f(46.32,{1A:G(a){H b=1M[1]||{},d={};U("4S"==$.Y(a))a={1w:a};24 U(a&&1==a.7N){H c=$(a);a={12:c[0],1w:c.2q("4Y"),1k:c.1b("2f-1k"),4x:c.1b("2f-4x"),5f:c.1b("2f-5f"),Y:c.1b("2f-Y"),M:c.1b("2f-M")&&7t("({"+c.1b("2f-M")+"})")||{}}}U(a&&(a.5f||(a.5f=5s(a.1w)),!a.Y)){H d=4E(a.1w);a.3i=d,a.Y=d.Y}P a.3i||(a.3i=4E(a.1w)),a.M=a&&a.M?$.1f(!0,$.1f({},b),$.1f({},a.M)):$.1f({},b),a.M=z.6R(a.M,a.Y,a.3i),$.1f(F,a),F}});H C={1A:G(i){F.12=i,F.2c=[],F.1J={1d:{L:0,2U:0},1c:{L:0}},F.1c=F.12.2z(".I-1c:4r"),F.2s(),F.19(),F.3b()},2s:G(){F.1c.T(F.1r=$("<X>").N("I-1c-1r").T(F.5g=$("<X>").N("I-1c-5g").T(F.3X=$("<X>").N("I-1c-1l I-1c-1l-1U").T(F.62=$("<X>").N("I-1c-1l-1S").T($("<X>").N("I-1c-1l-1S-2w")).T($("<X>").N("I-1c-1l-1S-2F")))).T(F.41=$("<X>").N("I-1c-bQ").T(F.2Z=$("<X>").N("I-1c-2Z"))).T(F.3W=$("<X>").N("I-1c-1l I-1c-1l-1K").T(F.4u=$("<X>").N("I-1c-1l-1S").T($("<X>").N("I-1c-1l-1S-2w")).T($("<X>").N("I-1c-1l-1S-2F")))))),F.1L()},3b:G(){F.5g.3p(".I-1d","1V",$.V(G(i){i.2r();H t=$(i.2D).70(".I-1d")[0],e=-1;F.5g.2z(".I-1d").1h(G(i,s){s==t&&(e=i+1)}),e&&(F.7u(e),A.2G(e))},F)),F.5g.1x("1V",G(i){i.2r()}),F.3X.1x("1V",$.V(F.9h,F)),F.3W.1x("1V",$.V(F.9i,F))},28:G(i){U(F.2g(),F.2c=[],!(2>i.1n)){H t=!1;$.1h(i,$.V(G(i,e){P"11"==e.M.Q?(t=!0,!1):2C 0},F)),t||($.1h(i,$.V(G(i,t){F.2c.2h(1Y 6u(F.2Z,t,i+1))},F)),1a.1m&&7>1a.1m||F.1L())}},2g:G(){$.1h(F.2c,G(i,t){t.1R()}),F.2c=[],F.14=-1,F.3j=-1},2x:G(){H i=A.12,t=A.2Q,e=F.1J,s=i.2t(":1E");s||i.1i();H o=t.2t(":1E");o||t.1i();H n=F.1c.3M()-(4M(F.1c.17("7s-1y"))||0)-(4M(F.1c.17("7s-94"))||0);e.1d.L=n;H a=F.2Z.2z(".I-1d:4r"),h=!!a[0],r=0;h||F.41.T(a=$("<X>").N("I-1d").T($("<X>").N("I-1d-1r"))),r=4M(a.17("2b-1u")),h||a.1R(),e.1d.2U=n+2*r,e.1c.L=F.1c.3M(),e.3c={1U:F.3X.2U(!0),1K:F.3W.2U(!0)};H d=x.2I().K,u=e.1d.2U,p=F.2c.1n;e.3c.1W=p*u/d>1;H l=d,c=e.3c.1U+e.3c.1K;e.3c.1W&&(l-=c),l=13.4s(l/u)*u;H f=p*u;l>f&&(l=f);H m=l+(e.3c.1W?c:0);e.3G=l/u,F.5h="6c",1>=e.3G&&(l=d,m=d,e.3c.1W=!1,F.5h="6T"),e.7v=13.5i(p*u/l),e.1c.K=l,e.1r={K:m},o||t.19(),s||i.19()},3V:G(){F.4y=!0},4p:G(){F.4y=!1},1W:G(){P!F.4y},1i:G(){2>F.2c.1n||(F.4p(),F.1c.1i(),F.2H=!0)},19:G(){F.3V(),F.1c.19(),F.2H=!1},1E:G(){P!!F.2H},1L:G(){F.2x();H i=F.1J;$.1h(F.2c,G(i,t){t.1L()}),F.3X[i.3c.1W?"1i":"19"](),F.3W[i.3c.1W?"1i":"19"]();H t=i.1c.K;1a.1m&&9>1a.1m&&(A.3D.2g("9j-9k-1c"),A.3D.23("9j-9k-1c",$.V(G(){F.2x();H t=i.1c.K;F.41.17({K:t+"1e"}),F.2Z.17({K:F.2c.1n*i.1d.2U+1+"1e"})},F),bR)),F.41.17({K:t+"1e"}),F.2Z.17({K:F.2c.1n*i.1d.2U+1+"1e"});H e=i.1r.K+1;U(F.1r.17({K:e+"1e","2b-1u":-.5*e+"1e"}),F.3X.1O(F.3W).17({L:i.1d.L+"1e"}),F.14&&F.3d(F.14,!0),1a.1m&&9>1a.1m){H s=A.12,o=A.2Q,n=s.2t(":1E");n||s.1i();H a=o.2t(":1E");a||o.1i(),F.41.L("7B%"),F.41.17({L:F.41.3M()+"1e"}),F.1c.2z(".I-1d-1P-3m").19(),a||o.19(),n||s.19()}},7w:G(i){U(!(1>i||i>F.1J.7v||i==F.3j)){H t=F.1J.3G*(i-1)+1;F.3d(t)}},9h:G(){F.7w(F.3j-1)},9i:G(){F.7w(F.3j+1)},bS:G(){H i=x.2I();P i},2G:G(i){U(!(1a.1m&&7>1a.1m)){H t=0>F.14;1>i&&(i=1);H e=F.2c.1n;i>e&&(i=e),F.14=i,F.7u(i),("6c"!=F.5h||F.3j!=13.5i(i/F.1J.3G))&&F.3d(i,t)}},3d:G(i,t){F.2x();H e,s=x.2I().K,o=.5*s,n=F.1J.1d.2U;U("6c"==F.5h){H a=13.5i(i/F.1J.3G);F.3j=a,e=-1*n*(F.3j-1)*F.1J.3G;H h="I-1c-1l-1S-59";F.62[(2>a?"1O":"1R")+"4w"](h),F.4u[(a>=F.1J.7v?"1O":"1R")+"4w"](h)}24 e=o+-1*(n*(i-1)+.5*n);H r=R.W&&R.W[R.14-1];F.2Z.1H(1,0).5T({1u:e+"1e"},t?0:r?r.J.M.1t.1c.2Z:0,$.V(G(){F.9l()},F))},9l:G(){H i,t;U(F.14&&F.1J.1d.2U&&!(1>F.2c.1n)){U("6c"==F.5h){U(1>F.3j)P;i=(F.3j-1)*F.1J.3G+1,t=13.2e(i-1+F.1J.3G,F.2c.1n)}24{H e=13.5i(x.2I().K/F.1J.1d.2U);i=13.1B(13.4s(13.1B(F.14-.5*e,0)),1),t=13.5i(13.2e(F.14+.5*e)),t>F.2c.1n&&(t=F.2c.1n)}1X(H s=i;t>=s;s++)F.2c[s-1].28()}},7u:G(i){$.1h(F.2c,G(i,t){t.9m()});H t=i&&F.2c[i-1];t&&t.9n()},bT:G(){F.14&&F.2G(F.14)}};$.1f(6u.32,{1A:G(i,t,e){F.12=i,F.J=t,F.bU={},F.14=e,F.2s()},2s:G(){H i=F.J.M;F.12.T(F.1d=$("<X>").N("I-1d").T(F.9o=$("<X>").N("I-1d-1r"))),"1p"==F.J.Y&&F.1d.N("I-28-1d").1b("1d",{J:F.J,3k:i.1d||F.J.1w});H t=i.1d&&i.1d.2F;t&&F.1d.T($("<X>").N("I-1d-2F I-1d-2F-"+t));H e;F.1d.T(e=$("<X>").N("I-1d-1P").T($("<X>").N("I-1d-1P-2w")).T(F.1N=$("<X>").N("I-1d-1N").T($("<X>").N("I-1d-1N-2w")).T($("<X>").N("I-1d-1N-2F"))).T($("<X>").N("I-1d-1P-3m"))),F.1d.T($("<X>").N("I-1d-bV"))},1R:G(){F.1d.1R(),F.1d=1o,F.bW=1o,F.2n=!1},28:G(){U(!F.3F&&!F.2n&&C.1E()){F.2n=!0;H i=F.J.M.1d,t=i&&"6P"==$.Y(i)?F.J.1w:i||F.J.1w;U(F.4z=t,t)U("1Q"==F.J.Y)U(t==i)1s.3L(F.4z,{Y:"1p"},$.V(F.6d,F));24{H e="4P"+(16.2P&&"4Q:"==16.2P.4R?"s":"")+":";$.8a(e+"//1Q.3a/4H/8b.8c?1w="+e+"//1Q.3a/"+F.J.3i.3o+"&4f=?",$.V(G(i){i&&i.9p?(F.4z=i.9p,1s.3L(F.4z,{Y:"1p"},$.V(F.6d,F))):(F.3F=!0,F.2n=!1,F.1N.1H(1,0).2J(F.J.M.1t.1c.2J).3S(F.J.M.1t.1c.28,0))},F))}24 1s.3L(F.4z,{Y:"1p"},$.V(F.6d,F))}},6d:G(i){F.1d&&F.2n&&(F.3F=!0,F.2n=!1,F.1F=i,F.1p=$("<5I>").2q({3k:F.4z}),F.9o.3T(F.1p),F.1L(),F.1N.1H(1,0).2J(F.J.M.1t.1c.2J).3S(F.J.M.1t.1c.28,0))},1L:G(){H i=C.1J.1d.L;U(F.1d.17({K:i+"1e",L:i+"1e"}),F.1p){H t,e={K:i,L:i},s=13.1B(e.K,e.L),o=$.1f({},F.1F);U(o.K>e.K&&o.L>e.L){t=3x.3y(o,{2M:e});H n=1,a=1;t.K<e.K&&(n=e.K/t.K),t.L<e.L&&(a=e.L/t.L);H h=13.1B(n,a);h>1&&(t.K*=h,t.L*=h),$.1h("K L".3t(" "),G(i,e){t[e]=13.3N(t[e])})}24 t=3x.3y(o.K<e.K||o.L<e.L?{K:s,L:s}:e,{2M:F.1F});H r=13.3N(.5*e.K-.5*t.K),d=13.3N(.5*e.L-.5*t.L);F.1p.17(1e(t)).17(1e({1y:d,1u:r}))}},9n:G(){F.1d.N("I-1d-4t")},9m:G(){F.1d.2A("I-1d-4t")}});H D={1A:G(i){F.12=i,F.6e=[],F.6f=!1,F.1J={1r:{}},F.1T=F.12.2z(".I-11:4r"),F.2s(),F.19(),F.3b()},2s:G(){F.1T.T(F.1r=$("<X>").N("I-11-1r").T(F.bX=$("<X>").N("I-11-2w")).T(F.1z=$("<X>").N("I-11-1z").T(F.63=$("<X>").N("I-11-1z-3f").T(F.bY=$("<X>").N("I-11-1k-1r").T(F.1k=$("<X>").N("I-11-1k"))))).T(F.1Z=$("<X>").N("I-11-1S I-11-1Z").T($("<3Y>").N("I-11-1S-2w")).T($("<3Y>").N("I-11-1S-2F"))).T(F.4A=$("<X>").N("I-11-1S I-11-4A").T($("<3Y>").N("I-11-1S-2w")).T($("<3Y>").N("I-11-1S-2F"))))},3b:G(){F.1Z.1x("1V",G(){A.19()}),$(16).1x("1L 8A",$.V(G(){A.2y.1I("1E")&&F.1L()},F)),F.4A.1x("1V",$.V(G(){F[F.6f?"6g":"9q"]()},F)),F.1T.1x("4b",$.V(G(i){F.6h||i.2l()},F))},1i:G(){F.4p(),F.1T.1i(),F.2H=!0},19:G(){F.3V(),F.1T.19(),F.2H=!1},1E:G(){P!!F.2H},2x:G(){H i=A.12,t=A.2Q,e=F.1J;F.1T.17({2R:"8q"});H s=F.4A.1O(F.1Z);$.1h(s,$.V(G(i,t){H e=$(t);e.1b("9r-2b-1y",e.17("2b-1y")),e.17({"2b-1y":0})},F));H o=i.2t(":1E");o||i.1i();H n=t.2t(":1E");n||t.1i();H a=F.9s();a&&F.3s(!1);H h=F.1T.3M();a&&F.3s(!0),e.1r.L=h,a||F.3s(!0);H r=F.1T.3M(),d=r>h;e.42=d,a&&F.3s(!0),d&&(F.3s(!0),r=F.1T.3M()),e.1r.7x=r,F.3s(a),$.1h(s,$.V(G(i,t){H e=$(t);e.17({"2b-1y":e.1b("9r-2b-1y")})},F)),F.1T.17({2R:"1E"}),n||t.19(),o||i.19()},bZ:G(){P F.1T.40("I-11-9t")},7y:G(i){F.1T[(i?"1O":"1R")+"4w"]("I-11-9t")},9s:G(){P F.1T.40("I-11-42")},3s:G(i){F.1T[(i?"1O":"1R")+"4w"]("I-11-42")},3V:G(){F.4y=!0},4p:G(){F.4y=!1},1W:G(){P!F.4y},28:G(i){F.2g(),$.1h(i,$.V(G(i,t){F.6e.2h(t)},F))},2g:G(){F.6e=[],F.J=1o,F.14=-1,F.3j=-1},2G:G(i){U(i!=F.14){H t=F.6e[i-1];U("11"==t.M.Q){F.J=t;H e=t.1k||"";F.1k.64(e),F.1L(),F.6g(!0)}}},1L:G(){F.6g(!0),F.2x()},9q:G(i){F.3s(!0),F.7y(!0),F.6f=!0,F.4A.N("I-11-9u");H t=x.2I(),e=-1*13.2e(t.L,F.1J.1r.7x||0);F.1J.1r.7x>t.L?(F.1z.17({L:t.L+"1e"}).N("I-11-42-4m"),F.6h=!0):(F.1z.17({L:"9v"}).2A("I-11-42-4m"),F.6h=!1),F.1T.1H(1,0).5T({"2b-1y":e+"1e"},{7f:i?0:F.J.M.1t.1T.7G})},6g:G(i){F.6f=!1,F.4A.2A("I-11-9u"),F.1z.4U(0),F.1z.17({L:"9v"}).2A("I-11-42-4m"),F.6h=!1,F.1T.1H(1,0).5T({"2b-1y":-1*(F.1J.1r.L||0)+"1e"},{7f:i?0:F.J.M.1t.1T.7H,8I:$.V(G(){F.3s(!1),F.7y(F.1J.42)},F)})}},5L={1i:G(b){H c=1M[1]||{},1v=1M[2];1M[1]&&"c0"==$.Y(1M[1])&&(1v=1M[1],c=z.6R({}));H d=[],9w;2E(9w=$.Y(b)){1D"4S":1D"6Y":H f=1Y 46(b,c),5j="1b-2f-4x-M";U(f.4x){U(2L.5z(b)){H g=$(\'.2f[1b-2f-4x="\'+$(b).1b("2f-4x")+\'"]\'),h={};g.c1("["+5j+"]").1h(G(i,a){$.1f(h,7t("({"+($(a).2q(5j)||"")+"})"))}),g.1h(G(i,t){1v||t!=b||(1v=i+1),d.2h(1Y 46(t,$.1f({},h,c)))})}}24{H h={};2L.5z(b)&&$(b).2t("["+5j+"]")&&($.1f(h,7t("({"+($(b).2q(5j)||"")+"})")),f=1Y 46(b,$.1f({},h,c))),d.2h(f)}2O;1D"9x":$.1h(b,G(i,t){H e=1Y 46(t,c);d.2h(e)})}(!1v||1>1v)&&(1v=1),1v>d.1n&&(1v=d.1n),R.7g||R.3E({x:0,y:0}),A.28(d,1v,{4f:G(){A.1i(G(){})}})}};$.1f(j,{1A:G(){y.81("22"),A.1A()},1i:G(){5L.1i.2B(5L,k.2k(1M))},19:G(){A.19()},6X:G(i){A.6X(i)}}),(1a.3z&&3>1a.3z||1a.4K&&1a.49&&8h.18>1a.49)&&(j.1i=G(){G i(t){H e,s=$.Y(t);U("4S"==s)e=t;24 U("9x"==s&&t[0])e=i(t[0]);24 U(2L.5z(t)&&$(t).2q("4Y"))H e=$(t).2q("4Y");24 e=t.1w?t.1w:!1;P e}P G(t){H e=i(t);e&&(16.2P.4Y=e)}}());H E={1p:{9y:"c2 c3 6H 8e 7D",4B:G(i){P $.5V(5s(i),F.9y.3t(" "))>-1},1b:G(i){P F.4B()?{5f:5s(i)}:!1}},2a:{4B:G(i){H t=/(2a\\.3a|9z\\.be)\\/c4\\?(?=.*6Q?=([a-5m-7z-9-2L]+))(?:\\S+)?$/.5B(i);P t&&t[2]?t[2]:(t=/(2a\\.3a|9z\\.be)\\/(6Q?\\/|u\\/|5M\\/)?([a-5m-7z-9-2L]+)(?:\\S+)?$/i.5B(i),t&&t[3]?t[3]:!1)},1b:G(i){H t=F.4B(i);P t?{3o:t}:!1}},1Q:{4B:G(i){H t=/(1Q\\.3a)\\/([a-5m-7z-9-2L]+)(?:\\S+)?$/i.5B(i);P t&&t[2]?t[2]:!1},1b:G(i){H t=F.4B(i);P t?{3o:t}:!1}}};$(2o).9d(G(){j.1A()}),16.6x=j})(22);',62,749,'|||||||||||||||||||||||||||||||||||||||||this|function|var|fr|view|width|height|options|addClass||return|ui|Frames||append|if|proxy|_frames|div|type|||touch|element|Math|_position||window|css||hide|Browser|data|thumbnails|thumbnail|px|extend|dimensions|each|show|frame|caption|side|IE|length|null|image|content|wrapper|Dimensions|effects|left|position|url|bind|top|info|initialize|max|cache|case|visible|_dimensions|move|stop|get|_vars|next|resize|arguments|loading|add|overlay|vimeo|remove|button|touchCaption|previous|click|enabled|for|new|close||_boxDimensions|jQuery|set|else|box|Support||load|outside|youtube|margin|_thumbnails||min|fresco|clear|push|spacer|ui_wrapper|call|preventDefault|className|_loading|document|frames|attr|stopPropagation|build|is|_timeouts|fit|background|updateVars|states|find|removeClass|apply|void|target|switch|icon|setPosition|_visible|viewport|delay|loop|_|bounds|mobileTouch|break|location|bubble|visibility|_sideWidth|_tracking|outerWidth|has|inside|no|portrait|slide||controls|prototype|indexOf|pageX|pageY|||dragImage||com|startObserving|sides|moveTo|player|padder|box_wrapper|onclick|_data|_page|src|originalEvent|border|Touch|id|delegate|download_image|player_iframe|setOverflowClass|split|deepExtendClone|vertical|easing|Fit|within|Android|style|preloaded|queues|timeouts|setXY|_loaded|ipp|landscape|onload|skins|onClick|preload|innerHeight|round|scripts|start|track|skin|fadeTo|prepend|queue|disable|_next|_previous|span|getLayout|hasClass|_thumbs|overflow|200|Loading||View|right|horizontal|WebKit|_events|touchmove|abs|unbind|swipe|callback|delete|defaultSkin|Window|setExpression|setSkin|setOpacity|scroll|_reset|views|enable|_preloaded|first|floor|active|_next_button|box_spacer|Class|group|_disabled|_url|more|detect|in|canvas|getURIData|both|none|api|body|documentElement|MobileSafari|parseFloat|parseInt|end|dragScale|http|https|protocol|string|offset|scrollTop|fadeOut|setTimeout|clearTimeout|href|overlapping||_m|keyCode|updateDimensions|_handleTracking||_playing|getSurroundingIndexes|_track|disabled|_loadTimer|showUI|startUITimer|player_div|_ui_timer|extension|slider|_mode|ceil|_dgo|getOrientation|String|zA|substr|warn|try|catch|deepExtend|detectExtension|sync|touchEffects|keyboard|esc|autoplay|initialTypeOptions|isElement|mousewheel|exec|IEMobile|mousemove|touchstart|touchend|touches|xhr|img|scrollLeft|_count|_Fresco|embed|easeInSine|setOrientation|isTouch|_tracking_timer|YT|_removeVideo|animate|afterPosition|inArray|_touchWidth|_whileVisible|clearUITimer|box_outer_border|ui_padder|clone|_previous_button|info_padder|html|_border|320|568|afterLoad|_button|hideUI|overlap|page|_afterLoad|_views|_expanded|collapse|_scrolling|sfcc|rs|test|console|createDragImage|Image|getContext|toDataURL|Overlay|Timeouts|States|Frame|Thumbnail|match|toLowerCase|Fresco|version|300|250|hd|Opera|opera|Chrome|createElement|postMessage|jpeg|required|available|Date|getTime|scrollSupressionThreshold|Cache|once|boolean|vi|create|absolute|center|draw|_states|showhide|setDefaultSkin|object|param|closest|stopQueues|_hide|after|before||_s|easeOutSine|fetchOptions|getKeyByKeyCode|updateMove|_touched|insertYoutubeVideo|froogaloop|insertVimeoVideo|duration|_xyp|_pos|removeTracking|clearLoad|box_padder|download|ui_spacer|ui_outer_border|_getInfoHeight|_fit|clearLoadTimer|_movieLoaded|padding|eval|setActive|pages|moveToPage|overflowHeight|setPaddedClass|Z0|fromCharCode|100|canvasToDataUrlPNG|png|constructor|base|slideOut|slideIn|175|spacing|640|reset|IE6|nodeType|parentNode|wheelDelta|detail|pow|AppleWebKit|Gecko|ChromeMobile|CrMo|navigator|prefix|toUpperCase|DocumentTouch|pointerEvents|check|Za|notified|durationThreshold|horizontalDistanceThreshold|verticalDistanceThreshold|direction|swiped|supressX|getJSON|oembed|json|getDimensions|jpg|easeInOutSine|getScrollDimensions|533|timeout_|update|class|skinless|hideOverlapping|wmode|value|transparent|hidden|restoreOverlapping|onShow|_show|hideAll|afterHide|unbindTouch|onkeydown|onkeyup|uis|orientationchange|original|removeAttr|handleTracking|clearTrackingTimer|startTracking|stopTracking|playing|complete|clearLoads|preloadSurroundingImages|mayPrevious|mayNext|setVisible|isVisible|setHidden|grep|setXYP|setTracking|isTracking|outer|ui_toggle|_spacing|_max|dragstart|mouseenter|mouseleave|setDragImage|addElement|quality|bottom|prevent|iframe||webkitAllowFullScreen|mozallowfullscreen|allowFullScreen|frameborder|addEvent|ready|_preShow|_shown|_postHide|previousPage|nextPage|ie|resizing|loadCurrentPage|deactivate|activate|thumbnail_wrapper|thumbnail_url|expand|restore|hasOverflowClass|padded|less|auto|object_type|array|extensions|youtu|114|110|111|109|toString|log|globalAlpha|drawImage|Object|replace|350|440|180|3e3|5e3|title|byline|enablejsapi|iv_load_policy|modestbranding|rel|360|Array|slice|isAttached|120|Event|trigger|isPropagationStopped|isDefaultPrevented|DOMMouseScroll|Quad|Cubic|Quart|Quint|Expo|Sine|cos|PI|easeIn|easeOut|easeInOut|innerWidth|RegExp|attachEvent|MSIE|KHTML|rv|Apple|Mobile|Safari|userAgent|charAt|join|Webkit|Moz|ms|Khtml|ontouchstart|instanceof|prefixed|Win|Mac|Linux|platform|fn|jquery|z_|z0|requires|mousedown|mouseup|suppresX|suppresY|125|stopImmediatePropagation|one|supressY|1e3|removeData|lifetime|3e5|inject|abort|dela|setOptions|oldIE|ltIE|mobile|currentTarget|select|name|restoreOverlappingWithinContent|fs|150|_pinchZoomed|keydown|keyup|bindTouch|_startMoveTime|stopVideo|unload||pn|hideAllBut|clearTracking|_scrollbarWidth|scrollbarWidth|toggle|info_background|text|smart|opacity|dataTransfer|replaceWith|720|hd1080|hd720|outerHeight|Tracking|setSize|relative|_style|setDimensions|Player|videoId|playerVars|events|onReady|setPlaybackQuality|onStateChange|www|player_id|video|Froogaloop|play|destroy|easeInQuad|easeOutQuart|hideUIDelayed|thumbs|500|adjustToViewport|refresh|_dimension|state|thumbnail_image|drag|caption_wrapper|hasPaddedClass|number|filter|bmp|gif|watch'.split('|'),0,{}));
/*
 * Foundation Responsive Library
 * http://foundation.zurb.com
 * Copyright 2013, ZURB
 * Free to use under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
*/

/*jslint unparam: true, browser: true, indent: 2 */

// Accommodate running jQuery or Zepto in noConflict() mode by
// using an anonymous function to redefine the $ shorthand name.
// See http://docs.jquery.com/Using_jQuery_with_Other_Libraries
// and http://zeptojs.com/
var libFuncName = null;

if (typeof jQuery === "undefined" &&
    typeof Zepto === "undefined" &&
    typeof $ === "function") {
  libFuncName = $;
} else if (typeof jQuery === "function") {
  libFuncName = jQuery;
} else if (typeof Zepto === "function") {
  libFuncName = Zepto;
} else {
  throw new TypeError();
}

(function ($, window, document, undefined) {
  'use strict';

  /*
    matchMedia() polyfill - Test a CSS media 
    type/query in JS. Authors & copyright (c) 2012: 
    Scott Jehl, Paul Irish, Nicholas Zakas. 
    Dual MIT/BSD license

    https://github.com/paulirish/matchMedia.js
  */

   $('head').append('<meta class="foundation-mq-small">');
   $('head').append('<meta class="foundation-mq-medium">');
   $('head').append('<meta class="foundation-mq-large">');

  window.matchMedia = window.matchMedia || (function( doc, undefined ) {

    "use strict";

    var bool,
        docElem = doc.documentElement,
        refNode = docElem.firstElementChild || docElem.firstChild,
        // fakeBody required for <FF4 when executed in <head>
        fakeBody = doc.createElement( "body" ),
        div = doc.createElement( "div" );

    div.id = "mq-test-1";
    div.style.cssText = "position:absolute;top:-100em";
    fakeBody.style.background = "none";
    fakeBody.appendChild(div);

    return function(q){

      div.innerHTML = "&shy;<style media=\"" + q + "\"> #mq-test-1 { width: 42px; }</style>";

      docElem.insertBefore( fakeBody, refNode );
      bool = div.offsetWidth === 42;
      docElem.removeChild( fakeBody );

      return {
        matches: bool,
        media: q
      };

    };

  }( document ));

  // add dusty browser stuff
  if (!Array.prototype.filter) {
    Array.prototype.filter = function(fun /*, thisp */) {
      "use strict";
   
      if (this == null) {
        throw new TypeError();
      }

      var t = Object(this),
          len = t.length >>> 0;
      if (typeof fun !== "function") {
          return;
      }

      var res = [],
          thisp = arguments[1];
      for (var i = 0; i < len; i++) {
        if (i in t) {
          var val = t[i]; // in case fun mutates this
          if (fun && fun.call(thisp, val, i, t)) {
            res.push(val);
          }
        }
      }

      return res;
    }
  }

  if (!Function.prototype.bind) {
    Function.prototype.bind = function (oThis) {
      if (typeof this !== "function") {
        // closest thing possible to the ECMAScript 5 internal IsCallable function
        throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
      }
   
      var aArgs = Array.prototype.slice.call(arguments, 1), 
          fToBind = this, 
          fNOP = function () {},
          fBound = function () {
            return fToBind.apply(this instanceof fNOP && oThis
               ? this
               : oThis,
             aArgs.concat(Array.prototype.slice.call(arguments)));
          };
   
      fNOP.prototype = this.prototype;
      fBound.prototype = new fNOP();
   
      return fBound;
    };
  }

  if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (searchElement /*, fromIndex */ ) {
      "use strict";
      if (this == null) {
        throw new TypeError();
      }
      var t = Object(this);
      var len = t.length >>> 0;
      if (len === 0) {
        return -1;
      }
      var n = 0;
      if (arguments.length > 1) {
        n = Number(arguments[1]);
        if (n != n) { // shortcut for verifying if it's NaN
          n = 0;
        } else if (n != 0 && n != Infinity && n != -Infinity) {
          n = (n > 0 || -1) * Math.floor(Math.abs(n));
        }
      }
      if (n >= len) {
          return -1;
      }
      var k = n >= 0 ? n : Math.max(len - Math.abs(n), 0);
      for (; k < len; k++) {
        if (k in t && t[k] === searchElement) {
          return k;
        }
      }
      return -1;
    }
  }

  // fake stop() for zepto.
  $.fn.stop = $.fn.stop || function() {
    return this;
  };

  window.Foundation = {
    name : 'Foundation',

    version : '4.3.2',

    cache : {},

    media_queries : {
      small : $('.foundation-mq-small').css('font-family').replace(/\'/g, ''),
      medium : $('.foundation-mq-medium').css('font-family').replace(/\'/g, ''),
      large : $('.foundation-mq-large').css('font-family').replace(/\'/g, '')
    },

    stylesheet : $('<style></style>').appendTo('head')[0].sheet,

    init : function (scope, libraries, method, options, response, /* internal */ nc) {
      var library_arr,
          args = [scope, method, options, response],
          responses = [],
          nc = nc || false;

      // disable library error catching,
      // used for development only
      if (nc) this.nc = nc;

      // check RTL
      this.rtl = /rtl/i.test($('html').attr('dir'));

      // set foundation global scope
      this.scope = scope || this.scope;

      if (libraries && typeof libraries === 'string' && !/reflow/i.test(libraries)) {
        if (/off/i.test(libraries)) return this.off();

        library_arr = libraries.split(' ');

        if (library_arr.length > 0) {
          for (var i = library_arr.length - 1; i >= 0; i--) {
            responses.push(this.init_lib(library_arr[i], args));
          }
        }
      } else {
        if (/reflow/i.test(libraries)) args[1] = 'reflow';

        for (var lib in this.libs) {
          responses.push(this.init_lib(lib, args));
        }
      }

      // if first argument is callback, add to args
      if (typeof libraries === 'function') {
        args.unshift(libraries);
      }

      return this.response_obj(responses, args);
    },

    response_obj : function (response_arr, args) {
      for (var i = 0, len = args.length; i < len; i++) {
        if (typeof args[i] === 'function') {
          return args[i]({
            errors: response_arr.filter(function (s) {
              if (typeof s === 'string') return s;
            })
          });
        }
      }

      return response_arr;
    },

    init_lib : function (lib, args) {
      return this.trap(function () {
        if (this.libs.hasOwnProperty(lib)) {
          this.patch(this.libs[lib]);
          return this.libs[lib].init.apply(this.libs[lib], args);
        } else {
          return function () {};
        }
      }.bind(this), lib);
    },

    trap : function (fun, lib) {
      if (!this.nc) {
        try {
          return fun();
        } catch (e) {
          return this.error({name: lib, message: 'could not be initialized', more: e.name + ' ' + e.message});
        }
      }

      return fun();
    },

    patch : function (lib) {
      this.fix_outer(lib);
      lib.scope = this.scope;
      lib.rtl = this.rtl;
    },

    inherit : function (scope, methods) {
      var methods_arr = methods.split(' ');

      for (var i = methods_arr.length - 1; i >= 0; i--) {
        if (this.lib_methods.hasOwnProperty(methods_arr[i])) {
          this.libs[scope.name][methods_arr[i]] = this.lib_methods[methods_arr[i]];
        }
      }
    },

    random_str : function (length) {
      var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');

      if (!length) {
        length = Math.floor(Math.random() * chars.length);
      }

      var str = '';
      for (var i = 0; i < length; i++) {
        str += chars[Math.floor(Math.random() * chars.length)];
      }
      return str;
    },

    libs : {},

    // methods that can be inherited in libraries
    lib_methods : {
      set_data : function (node, data) {
        // this.name references the name of the library calling this method
        var id = [this.name,+new Date(),Foundation.random_str(5)].join('-');

        Foundation.cache[id] = data;
        node.attr('data-' + this.name + '-id', id);
        return data;
      },

      get_data : function (node) {
        return Foundation.cache[node.attr('data-' + this.name + '-id')];
      },

      remove_data : function (node) {
        if (node) {
          delete Foundation.cache[node.attr('data-' + this.name + '-id')];
          node.attr('data-' + this.name + '-id', '');
        } else {
          $('[data-' + this.name + '-id]').each(function () {
            delete Foundation.cache[$(this).attr('data-' + this.name + '-id')];
            $(this).attr('data-' + this.name + '-id', '');
          });
        }
      },

      throttle : function(fun, delay) {
        var timer = null;
        return function () {
          var context = this, args = arguments;
          clearTimeout(timer);
          timer = setTimeout(function () {
            fun.apply(context, args);
          }, delay);
        };
      },

      // parses data-options attribute on nodes and turns
      // them into an object
      data_options : function (el) {
        var opts = {}, ii, p,
            opts_arr = (el.attr('data-options') || ':').split(';'),
            opts_len = opts_arr.length;

        function isNumber (o) {
          return ! isNaN (o-0) && o !== null && o !== "" && o !== false && o !== true;
        }

        function trim(str) {
          if (typeof str === 'string') return $.trim(str);
          return str;
        }

        // parse options
        for (ii = opts_len - 1; ii >= 0; ii--) {
          p = opts_arr[ii].split(':');

          if (/true/i.test(p[1])) p[1] = true;
          if (/false/i.test(p[1])) p[1] = false;
          if (isNumber(p[1])) p[1] = parseInt(p[1], 10);

          if (p.length === 2 && p[0].length > 0) {
            opts[trim(p[0])] = trim(p[1]);
          }
        }

        return opts;
      },

      delay : function (fun, delay) {
        return setTimeout(fun, delay);
      },

      // animated scrolling
      scrollTo : function (el, to, duration) {
        if (duration < 0) return;
        var difference = to - $(window).scrollTop();
        var perTick = difference / duration * 10;

        this.scrollToTimerCache = setTimeout(function() {
          if (!isNaN(parseInt(perTick, 10))) {
            window.scrollTo(0, $(window).scrollTop() + perTick);
            this.scrollTo(el, to, duration - 10);
          }
        }.bind(this), 10);
      },

      // not supported in core Zepto
      scrollLeft : function (el) {
        if (!el.length) return;
        return ('scrollLeft' in el[0]) ? el[0].scrollLeft : el[0].pageXOffset;
      },

      // test for empty object or array
      empty : function (obj) {
        if (obj.length && obj.length > 0)    return false;
        if (obj.length && obj.length === 0)  return true;

        for (var key in obj) {
          if (hasOwnProperty.call(obj, key))    return false;
        }

        return true;
      },

      addCustomRule : function(rule, media) {
        if(media === undefined) {
          Foundation.stylesheet.insertRule(rule, Foundation.stylesheet.cssRules.length);
        } else {
          var query = Foundation.media_queries[media];
          if(query !== undefined) {
            Foundation.stylesheet.insertRule('@media ' + 
              Foundation.media_queries[media] + '{ ' + rule + ' }');
          }
        }
      }
    },

    fix_outer : function (lib) {
      lib.outerHeight = function (el, bool) {
        if (typeof Zepto === 'function') {
          return el.height();
        }

        if (typeof bool !== 'undefined') {
          return el.outerHeight(bool);
        }

        return el.outerHeight();
      };

      lib.outerWidth = function (el, bool) {
        if (typeof Zepto === 'function') {
          return el.width();
        }

        if (typeof bool !== 'undefined') {
          return el.outerWidth(bool);
        }

        return el.outerWidth();
      };
    },

    error : function (error) {
      return error.name + ' ' + error.message + '; ' + error.more;
    },

    // remove all foundation events.
    off: function () {
      $(this.scope).off('.fndtn');
      $(window).off('.fndtn');
      return true;
    },

    zj : $
  };

  $.fn.foundation = function () {
    var args = Array.prototype.slice.call(arguments, 0);

    return this.each(function () {
      Foundation.init.apply(Foundation, [this].concat(args));
      return this;
    });
  };

}(libFuncName, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.alerts = {
    name : 'alerts',

    version : '4.3.2',

    settings : {
      animation: 'fadeOut',
      speed: 300, // fade out speed
      callback: function (){}
    },

    init : function (scope, method, options) {
      this.scope = scope || this.scope;
      Foundation.inherit(this, 'data_options');

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      if (typeof method !== 'string') {
        if (!this.settings.init) { this.events(); }

        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;

      $(this.scope).on('click.fndtn.alerts', '[data-alert] a.close', function (e) {
          var alertBox = $(this).closest("[data-alert]"),
              settings = $.extend({}, self.settings, self.data_options(alertBox));

        e.preventDefault();
        alertBox[settings.animation](settings.speed, function () {
          $(this).remove();
          settings.callback();
        });
      });

      this.settings.init = true;
    },

    off : function () {
      $(this.scope).off('.fndtn.alerts');
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.clearing = {
    name : 'clearing',

    version: '4.3.2',

    settings : {
      templates : {
        viewing : '<a href="#" class="clearing-close">&times;</a>' +
          '<div class="visible-img" style="display: none"><img src="//:0">' +
          '<p class="clearing-caption"></p><a href="#" class="clearing-main-prev"><span></span></a>' +
          '<a href="#" class="clearing-main-next"><span></span></a></div>'
      },

      // comma delimited list of selectors that, on click, will close clearing,
      // add 'div.clearing-blackout, div.visible-img' to close on background click
      close_selectors : '.clearing-close',

      // event initializers and locks
      init : false,
      locked : false
    },

    init : function (scope, method, options) {
      var self = this;
      Foundation.inherit(this, 'set_data get_data remove_data throttle data_options');

      if (typeof method === 'object') {
        options = $.extend(true, this.settings, method);
      }

      if (typeof method !== 'string') {
        $(this.scope).find('ul[data-clearing]').each(function () {
          var $el = $(this),
              options = options || {},
              lis = $el.find('li'),
              settings = self.get_data($el);

          if (!settings && lis.length > 0) {
            options.$parent = $el.parent();

            self.set_data($el, $.extend({}, self.settings, options, self.data_options($el)));

            self.assemble($el.find('li'));

            if (!self.settings.init) {
              self.events().swipe_events();
            }
          }
        });

        return this.settings.init;
      } else {
        // fire method
        return this[method].call(this, options);
      }
    },

    // event binding and initial setup

    events : function () {
      var self = this;

      $(this.scope)
        .on('click.fndtn.clearing', 'ul[data-clearing] li',
          function (e, current, target) {
            var current = current || $(this),
                target = target || current,
                next = current.next('li'),
                settings = self.get_data(current.parent()),
                image = $(e.target);

            e.preventDefault();
            if (!settings) self.init();

            // if clearing is open and the current image is
            // clicked, go to the next image in sequence
            if (target.hasClass('visible') && 
              current[0] === target[0] && 
              next.length > 0 && self.is_open(current)) {
              target = next;
              image = target.find('img');
            }

            // set current and target to the clicked li if not otherwise defined.
            self.open(image, current, target);
            self.update_paddles(target);
          })

        .on('click.fndtn.clearing', '.clearing-main-next',
          function (e) { this.nav(e, 'next') }.bind(this))
        .on('click.fndtn.clearing', '.clearing-main-prev',
          function (e) { this.nav(e, 'prev') }.bind(this))
        .on('click.fndtn.clearing', this.settings.close_selectors,
          function (e) { Foundation.libs.clearing.close(e, this) })
        .on('keydown.fndtn.clearing',
          function (e) { this.keydown(e) }.bind(this));

      $(window).on('resize.fndtn.clearing',
        function () { this.resize() }.bind(this));

      this.settings.init = true;
      return this;
    },

    swipe_events : function () {
      var self = this;

      $(this.scope)
        .on('touchstart.fndtn.clearing', '.visible-img', function(e) {
          if (!e.touches) { e = e.originalEvent; }
          var data = {
                start_page_x: e.touches[0].pageX,
                start_page_y: e.touches[0].pageY,
                start_time: (new Date()).getTime(),
                delta_x: 0,
                is_scrolling: undefined
              };

          $(this).data('swipe-transition', data);
          e.stopPropagation();
        })
        .on('touchmove.fndtn.clearing', '.visible-img', function(e) {
          if (!e.touches) { e = e.originalEvent; }
          // Ignore pinch/zoom events
          if(e.touches.length > 1 || e.scale && e.scale !== 1) return;

          var data = $(this).data('swipe-transition');

          if (typeof data === 'undefined') {
            data = {};
          }

          data.delta_x = e.touches[0].pageX - data.start_page_x;

          if ( typeof data.is_scrolling === 'undefined') {
            data.is_scrolling = !!( data.is_scrolling || Math.abs(data.delta_x) < Math.abs(e.touches[0].pageY - data.start_page_y) );
          }

          if (!data.is_scrolling && !data.active) {
            e.preventDefault();
            var direction = (data.delta_x < 0) ? 'next' : 'prev';
            data.active = true;
            self.nav(e, direction);
          }
        })
        .on('touchend.fndtn.clearing', '.visible-img', function(e) {
          $(this).data('swipe-transition', {});
          e.stopPropagation();
        });
    },

    assemble : function ($li) {
      var $el = $li.parent();
      $el.after('<div id="foundationClearingHolder"></div>');

      var holder = $('#foundationClearingHolder'),
          settings = this.get_data($el),
          grid = $el.detach(),
          data = {
            grid: '<div class="carousel">' + this.outerHTML(grid[0]) + '</div>',
            viewing: settings.templates.viewing
          },
          wrapper = '<div class="clearing-assembled"><div>' + data.viewing +
            data.grid + '</div></div>';

      return holder.after(wrapper).remove();
    },

    // event callbacks

    open : function ($image, current, target) {
      var root = target.closest('.clearing-assembled'),
          container = root.find('div').first(),
          visible_image = container.find('.visible-img'),
          image = visible_image.find('img').not($image);

      if (!this.locked()) {
        // set the image to the selected thumbnail
        image
          .attr('src', this.load($image))
          .css('visibility', 'hidden');

        this.loaded(image, function () {
          image.css('visibility', 'visible');
          // toggle the gallery
          root.addClass('clearing-blackout');
          container.addClass('clearing-container');
          visible_image.show();
          this.fix_height(target)
            .caption(visible_image.find('.clearing-caption'), $image)
            .center(image)
            .shift(current, target, function () {
              target.siblings().removeClass('visible');
              target.addClass('visible');
            });
        }.bind(this));
      }
    },

    close : function (e, el) {
      e.preventDefault();

      var root = (function (target) {
            if (/blackout/.test(target.selector)) {
              return target;
            } else {
              return target.closest('.clearing-blackout');
            }
          }($(el))), container, visible_image;

      if (el === e.target && root) {
        container = root.find('div').first();
        visible_image = container.find('.visible-img');
        this.settings.prev_index = 0;
        root.find('ul[data-clearing]')
          .attr('style', '').closest('.clearing-blackout')
          .removeClass('clearing-blackout');
        container.removeClass('clearing-container');
        visible_image.hide();
      }

      return false;
    },

    is_open : function (current) {
      return current.parent().prop('style').length > 0;
    },

    keydown : function (e) {
      var clearing = $('.clearing-blackout').find('ul[data-clearing]');

      if (e.which === 39) this.go(clearing, 'next');
      if (e.which === 37) this.go(clearing, 'prev');
      if (e.which === 27) $('a.clearing-close').trigger('click');
    },

    nav : function (e, direction) {
      var clearing = $('.clearing-blackout').find('ul[data-clearing]');

      e.preventDefault();
      this.go(clearing, direction);
    },

    resize : function () {
      var image = $('.clearing-blackout .visible-img').find('img');

      if (image.length) {
        this.center(image);
      }
    },

    // visual adjustments
    fix_height : function (target) {
      var lis = target.parent().children(),
          self = this;

      lis.each(function () {
          var li = $(this),
              image = li.find('img');

          if (li.height() > self.outerHeight(image)) {
            li.addClass('fix-height');
          }
        })
        .closest('ul')
        .width(lis.length * 100 + '%');

      return this;
    },

    update_paddles : function (target) {
      var visible_image = target
        .closest('.carousel')
        .siblings('.visible-img');

      if (target.next().length > 0) {
        visible_image
          .find('.clearing-main-next')
          .removeClass('disabled');
      } else {
        visible_image
          .find('.clearing-main-next')
          .addClass('disabled');
      }

      if (target.prev().length > 0) {
        visible_image
          .find('.clearing-main-prev')
          .removeClass('disabled');
      } else {
        visible_image
          .find('.clearing-main-prev')
          .addClass('disabled');
      }
    },

    center : function (target) {
      if (!this.rtl) {
        target.css({
          marginLeft : -(this.outerWidth(target) / 2),
          marginTop : -(this.outerHeight(target) / 2)
        });
      } else {
        target.css({
          marginRight : -(this.outerWidth(target) / 2),
          marginTop : -(this.outerHeight(target) / 2)
        });
      }
      return this;
    },

    // image loading and preloading

    load : function ($image) {
      if ($image[0].nodeName === "A") {
        var href = $image.attr('href');
      } else {
        var href = $image.parent().attr('href');
      }

      this.preload($image);

      if (href) return href;
      return $image.attr('src');
    },

    preload : function ($image) {
      this
        .img($image.closest('li').next())
        .img($image.closest('li').prev());
    },

    loaded : function (image, callback) {
      // based on jquery.imageready.js
      // @weblinc, @jsantell, (c) 2012

      function loaded () {
        callback();
      }

      function bindLoad () {
        this.one('load', loaded);

        if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
          var src = this.attr( 'src' ),
              param = src.match( /\?/ ) ? '&' : '?';

          param += 'random=' + (new Date()).getTime();
          this.attr('src', src + param);
        }
      }

      if (!image.attr('src')) {
        loaded();
        return;
      }

      if (image[0].complete || image[0].readyState === 4) {
        loaded();
      } else {
        bindLoad.call(image);
      }
    },

    img : function (img) {
      if (img.length) {
        var new_img = new Image(),
            new_a = img.find('a');

        if (new_a.length) {
          new_img.src = new_a.attr('href');
        } else {
          new_img.src = img.find('img').attr('src');
        }
      }
      return this;
    },

    // image caption

    caption : function (container, $image) {
      var caption = $image.data('caption');

      if (caption) {
        container
          .html(caption)
          .show();
      } else {
        container
          .text('')
          .hide();
      }
      return this;
    },

    // directional methods

    go : function ($ul, direction) {
      var current = $ul.find('.visible'),
          target = current[direction]();

      if (target.length) {
        target
          .find('img')
          .trigger('click', [current, target]);
      }
    },

    shift : function (current, target, callback) {
      var clearing = target.parent(),
          old_index = this.settings.prev_index || target.index(),
          direction = this.direction(clearing, current, target),
          left = parseInt(clearing.css('left'), 10),
          width = this.outerWidth(target),
          skip_shift;

      // we use jQuery animate instead of CSS transitions because we
      // need a callback to unlock the next animation
      if (target.index() !== old_index && !/skip/.test(direction)){
        if (/left/.test(direction)) {
          this.lock();
          clearing.animate({left : left + width}, 300, this.unlock());
        } else if (/right/.test(direction)) {
          this.lock();
          clearing.animate({left : left - width}, 300, this.unlock());
        }
      } else if (/skip/.test(direction)) {
        // the target image is not adjacent to the current image, so
        // do we scroll right or not
        skip_shift = target.index() - this.settings.up_count;
        this.lock();

        if (skip_shift > 0) {
          clearing.animate({left : -(skip_shift * width)}, 300, this.unlock());
        } else {
          clearing.animate({left : 0}, 300, this.unlock());
        }
      }

      callback();
    },

    direction : function ($el, current, target) {
      var lis = $el.find('li'),
          li_width = this.outerWidth(lis) + (this.outerWidth(lis) / 4),
          up_count = Math.floor(this.outerWidth($('.clearing-container')) / li_width) - 1,
          target_index = lis.index(target),
          response;

      this.settings.up_count = up_count;

      if (this.adjacent(this.settings.prev_index, target_index)) {
        if ((target_index > up_count)
          && target_index > this.settings.prev_index) {
          response = 'right';
        } else if ((target_index > up_count - 1)
          && target_index <= this.settings.prev_index) {
          response = 'left';
        } else {
          response = false;
        }
      } else {
        response = 'skip';
      }

      this.settings.prev_index = target_index;

      return response;
    },

    adjacent : function (current_index, target_index) {
      for (var i = target_index + 1; i >= target_index - 1; i--) {
        if (i === current_index) return true;
      }
      return false;
    },

    // lock management

    lock : function () {
      this.settings.locked = true;
    },

    unlock : function () {
      this.settings.locked = false;
    },

    locked : function () {
      return this.settings.locked;
    },

    // plugin management/browser quirks

    outerHTML : function (el) {
      // support FireFox < 11
      return el.outerHTML || new XMLSerializer().serializeToString(el);
    },

    off : function () {
      $(this.scope).off('.fndtn.clearing');
      $(window).off('.fndtn.clearing');
      this.remove_data(); // empty settings cache
      this.settings.init = false;
    },

    reflow : function () {
      this.init();
    }
  };

}(Foundation.zj, this, this.document));
/*!
 * jQuery Cookie Plugin v1.3
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2011, Klaus Hartl
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.opensource.org/licenses/GPL-2.0
 *
 * Modified to work with Zepto.js by ZURB
 */

(function ($, document, undefined) {

  var pluses = /\+/g;

  function raw(s) {
    return s;
  }

  function decoded(s) {
    return decodeURIComponent(s.replace(pluses, ' '));
  }

  var config = $.cookie = function (key, value, options) {

    // write
    if (value !== undefined) {
      options = $.extend({}, config.defaults, options);

      if (value === null) {
        options.expires = -1;
      }

      if (typeof options.expires === 'number') {
        var days = options.expires, t = options.expires = new Date();
        t.setDate(t.getDate() + days);
      }

      value = config.json ? JSON.stringify(value) : String(value);

      return (document.cookie = [
        encodeURIComponent(key), '=', config.raw ? value : encodeURIComponent(value),
        options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
        options.path    ? '; path=' + options.path : '',
        options.domain  ? '; domain=' + options.domain : '',
        options.secure  ? '; secure' : ''
      ].join(''));
    }

    // read
    var decode = config.raw ? raw : decoded;
    var cookies = document.cookie.split('; ');
    for (var i = 0, l = cookies.length; i < l; i++) {
      var parts = cookies[i].split('=');
      if (decode(parts.shift()) === key) {
        var cookie = decode(parts.join('='));
        return config.json ? JSON.parse(cookie) : cookie;
      }
    }

    return null;
  };

  config.defaults = {};

  $.removeCookie = function (key, options) {
    if ($.cookie(key) !== null) {
      $.cookie(key, null, options);
      return true;
    }
    return false;
  };

})(Foundation.zj, document);
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.dropdown = {
    name : 'dropdown',

    version : '4.3.2',

    settings : {
      activeClass: 'open',
      is_hover: false,
      opened: function(){},
      closed: function(){}
    },

    init : function (scope, method, options) {
      this.scope = scope || this.scope;
      Foundation.inherit(this, 'throttle scrollLeft data_options');

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      if (typeof method !== 'string') {

        if (!this.settings.init) {
          this.events();
        }

        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;

      $(this.scope)
        .on('click.fndtn.dropdown', '[data-dropdown]', function (e) {
          var settings = $.extend({}, self.settings, self.data_options($(this)));
          e.preventDefault();

          if (!settings.is_hover) self.toggle($(this));
        })
        .on('mouseenter', '[data-dropdown]', function (e) {
          var settings = $.extend({}, self.settings, self.data_options($(this)));
          if (settings.is_hover) self.toggle($(this));
        })
        .on('mouseleave', '[data-dropdown-content]', function (e) {
          var target = $('[data-dropdown="' + $(this).attr('id') + '"]'),
              settings = $.extend({}, self.settings, self.data_options(target));
          if (settings.is_hover) self.close.call(self, $(this));
        })
        .on('opened.fndtn.dropdown', '[data-dropdown-content]', this.settings.opened)
        .on('closed.fndtn.dropdown', '[data-dropdown-content]', this.settings.closed);

      $(document).on('click.fndtn.dropdown', function (e) {
        var parent = $(e.target).closest('[data-dropdown-content]');

        if ($(e.target).data('dropdown') || $(e.target).parent().data('dropdown')) {
          return;
        }
        if (!($(e.target).data('revealId')) && 
          (parent.length > 0 && ($(e.target).is('[data-dropdown-content]') || 
            $.contains(parent.first()[0], e.target)))) {
          e.stopPropagation();
          return;
        }

        self.close.call(self, $('[data-dropdown-content]'));
      });

      $(window).on('resize.fndtn.dropdown', self.throttle(function () {
        self.resize.call(self);
      }, 50)).trigger('resize');

      this.settings.init = true;
    },

    close: function (dropdown) {
      var self = this;
      dropdown.each(function () {
        if ($(this).hasClass(self.settings.activeClass)) {
          $(this)
            .css(Foundation.rtl ? 'right':'left', '-99999px')
            .removeClass(self.settings.activeClass);
          $(this).trigger('closed');
        }
      });
    },

    open: function (dropdown, target) {
        this
          .css(dropdown
            .addClass(this.settings.activeClass), target);
        dropdown.trigger('opened');
    },

    toggle : function (target) {
      var dropdown = $('#' + target.data('dropdown'));
      if (dropdown.length === 0) {
        // No dropdown found, not continuing
        return;
      }

      this.close.call(this, $('[data-dropdown-content]').not(dropdown));

      if (dropdown.hasClass(this.settings.activeClass)) {
        this.close.call(this, dropdown);
      } else {
        this.close.call(this, $('[data-dropdown-content]'))
        this.open.call(this, dropdown, target);
      }
    },

    resize : function () {
      var dropdown = $('[data-dropdown-content].open'),
          target = $("[data-dropdown='" + dropdown.attr('id') + "']");

      if (dropdown.length && target.length) {
        this.css(dropdown, target);
      }
    },

    css : function (dropdown, target) {
      var offset_parent = dropdown.offsetParent();
      // if (offset_parent.length > 0 && /body/i.test(dropdown.offsetParent()[0].nodeName)) {
        var position = target.offset();
        position.top -= offset_parent.offset().top;
        position.left -= offset_parent.offset().left;
      // } else {
      //   var position = target.position();
      // }

      if (this.small()) {
        dropdown.css({
          position : 'absolute',
          width: '95%',
          'max-width': 'none',
          top: position.top + this.outerHeight(target)
        });
        dropdown.css(Foundation.rtl ? 'right':'left', '2.5%');
      } else {
        if (!Foundation.rtl && $(window).width() > this.outerWidth(dropdown) + target.offset().left && !this.data_options(target).align_right) {
          var left = position.left;
          if (dropdown.hasClass('right')) {
            dropdown.removeClass('right');
          }
        } else {
          if (!dropdown.hasClass('right')) {
            dropdown.addClass('right');
          }
          var left = position.left - (this.outerWidth(dropdown) - this.outerWidth(target));
        }

        dropdown.attr('style', '').css({
          position : 'absolute',
          top: position.top + this.outerHeight(target),
          left: left
        });
      }

      return dropdown;
    },

    small : function () {
      return $(window).width() < 768 || $('html').hasClass('lt-ie9');
    },

    off: function () {
      $(this.scope).off('.fndtn.dropdown');
      $('html, body').off('.fndtn.dropdown');
      $(window).off('.fndtn.dropdown');
      $('[data-dropdown-content]').off('.fndtn.dropdown');
      this.settings.init = false;
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.forms = {
    name : 'forms',

    version: '4.3.2',

    cache: {},

    settings: {
      disable_class: 'no-custom',
      last_combo : null
    },

    init: function (scope, method, options) {

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      if (typeof method !== 'string') {
        if (!this.settings.init) {
          this.events();
        }

        this.assemble();

        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    assemble: function () {

      var forms = this;

      $('form.custom input[type="radio"],[type="checkbox"]', $(this.scope))
        .not('[data-customforms="disabled"]')
        .not('.' + this.settings.disable_class)
        .each(function(idx, sel){
          forms.set_custom_markup(sel);
        })
        .change(function(){
          forms.set_custom_markup(this);
        });

      $('form.custom select', $(this.scope))
        .not('[data-customforms="disabled"]')
        .not('.' + this.settings.disable_class)
        .not('[multiple=multiple]')
        .each(this.append_custom_select);
    },

    events: function () {
      var self = this;

      $(this.scope)
        .on('click.fndtn.forms', 'form.custom span.custom.checkbox', function (e) {
          e.preventDefault();
          e.stopPropagation();
          self.toggle_checkbox($(this));
        })
        .on('click.fndtn.forms', 'form.custom span.custom.radio', function (e) {
          e.preventDefault();
          e.stopPropagation();
          self.toggle_radio($(this));
        })
        .on('change.fndtn.forms', 'form.custom select', function (e, force_refresh) {
          if ($(this).is('[data-customforms="disabled"]')) return;
          self.refresh_custom_select($(this), force_refresh);
        })
        .on('click.fndtn.forms', 'form.custom label', function (e) {
          if ($(e.target).is('label')) {
            var $associatedElement = $('#' + self.escape($(this).attr('for'))).not('[data-customforms="disabled"]'),
              $customCheckbox,
              $customRadio;

            if ($associatedElement.length !== 0) {
              if ($associatedElement.attr('type') === 'checkbox') {
                e.preventDefault();
                $customCheckbox = $(this).find('span.custom.checkbox');
                //the checkbox might be outside after the label or inside of another element
                if ($customCheckbox.length === 0) {
                  $customCheckbox = $associatedElement.add(this).siblings('span.custom.checkbox').first();
                }
                self.toggle_checkbox($customCheckbox);
              } else if ($associatedElement.attr('type') === 'radio') {
                e.preventDefault();
                $customRadio = $(this).find('span.custom.radio');
                //the radio might be outside after the label or inside of another element
                if ($customRadio.length === 0) {
                  $customRadio = $associatedElement.add(this).siblings('span.custom.radio').first();
                }
                self.toggle_radio($customRadio);
              }
            }
          }
        })
        .on('mousedown.fndtn.forms', 'form.custom div.custom.dropdown', function () {
          return false;
        })
        .on('click.fndtn.forms', 'form.custom div.custom.dropdown a.current, form.custom div.custom.dropdown a.selector', function (e) {
          var $this = $(this),
              $dropdown = $this.closest('div.custom.dropdown'),
              $select = getFirstPrevSibling($dropdown, 'select');

          // make sure other dropdowns close
          if (!$dropdown.hasClass('open')) $(self.scope).trigger('click');

          e.preventDefault();
          if (false === $select.is(':disabled')) {
            $dropdown.toggleClass('open');

            if ($dropdown.hasClass('open')) {
              $(self.scope).on('click.fndtn.forms.customdropdown', function () {
                $dropdown.removeClass('open');
                $(self.scope).off('.fndtn.forms.customdropdown');
              });
            } else {
              $(self.scope).on('.fndtn.forms.customdropdown');
            }
            return false;
          }
        })
        .on('click.fndtn.forms touchend.fndtn.forms', 'form.custom div.custom.dropdown li', function (e) {
          var $this = $(this),
              $customDropdown = $this.closest('div.custom.dropdown'),
              $select = getFirstPrevSibling($customDropdown, 'select'),
              selectedIndex = 0;

          e.preventDefault();
          e.stopPropagation();

          if (!$(this).hasClass('disabled')) {
            $('div.dropdown').not($customDropdown).removeClass('open');

            var $oldThis = $this.closest('ul')
              .find('li.selected');
            $oldThis.removeClass('selected');

            $this.addClass('selected');

            $customDropdown.removeClass('open')
              .find('a.current')
              .text($this.text());

            $this.closest('ul').find('li').each(function (index) {
              if ($this[0] === this) {
                selectedIndex = index;
              }
            });
            $select[0].selectedIndex = selectedIndex;

            //store the old value in data
            $select.data('prevalue', $oldThis.html());
            
            // Kick off full DOM change event
            if (typeof (document.createEvent) != 'undefined') {
              var event = document.createEvent('HTMLEvents');
              event.initEvent('change', true, true);
              $select[0].dispatchEvent(event);
            } else {
              $select[0].fireEvent('onchange'); // for IE
            }
          }
      });

      $(window).on('keydown', function (e) {
        var focus = document.activeElement,
            self = Foundation.libs.forms,
            dropdown = $('.custom.dropdown'),
      select = getFirstPrevSibling(dropdown, 'select'),
      inputs = $('input,select,textarea,button'); // Zepto-compatible jQuery(":input")

        if (dropdown.length > 0 && dropdown.hasClass('open')) {
          e.preventDefault();

      if (e.which === 9) {
          $(inputs[$(inputs).index(select) + 1]).focus();
        dropdown.removeClass('open');
      }

          if (e.which === 13) {
            dropdown.find('li.selected').trigger('click');
          }

          if (e.which === 27) {
            dropdown.removeClass('open');
          }

          if (e.which >= 65 && e.which <= 90) {
            var next = self.go_to(dropdown, e.which),
                current = dropdown.find('li.selected');

            if (next) {
              current.removeClass('selected');
              self.scrollTo(next.addClass('selected'), 300);
            }
          }

          if (e.which === 38) {
            var current = dropdown.find('li.selected'),
                prev = current.prev(':not(.disabled)');

            if (prev.length > 0) {
              prev.parent()[0].scrollTop = prev.parent().scrollTop() - self.outerHeight(prev);
              current.removeClass('selected');
              prev.addClass('selected');
            }
          } else if (e.which === 40) {
            var current = dropdown.find('li.selected'),
                next = current.next(':not(.disabled)');

            if (next.length > 0) {
              next.parent()[0].scrollTop = next.parent().scrollTop() + self.outerHeight(next);
              current.removeClass('selected');
              next.addClass('selected');
            }
          }
        }
      });

    $(window).on('keyup', function (e) {
          var focus = document.activeElement,
              dropdown = $('.custom.dropdown');

      if (focus === dropdown.find('.current')[0]) {
        dropdown.find('.selector').focus().click();
      }
    });

      this.settings.init = true;
    },

    go_to: function (dropdown, character) {
      var lis = dropdown.find('li'),
          count = lis.length;

      if (count > 0) {
        for (var i = 0; i < count; i++) {
          var first_letter = lis.eq(i).text().charAt(0).toLowerCase();
          if (first_letter === String.fromCharCode(character).toLowerCase()) return lis.eq(i);
        }
      }
    },

    scrollTo: function (el, duration) {
      if (duration < 0) return;
      var parent = el.parent();
      var li_height = this.outerHeight(el);
      var difference = (li_height * (el.index())) - parent.scrollTop();
      var perTick = difference / duration * 10;

      this.scrollToTimerCache = setTimeout(function () {
        if (!isNaN(parseInt(perTick, 10))) {
          parent[0].scrollTop = parent.scrollTop() + perTick;
          this.scrollTo(el, duration - 10);
        }
      }.bind(this), 10);
    },

    set_custom_markup: function (sel) {
      var $this = $(sel),
          type = $this.attr('type'),
          $span = $this.next('span.custom.' + type);
          
      if (!$this.parent().hasClass('switch')) {
        $this.addClass('hidden-field');
      }

      if ($span.length === 0) {
        $span = $('<span class="custom ' + type + '"></span>').insertAfter($this);
      }

      $span.toggleClass('checked', $this.is(':checked'));
      $span.toggleClass('disabled', $this.is(':disabled'));
    },

    append_custom_select: function (idx, sel) {
        var self = Foundation.libs.forms,
            $this = $(sel),
            $customSelect = $this.next('div.custom.dropdown'),
            $customList = $customSelect.find('ul'),
            $selectCurrent = $customSelect.find(".current"),
            $selector = $customSelect.find(".selector"),
            $options = $this.find('option'),
            $selectedOption = $options.filter(':selected'),
            copyClasses = $this.attr('class') ? $this.attr('class').split(' ') : [],
            maxWidth = 0,
            liHtml = '',
            $listItems,
            $currentSelect = false;

        if ($customSelect.length === 0) {
          var customSelectSize = $this.hasClass('small') ? 'small' : $this.hasClass('medium') ? 'medium' : $this.hasClass('large') ? 'large' : $this.hasClass('expand') ? 'expand' : '';

          $customSelect = $('<div class="' + ['custom', 'dropdown', customSelectSize].concat(copyClasses).filter(function (item, idx, arr) {
            if (item === '') return false;
            return arr.indexOf(item) === idx;
          }).join(' ') + '"><a href="#" class="selector"></a><ul /></div>');

          $selector = $customSelect.find(".selector");
          $customList = $customSelect.find("ul");

          liHtml = $options.map(function () {
            var copyClasses = $(this).attr('class') ? $(this).attr('class') : '';
            return "<li class='" + copyClasses + "'>" + $(this).html() + "</li>";
          }).get().join('');

          $customList.append(liHtml);

          $currentSelect = $customSelect
            .prepend('<a href="#" class="current">' + ($selectedOption.html() || '') + '</a>')
            .find(".current");

          $this.after($customSelect)
            .addClass('hidden-field');
        } else {
          liHtml = $options.map(function () {
              return "<li>" + $(this).html() + "</li>";
            })
            .get().join('');

          $customList.html('')
            .append(liHtml);

        } // endif $customSelect.length === 0

        self.assign_id($this, $customSelect);
        $customSelect.toggleClass('disabled', $this.is(':disabled'));
        $listItems = $customList.find('li');

        // cache list length
        self.cache[$customSelect.data('id')] = $listItems.length;

        $options.each(function (index) {
          if (this.selected) {
            $listItems.eq(index).addClass('selected');

            if ($currentSelect) {
              $currentSelect.html($(this).html());
            }
          }
          if ($(this).is(':disabled')) {
            $listItems.eq(index).addClass('disabled');
          }
        });

        //
        // If we're not specifying a predetermined form size.
        //
        if (!$customSelect.is('.small, .medium, .large, .expand')) {

          // ------------------------------------------------------------------------------------
          // This is a work-around for when elements are contained within hidden parents.
          // For example, when custom-form elements are inside of a hidden reveal modal.
          //
          // We need to display the current custom list element as well as hidden parent elements
          // in order to properly calculate the list item element's width property.
          // -------------------------------------------------------------------------------------

          $customSelect.addClass('open');
          //
          // Quickly, display all parent elements.
          // This should help us calcualate the width of the list item's within the drop down.
          //
          var self = Foundation.libs.forms;
          self.hidden_fix.adjust($customList);

          maxWidth = (self.outerWidth($listItems) > maxWidth) ? self.outerWidth($listItems) : maxWidth;

          Foundation.libs.forms.hidden_fix.reset();

          $customSelect.removeClass('open');

        } // endif

    },

    assign_id: function ($select, $customSelect) {
      var id = [+new Date(), Foundation.random_str(5)].join('-');
      $select.attr('data-id', id);
      $customSelect.attr('data-id', id);
    },

    refresh_custom_select: function ($select, force_refresh) {
      var self = this;
      var maxWidth = 0,
          $customSelect = $select.next(),
          $options = $select.find('option'),
          $customList = $customSelect.find('ul'),
          $listItems = $customSelect.find('li');

      if ($options.length !== this.cache[$customSelect.data('id')] || force_refresh) {
        $customList.html('');

        // rebuild and re-populate all at once
        var customSelectHtml = '';
        $options.each(function () {
          var $this = $(this), thisHtml = $this.html(), thisSelected = this.selected;
          customSelectHtml += '<li class="' + (thisSelected ? ' selected ' : '') + ($this.is(':disabled') ? ' disabled ' : '') + '">' + thisHtml + '</li>';
          if (thisSelected) {
            $customSelect.find('.current').html(thisHtml);
          }
        });

        $customList.html(customSelectHtml);

        // fix width
        $customSelect.removeAttr('style');
        $customList.removeAttr('style');
        $customSelect.find('li').each(function () {
          $customSelect.addClass('open');
          if (self.outerWidth($(this)) > maxWidth) {
            maxWidth = self.outerWidth($(this));
          }
          $customSelect.removeClass('open');
        });

        $listItems = $customSelect.find('li');
        // cache list length
        this.cache[$customSelect.data('id')] = $listItems.length;
      }
    },
    
    refresh_custom_selection: function ($select) {
      var selectedValue = $('option:selected', $select).text();
      $('a.current', $select.next()).text(selectedValue);
    },

    toggle_checkbox: function ($element) {
      var $input = $element.prev(),
          input = $input[0];

      if (false === $input.is(':disabled')) {
        input.checked = ((input.checked) ? false : true);
        $element.toggleClass('checked');

        $input.trigger('change');
      }
    },

    toggle_radio: function ($element) {
        var $input = $element.prev(),
            $form = $input.closest('form.custom'),
            input = $input[0];

        if (false === $input.is(':disabled')) {
          $form.find('input[type="radio"][name="' + this.escape($input.attr('name')) + '"]')
            .next().not($element).removeClass('checked');

          if (!$element.hasClass('checked')) {
            $element.toggleClass('checked');
          }

          input.checked = $element.hasClass('checked');

          $input.trigger('change');
        }
    },

    escape: function (text) {
      if (!text) return '';
      return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
    },

    hidden_fix: {
        /**
         * Sets all hidden parent elements and self to visibile.
         *
         * @method adjust
         * @param {jQuery Object} $child
         */

        // We'll use this to temporarily store style properties.
        tmp: [],

        // We'll use this to set hidden parent elements.
        hidden: null,

        adjust: function ($child) {
          // Internal reference.
          var _self = this;

          // Set all hidden parent elements, including this element.
          _self.hidden = $child.parents();
          _self.hidden = _self.hidden.add($child).filter(":hidden");

          // Loop through all hidden elements.
          _self.hidden.each(function () {

            // Cache the element.
            var $elem = $(this);

            // Store the style attribute.
            // Undefined if element doesn't have a style attribute.
            _self.tmp.push($elem.attr('style'));

            // Set the element's display property to block,
            // but ensure it's visibility is hidden.
            $elem.css({
                'visibility': 'hidden',
                'display': 'block'
            });
          });

        }, // end adjust

        /**
         * Resets the elements previous state.
         *
         * @method reset
         */
        reset: function () {
          // Internal reference.
          var _self = this;
          // Loop through our hidden element collection.
          _self.hidden.each(function (i) {
            // Cache this element.
            var $elem = $(this),
                _tmp = _self.tmp[i]; // Get the stored 'style' value for this element.

            // If the stored value is undefined.
            if (_tmp === undefined)
            // Remove the style attribute.
            $elem.removeAttr('style');
            else
            // Otherwise, reset the element style attribute.
            $elem.attr('style', _tmp);
          });
          // Reset the tmp array.
          _self.tmp = [];
          // Reset the hidden elements variable.
          _self.hidden = null;

        } // end reset
    },

    off: function () {
      $(this.scope).off('.fndtn.forms');
    },

    reflow : function () {}
  };

  var getFirstPrevSibling = function($el, selector) {
    var $el = $el.prev();
    while ($el.length) {
      if ($el.is(selector)) return $el;
      $el = $el.prev();
    }
    return $();
  };
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


(function ($, window, document, undefined) {
  'use strict';

  var Modernizr = Modernizr || false;

  Foundation.libs.joyride = {
    name : 'joyride',

    version : '4.3.2',

    defaults : {
      expose               : false,      // turn on or off the expose feature
      modal                : false,      // Whether to cover page with modal during the tour
      tipLocation          : 'bottom',  // 'top' or 'bottom' in relation to parent
      nubPosition          : 'auto',    // override on a per tooltip bases
      scrollSpeed          : 300,       // Page scrolling speed in milliseconds, 0 = no scroll animation
      timer                : 0,         // 0 = no timer , all other numbers = timer in milliseconds
      startTimerOnClick    : true,      // true or false - true requires clicking the first button start the timer
      startOffset          : 0,         // the index of the tooltip you want to start on (index of the li)
      nextButton           : true,      // true or false to control whether a next button is used
      tipAnimation         : 'fade',    // 'pop' or 'fade' in each tip
      pauseAfter           : [],        // array of indexes where to pause the tour after
      exposed              : [],        // array of expose elements
      tipAnimationFadeSpeed: 300,       // when tipAnimation = 'fade' this is speed in milliseconds for the transition
      cookieMonster        : false,     // true or false to control whether cookies are used
      cookieName           : 'joyride', // Name the cookie you'll use
      cookieDomain         : false,     // Will this cookie be attached to a domain, ie. '.notableapp.com'
      cookieExpires        : 365,       // set when you would like the cookie to expire.
      tipContainer         : 'body',    // Where will the tip be attached
      postRideCallback     : function (){},    // A method to call once the tour closes (canceled or complete)
      postStepCallback     : function (){},    // A method to call after each step
      preStepCallback      : function (){},    // A method to call before each step
      preRideCallback      : function (){},    // A method to call before the tour starts (passed index, tip, and cloned exposed element)
      postExposeCallback   : function (){},    // A method to call after an element has been exposed
      template : { // HTML segments for tip layout
        link    : '<a href="#close" class="joyride-close-tip">&times;</a>',
        timer   : '<div class="joyride-timer-indicator-wrap"><span class="joyride-timer-indicator"></span></div>',
        tip     : '<div class="joyride-tip-guide"><span class="joyride-nub"></span></div>',
        wrapper : '<div class="joyride-content-wrapper"></div>',
        button  : '<a href="#" class="small button joyride-next-tip"></a>',
        modal   : '<div class="joyride-modal-bg"></div>',
        expose  : '<div class="joyride-expose-wrapper"></div>',
        exposeCover: '<div class="joyride-expose-cover"></div>'
      },
      exposeAddClass : '' // One or more space-separated class names to be added to exposed element
    },

    settings : {},

    init : function (scope, method, options) {
      this.scope = scope || this.scope;
      Foundation.inherit(this, 'throttle data_options scrollTo scrollLeft delay');

      if (typeof method === 'object') {
        $.extend(true, this.settings, this.defaults, method);
      } else {
        $.extend(true, this.settings, this.defaults, options);
      }

      if (typeof method !== 'string') {
        if (!this.settings.init) this.events();

        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;

      $(this.scope)
        .on('click.joyride', '.joyride-next-tip, .joyride-modal-bg', function (e) {
          e.preventDefault();

          if (this.settings.$li.next().length < 1) {
            this.end();
          } else if (this.settings.timer > 0) {
            clearTimeout(this.settings.automate);
            this.hide();
            this.show();
            this.startTimer();
          } else {
            this.hide();
            this.show();
          }

        }.bind(this))

        .on('click.joyride', '.joyride-close-tip', function (e) {
          e.preventDefault();
          this.end();
        }.bind(this));

      $(window).on('resize.fndtn.joyride', self.throttle(function () {
        if ($('[data-joyride]').length > 0 && self.settings.$next_tip) {
          if (self.settings.exposed.length > 0) {
            var $els = $(self.settings.exposed);

            $els.each(function () {
              var $this = $(this);
              self.un_expose($this);
              self.expose($this);
            });
          }

          if (self.is_phone()) {
            self.pos_phone();
          } else {
            self.pos_default(false, true);
          }
        }
      }, 100));

      this.settings.init = true;
    },

    start : function () {
      var self = this,
          $this = $(this.scope).find('[data-joyride]'),
          integer_settings = ['timer', 'scrollSpeed', 'startOffset', 'tipAnimationFadeSpeed', 'cookieExpires'],
          int_settings_count = integer_settings.length;

      if (!this.settings.init) this.events();

      // non configureable settings
      this.settings.$content_el = $this;
      this.settings.$body = $(this.settings.tipContainer);
      this.settings.body_offset = $(this.settings.tipContainer).position();
      this.settings.$tip_content = this.settings.$content_el.find('> li');
      this.settings.paused = false;
      this.settings.attempts = 0;

      this.settings.tipLocationPatterns = {
        top: ['bottom'],
        bottom: [], // bottom should not need to be repositioned
        left: ['right', 'top', 'bottom'],
        right: ['left', 'top', 'bottom']
      };

      // can we create cookies?
      if (typeof $.cookie !== 'function') {
        this.settings.cookieMonster = false;
      }

      // generate the tips and insert into dom.
      if (!this.settings.cookieMonster || this.settings.cookieMonster && $.cookie(this.settings.cookieName) === null) {
        this.settings.$tip_content.each(function (index) {
          var $this = $(this);
          $.extend(true, self.settings, self.data_options($this));
          // Make sure that settings parsed from data_options are integers where necessary
          for (var i = int_settings_count - 1; i >= 0; i--) {
            self.settings[integer_settings[i]] = parseInt(self.settings[integer_settings[i]], 10);
          }
          self.create({$li : $this, index : index});
        });

        // show first tip
        if (!this.settings.startTimerOnClick && this.settings.timer > 0) {
          this.show('init');
          this.startTimer();
        } else {
          this.show('init');
        }

      }
    },

    resume : function () {
      this.set_li();
      this.show();
    },

    tip_template : function (opts) {
      var $blank, content;

      opts.tip_class = opts.tip_class || '';

      $blank = $(this.settings.template.tip).addClass(opts.tip_class);
      content = $.trim($(opts.li).html()) +
        this.button_text(opts.button_text) +
        this.settings.template.link +
        this.timer_instance(opts.index);

      $blank.append($(this.settings.template.wrapper));
      $blank.first().attr('data-index', opts.index);
      $('.joyride-content-wrapper', $blank).append(content);

      return $blank[0];
    },

    timer_instance : function (index) {
      var txt;

      if ((index === 0 && this.settings.startTimerOnClick && this.settings.timer > 0) || this.settings.timer === 0) {
        txt = '';
      } else {
        txt = this.outerHTML($(this.settings.template.timer)[0]);
      }
      return txt;
    },

    button_text : function (txt) {
      if (this.settings.nextButton) {
        txt = $.trim(txt) || 'Next';
        txt = this.outerHTML($(this.settings.template.button).append(txt)[0]);
      } else {
        txt = '';
      }
      return txt;
    },

    create : function (opts) {
      var buttonText = opts.$li.attr('data-button') || opts.$li.attr('data-text'),
        tipClass = opts.$li.attr('class'),
        $tip_content = $(this.tip_template({
          tip_class : tipClass,
          index : opts.index,
          button_text : buttonText,
          li : opts.$li
        }));

      $(this.settings.tipContainer).append($tip_content);
    },

    show : function (init) {
      var $timer = null;

      // are we paused?
      if (this.settings.$li === undefined
        || ($.inArray(this.settings.$li.index(), this.settings.pauseAfter) === -1)) {

        // don't go to the next li if the tour was paused
        if (this.settings.paused) {
          this.settings.paused = false;
        } else {
          this.set_li(init);
        }

        this.settings.attempts = 0;

        if (this.settings.$li.length && this.settings.$target.length > 0) {
          if (init) { //run when we first start
            this.settings.preRideCallback(this.settings.$li.index(), this.settings.$next_tip);
            if (this.settings.modal) {
              this.show_modal();
            }
          }

          this.settings.preStepCallback(this.settings.$li.index(), this.settings.$next_tip);

          if (this.settings.modal && this.settings.expose) {
            this.expose();
          }

          this.settings.tipSettings = $.extend(this.settings, this.data_options(this.settings.$li));

          this.settings.timer = parseInt(this.settings.timer, 10);

          this.settings.tipSettings.tipLocationPattern = this.settings.tipLocationPatterns[this.settings.tipSettings.tipLocation];

          // scroll if not modal
          if (!/body/i.test(this.settings.$target.selector)) {
            this.scroll_to();
          }

          if (this.is_phone()) {
            this.pos_phone(true);
          } else {
            this.pos_default(true);
          }

          $timer = this.settings.$next_tip.find('.joyride-timer-indicator');

          if (/pop/i.test(this.settings.tipAnimation)) {

            $timer.width(0);

            if (this.settings.timer > 0) {

              this.settings.$next_tip.show();

              this.delay(function () {
                $timer.animate({
                  width: $timer.parent().width()
                }, this.settings.timer, 'linear');
              }.bind(this), this.settings.tipAnimationFadeSpeed);

            } else {
              this.settings.$next_tip.show();

            }


          } else if (/fade/i.test(this.settings.tipAnimation)) {

            $timer.width(0);

            if (this.settings.timer > 0) {

              this.settings.$next_tip
                .fadeIn(this.settings.tipAnimationFadeSpeed)
                .show();

              this.delay(function () {
                $timer.animate({
                  width: $timer.parent().width()
                }, this.settings.timer, 'linear');
              }.bind(this), this.settings.tipAnimationFadeSpeed);

            } else {
              this.settings.$next_tip.fadeIn(this.settings.tipAnimationFadeSpeed);

            }
          }

          this.settings.$current_tip = this.settings.$next_tip;

        // skip non-existant targets
        } else if (this.settings.$li && this.settings.$target.length < 1) {

          this.show();

        } else {

          this.end();

        }
      } else {

        this.settings.paused = true;

      }

    },

    is_phone : function () {
      if (Modernizr) {
        return Modernizr.mq('only screen and (max-width: 767px)') || $('.lt-ie9').length > 0;
      }

      return ($(window).width() < 767);
    },

    hide : function () {
      if (this.settings.modal && this.settings.expose) {
        this.un_expose();
      }

      if (!this.settings.modal) {
        $('.joyride-modal-bg').hide();
      }

      // Prevent scroll bouncing...wait to remove from layout
      this.settings.$current_tip.css('visibility', 'hidden');
      setTimeout($.proxy(function() {
        this.hide();
        this.css('visibility', 'visible');
      }, this.settings.$current_tip), 0);
      this.settings.postStepCallback(this.settings.$li.index(),
        this.settings.$current_tip);
    },

    set_li : function (init) {
      if (init) {
        this.settings.$li = this.settings.$tip_content.eq(this.settings.startOffset);
        this.set_next_tip();
        this.settings.$current_tip = this.settings.$next_tip;
      } else {
        this.settings.$li = this.settings.$li.next();
        this.set_next_tip();
      }

      this.set_target();
    },

    set_next_tip : function () {
      this.settings.$next_tip = $(".joyride-tip-guide[data-index='" + this.settings.$li.index() + "']");
      this.settings.$next_tip.data('closed', '');
    },

    set_target : function () {
      var cl = this.settings.$li.attr('data-class'),
          id = this.settings.$li.attr('data-id'),
          $sel = function () {
            if (id) {
              return $(document.getElementById(id));
            } else if (cl) {
              return $('.' + cl).first();
            } else {
              return $('body');
            }
          };

      this.settings.$target = $sel();
    },

    scroll_to : function () {
      var window_half, tipOffset;

      window_half = $(window).height() / 2;
      tipOffset = Math.ceil(this.settings.$target.offset().top - window_half + this.outerHeight(this.settings.$next_tip));
      if (tipOffset > 0) {
        this.scrollTo($('html, body'), tipOffset, this.settings.scrollSpeed);
      }
    },

    paused : function () {
      return ($.inArray((this.settings.$li.index() + 1), this.settings.pauseAfter) === -1);
    },

    restart : function () {
      this.hide();
      this.settings.$li = undefined;
      this.show('init');
    },

    pos_default : function (init, resizing) {
      var half_fold = Math.ceil($(window).height() / 2),
          tip_position = this.settings.$next_tip.offset(),
          $nub = this.settings.$next_tip.find('.joyride-nub'),
          nub_width = Math.ceil(this.outerWidth($nub) / 2),
          nub_height = Math.ceil(this.outerHeight($nub) / 2),
          toggle = init || false;

      // tip must not be "display: none" to calculate position
      if (toggle) {
        this.settings.$next_tip.css('visibility', 'hidden');
        this.settings.$next_tip.show();
      }

      if (typeof resizing === 'undefined') {
        resizing = false;
      }

      if (!/body/i.test(this.settings.$target.selector)) {

          if (this.bottom()) {
            var leftOffset = this.settings.$target.offset().left;
            if (Foundation.rtl) {
              leftOffset = this.settings.$target.offset().width - this.settings.$next_tip.width() + leftOffset;
            }
            this.settings.$next_tip.css({
              top: (this.settings.$target.offset().top + nub_height + this.outerHeight(this.settings.$target)),
              left: leftOffset});

            this.nub_position($nub, this.settings.tipSettings.nubPosition, 'top');

          } else if (this.top()) {
            var leftOffset = this.settings.$target.offset().left;
            if (Foundation.rtl) {
              leftOffset = this.settings.$target.offset().width - this.settings.$next_tip.width() + leftOffset;
            }
            this.settings.$next_tip.css({
              top: (this.settings.$target.offset().top - this.outerHeight(this.settings.$next_tip) - nub_height),
              left: leftOffset});

            this.nub_position($nub, this.settings.tipSettings.nubPosition, 'bottom');

          } else if (this.right()) {

            this.settings.$next_tip.css({
              top: this.settings.$target.offset().top,
              left: (this.outerWidth(this.settings.$target) + this.settings.$target.offset().left + nub_width)});

            this.nub_position($nub, this.settings.tipSettings.nubPosition, 'left');

          } else if (this.left()) {

            this.settings.$next_tip.css({
              top: this.settings.$target.offset().top,
              left: (this.settings.$target.offset().left - this.outerWidth(this.settings.$next_tip) - nub_width)});

            this.nub_position($nub, this.settings.tipSettings.nubPosition, 'right');

          }

          if (!this.visible(this.corners(this.settings.$next_tip)) && this.settings.attempts < this.settings.tipSettings.tipLocationPattern.length) {

            $nub.removeClass('bottom')
              .removeClass('top')
              .removeClass('right')
              .removeClass('left');

            this.settings.tipSettings.tipLocation = this.settings.tipSettings.tipLocationPattern[this.settings.attempts];

            this.settings.attempts++;

            this.pos_default();

          }

      } else if (this.settings.$li.length) {

        this.pos_modal($nub);

      }

      if (toggle) {
        this.settings.$next_tip.hide();
        this.settings.$next_tip.css('visibility', 'visible');
      }

    },

    pos_phone : function (init) {
      var tip_height = this.outerHeight(this.settings.$next_tip),
          tip_offset = this.settings.$next_tip.offset(),
          target_height = this.outerHeight(this.settings.$target),
          $nub = $('.joyride-nub', this.settings.$next_tip),
          nub_height = Math.ceil(this.outerHeight($nub) / 2),
          toggle = init || false;

      $nub.removeClass('bottom')
        .removeClass('top')
        .removeClass('right')
        .removeClass('left');

      if (toggle) {
        this.settings.$next_tip.css('visibility', 'hidden');
        this.settings.$next_tip.show();
      }

      if (!/body/i.test(this.settings.$target.selector)) {

        if (this.top()) {

            this.settings.$next_tip.offset({top: this.settings.$target.offset().top - tip_height - nub_height});
            $nub.addClass('bottom');

        } else {

          this.settings.$next_tip.offset({top: this.settings.$target.offset().top + target_height + nub_height});
          $nub.addClass('top');

        }

      } else if (this.settings.$li.length) {
        this.pos_modal($nub);
      }

      if (toggle) {
        this.settings.$next_tip.hide();
        this.settings.$next_tip.css('visibility', 'visible');
      }
    },

    pos_modal : function ($nub) {
      this.center();
      $nub.hide();

      this.show_modal();
    },

    show_modal : function () {
      if (!this.settings.$next_tip.data('closed')) {
        var joyridemodalbg =  $('.joyride-modal-bg');
        if (joyridemodalbg.length < 1) {
          $('body').append(this.settings.template.modal).show();
        }

        if (/pop/i.test(this.settings.tipAnimation)) {
            joyridemodalbg.show();
        } else {
            joyridemodalbg.fadeIn(this.settings.tipAnimationFadeSpeed);
        }
      }
    },

    expose : function () {
      var expose,
          exposeCover,
          el,
          origCSS,
          origClasses,
          randId = 'expose-'+Math.floor(Math.random()*10000);

      if (arguments.length > 0 && arguments[0] instanceof $) {
        el = arguments[0];
      } else if(this.settings.$target && !/body/i.test(this.settings.$target.selector)){
        el = this.settings.$target;
      }  else {
        return false;
      }

      if(el.length < 1){
        if(window.console){
          console.error('element not valid', el);
        }
        return false;
      }

      expose = $(this.settings.template.expose);
      this.settings.$body.append(expose);
      expose.css({
        top: el.offset().top,
        left: el.offset().left,
        width: this.outerWidth(el, true),
        height: this.outerHeight(el, true)
      });

      exposeCover = $(this.settings.template.exposeCover);

      origCSS = {
        zIndex: el.css('z-index'),
        position: el.css('position')
      };

      origClasses = el.attr('class') == null ? '' : el.attr('class');

      el.css('z-index',parseInt(expose.css('z-index'))+1);

      if (origCSS.position == 'static') {
        el.css('position','relative');
      }

      el.data('expose-css',origCSS);
      el.data('orig-class', origClasses);
      el.attr('class', origClasses + ' ' + this.settings.exposeAddClass);

      exposeCover.css({
        top: el.offset().top,
        left: el.offset().left,
        width: this.outerWidth(el, true),
        height: this.outerHeight(el, true)
      });

      this.settings.$body.append(exposeCover);
      expose.addClass(randId);
      exposeCover.addClass(randId);
      el.data('expose', randId);
      this.settings.postExposeCallback(this.settings.$li.index(), this.settings.$next_tip, el);
      this.add_exposed(el);
    },

    un_expose : function () {
      var exposeId,
          el,
          expose ,
          origCSS,
          origClasses,
          clearAll = false;

      if (arguments.length > 0 && arguments[0] instanceof $) {
        el = arguments[0];
      } else if(this.settings.$target && !/body/i.test(this.settings.$target.selector)){
        el = this.settings.$target;
      }  else {
        return false;
      }

      if(el.length < 1){
        if (window.console) {
          console.error('element not valid', el);
        }
        return false;
      }

      exposeId = el.data('expose');
      expose = $('.' + exposeId);

      if (arguments.length > 1) {
        clearAll = arguments[1];
      }

      if (clearAll === true) {
        $('.joyride-expose-wrapper,.joyride-expose-cover').remove();
      } else {
        expose.remove();
      }

      origCSS = el.data('expose-css');

      if (origCSS.zIndex == 'auto') {
        el.css('z-index', '');
      } else {
        el.css('z-index', origCSS.zIndex);
      }

      if (origCSS.position != el.css('position')) {
        if(origCSS.position == 'static') {// this is default, no need to set it.
          el.css('position', '');
        } else {
          el.css('position', origCSS.position);
        }
      }

      origClasses = el.data('orig-class');
      el.attr('class', origClasses);
      el.removeData('orig-classes');

      el.removeData('expose');
      el.removeData('expose-z-index');
      this.remove_exposed(el);
    },

    add_exposed: function(el){
      this.settings.exposed = this.settings.exposed || [];
      if (el instanceof $ || typeof el === 'object') {
        this.settings.exposed.push(el[0]);
      } else if (typeof el == 'string') {
        this.settings.exposed.push(el);
      }
    },

    remove_exposed: function(el){
      var search, count;
      if (el instanceof $) {
        search = el[0]
      } else if (typeof el == 'string'){
        search = el;
      }

      this.settings.exposed = this.settings.exposed || [];
      count = this.settings.exposed.length;

      for (var i=0; i < count; i++) {
        if (this.settings.exposed[i] == search) {
          this.settings.exposed.splice(i, 1);
          return;
        }
      }
    },

    center : function () {
      var $w = $(window);

      this.settings.$next_tip.css({
        top : ((($w.height() - this.outerHeight(this.settings.$next_tip)) / 2) + $w.scrollTop()),
        left : ((($w.width() - this.outerWidth(this.settings.$next_tip)) / 2) + this.scrollLeft($w))
      });

      return true;
    },

    bottom : function () {
      return /bottom/i.test(this.settings.tipSettings.tipLocation);
    },

    top : function () {
      return /top/i.test(this.settings.tipSettings.tipLocation);
    },

    right : function () {
      return /right/i.test(this.settings.tipSettings.tipLocation);
    },

    left : function () {
      return /left/i.test(this.settings.tipSettings.tipLocation);
    },

    corners : function (el) {
      var w = $(window),
          window_half = w.height() / 2,
          //using this to calculate since scroll may not have finished yet.
          tipOffset = Math.ceil(this.settings.$target.offset().top - window_half + this.settings.$next_tip.outerHeight()),
          right = w.width() + this.scrollLeft(w),
          offsetBottom =  w.height() + tipOffset,
          bottom = w.height() + w.scrollTop(),
          top = w.scrollTop();

      if (tipOffset < top) {
        if (tipOffset < 0) {
          top = 0;
        } else {
          top = tipOffset;
        }
      }

      if (offsetBottom > bottom) {
        bottom = offsetBottom;
      }

      return [
        el.offset().top < top,
        right < el.offset().left + el.outerWidth(),
        bottom < el.offset().top + el.outerHeight(),
        this.scrollLeft(w) > el.offset().left
      ];
    },

    visible : function (hidden_corners) {
      var i = hidden_corners.length;

      while (i--) {
        if (hidden_corners[i]) return false;
      }

      return true;
    },

    nub_position : function (nub, pos, def) {
      if (pos === 'auto') {
        nub.addClass(def);
      } else {
        nub.addClass(pos);
      }
    },

    startTimer : function () {
      if (this.settings.$li.length) {
        this.settings.automate = setTimeout(function () {
          this.hide();
          this.show();
          this.startTimer();
        }.bind(this), this.settings.timer);
      } else {
        clearTimeout(this.settings.automate);
      }
    },

    end : function () {
      if (this.settings.cookieMonster) {
        $.cookie(this.settings.cookieName, 'ridden', { expires: this.settings.cookieExpires, domain: this.settings.cookieDomain });
      }

      if (this.settings.timer > 0) {
        clearTimeout(this.settings.automate);
      }

      if (this.settings.modal && this.settings.expose) {
        this.un_expose();
      }

      this.settings.$next_tip.data('closed', true);

      $('.joyride-modal-bg').hide();
      this.settings.$current_tip.hide();
      this.settings.postStepCallback(this.settings.$li.index(), this.settings.$current_tip);
      this.settings.postRideCallback(this.settings.$li.index(), this.settings.$current_tip);
      $('.joyride-tip-guide').remove();
    },

    outerHTML : function (el) {
      // support FireFox < 11
      return el.outerHTML || new XMLSerializer().serializeToString(el);
    },

    off : function () {
      $(this.scope).off('.joyride');
      $(window).off('.joyride');
      $('.joyride-close-tip, .joyride-next-tip, .joyride-modal-bg').off('.joyride');
      $('.joyride-tip-guide, .joyride-modal-bg').remove();
      clearTimeout(this.settings.automate);
      this.settings = {};
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.magellan = {
    name : 'magellan',

    version : '4.3.2',

    settings : {
      activeClass: 'active',
      threshold: 0
    },

    init : function (scope, method, options) {
      this.scope = scope || this.scope;
      Foundation.inherit(this, 'data_options');

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      if (typeof method !== 'string') {
        if (!this.settings.init) {
          this.fixed_magellan = $("[data-magellan-expedition]");
          this.set_threshold();
          this.last_destination = $('[data-magellan-destination]').last();
          this.events();
        }

        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;
      $(this.scope).on('arrival.fndtn.magellan', '[data-magellan-arrival]', function (e) {
        var $destination = $(this),
            $expedition = $destination.closest('[data-magellan-expedition]'),
            activeClass = $expedition.attr('data-magellan-active-class') 
              || self.settings.activeClass;

          $destination
            .closest('[data-magellan-expedition]')
            .find('[data-magellan-arrival]')
            .not($destination)
            .removeClass(activeClass);
          $destination.addClass(activeClass);
      });

      this.fixed_magellan
        .on('update-position.fndtn.magellan', function(){
          var $el = $(this);
          // $el.data("magellan-fixed-position","");
          // $el.data("magellan-top-offset", "");
        })
        .trigger('update-position');

      $(window)
        .on('resize.fndtn.magellan', function() {
          this.fixed_magellan.trigger('update-position');
        }.bind(this))

        .on('scroll.fndtn.magellan', function() {
          var windowScrollTop = $(window).scrollTop();
          self.fixed_magellan.each(function() {
            var $expedition = $(this);
            if (typeof $expedition.data('magellan-top-offset') === 'undefined') {
              $expedition.data('magellan-top-offset', $expedition.offset().top);
            }
            if (typeof $expedition.data('magellan-fixed-position') === 'undefined') {
              $expedition.data('magellan-fixed-position', false)
            }
            var fixed_position = (windowScrollTop + self.settings.threshold) > $expedition.data("magellan-top-offset");
            var attr = $expedition.attr('data-magellan-top-offset');

            if ($expedition.data("magellan-fixed-position") != fixed_position) {
              $expedition.data("magellan-fixed-position", fixed_position);
              if (fixed_position) {
                $expedition.addClass('fixed');
                $expedition.css({position:"fixed", top:0});
              } else {
                $expedition.removeClass('fixed');
                $expedition.css({position:"", top:""});
              }
              if (fixed_position && typeof attr != 'undefined' && attr != false) {
                $expedition.css({position:"fixed", top:attr + "px"});
              }
            }
          });
        });


      if (this.last_destination.length > 0) {
        $(window).on('scroll.fndtn.magellan', function (e) {
          var windowScrollTop = $(window).scrollTop(),
              scrolltopPlusHeight = windowScrollTop + $(window).height(),
              lastDestinationTop = Math.ceil(self.last_destination.offset().top);

          $('[data-magellan-destination]').each(function () {
            var $destination = $(this),
                destination_name = $destination.attr('data-magellan-destination'),
                topOffset = $destination.offset().top - windowScrollTop;

            if (topOffset <= self.settings.threshold) {
              $("[data-magellan-arrival='" + destination_name + "']").trigger('arrival');
            }
            // In large screens we may hit the bottom of the page and dont reach the top of the last magellan-destination, so lets force it
            if (scrolltopPlusHeight >= $(self.scope).height() && lastDestinationTop > windowScrollTop && lastDestinationTop < scrolltopPlusHeight) {
              $('[data-magellan-arrival]').last().trigger('arrival');
            }
          });
        });
      }

      this.settings.init = true;
    },

    set_threshold : function () {
      if (typeof this.settings.threshold !== 'number') {
        this.settings.threshold = (this.fixed_magellan.length > 0) ? 
          this.outerHeight(this.fixed_magellan, true) : 0;
      }
    },

    off : function () {
      $(this.scope).off('.fndtn.magellan');
      $(window).off('.fndtn.magellan');
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
;(function ($, window, document, undefined) {
  'use strict';

  var noop = function() {};

  var Orbit = function(el, settings) {
    // Don't reinitialize plugin
    if (el.hasClass(settings.slides_container_class)) {
      return this;
    }

    var self = this,
        container,
        slides_container = el,
        number_container,
        bullets_container,
        timer_container,
        idx = 0,
        animate,
        timer,
        locked = false,
        adjust_height_after = false;

    slides_container.children().first().addClass(settings.active_slide_class);

    self.update_slide_number = function(index) {
      if (settings.slide_number) {
        number_container.find('span:first').text(parseInt(index)+1);
        number_container.find('span:last').text(slides_container.children().length);
      }
      if (settings.bullets) {
        bullets_container.children().removeClass(settings.bullets_active_class);
        $(bullets_container.children().get(index)).addClass(settings.bullets_active_class);
      }
    };

    self.update_active_link = function(index) {
      var link = $('a[data-orbit-link="'+slides_container.children().eq(index).attr('data-orbit-slide')+'"]');
      link.parents('ul').find('[data-orbit-link]').removeClass(settings.bullets_active_class);
      link.addClass(settings.bullets_active_class);
    };

    self.build_markup = function() {
      slides_container.wrap('<div class="'+settings.container_class+'"></div>');
      container = slides_container.parent();
      slides_container.addClass(settings.slides_container_class);
      
      if (settings.navigation_arrows) {
        container.append($('<a href="#"><span></span></a>').addClass(settings.prev_class));
        container.append($('<a href="#"><span></span></a>').addClass(settings.next_class));
      }

      if (settings.timer) {
        timer_container = $('<div>').addClass(settings.timer_container_class);
        timer_container.append('<span>');
        timer_container.append($('<div>').addClass(settings.timer_progress_class));
        timer_container.addClass(settings.timer_paused_class);
        container.append(timer_container);
      }

      if (settings.slide_number) {
        number_container = $('<div>').addClass(settings.slide_number_class);
        number_container.append('<span></span> ' + settings.slide_number_text + ' <span></span>');
        container.append(number_container);
      }

      if (settings.bullets) {
        bullets_container = $('<ol>').addClass(settings.bullets_container_class);
        container.append(bullets_container);
        slides_container.children().each(function(idx, el) {
          var bullet = $('<li>').attr('data-orbit-slide', idx);
          bullets_container.append(bullet);
        });
      }

      if (settings.stack_on_small) {
        container.addClass(settings.stack_on_small_class);
      }

      self.update_slide_number(0);
      self.update_active_link(0);
    };

    self._goto = function(next_idx, start_timer) {
      // if (locked) {return false;}
      if (next_idx === idx) {return false;}
      if (typeof timer === 'object') {timer.restart();}
      var slides = slides_container.children();

      var dir = 'next';
      locked = true;
      if (next_idx < idx) {dir = 'prev';}
      if (next_idx >= slides.length) {next_idx = 0;}
      else if (next_idx < 0) {next_idx = slides.length - 1;}
      
      var current = $(slides.get(idx));
      var next = $(slides.get(next_idx));

      current.css('zIndex', 2);
      current.removeClass(settings.active_slide_class);
      next.css('zIndex', 4).addClass(settings.active_slide_class);

      slides_container.trigger('orbit:before-slide-change');
      settings.before_slide_change();
      self.update_active_link(next_idx);
      
      var callback = function() {
        var unlock = function() {
          idx = next_idx;
          locked = false;
          if (start_timer === true) {timer = self.create_timer(); timer.start();}
          self.update_slide_number(idx);
          slides_container.trigger('orbit:after-slide-change',[{slide_number: idx, total_slides: slides.length}]);
          settings.after_slide_change(idx, slides.length);
        };
        if (slides_container.height() != next.height() && settings.variable_height) {
          slides_container.animate({'height': next.height()}, 250, 'linear', unlock);
        } else {
          unlock();
        }
      };

      if (slides.length === 1) {callback(); return false;}

      var start_animation = function() {
        if (dir === 'next') {animate.next(current, next, callback);}
        if (dir === 'prev') {animate.prev(current, next, callback);}        
      };

      if (next.height() > slides_container.height() && settings.variable_height) {
        slides_container.animate({'height': next.height()}, 250, 'linear', start_animation);
      } else {
        start_animation();
      }
    };
    
    self.next = function(e) {
      e.stopImmediatePropagation();
      e.preventDefault();
      self._goto(idx + 1);
    };
    
    self.prev = function(e) {
      e.stopImmediatePropagation();
      e.preventDefault();
      self._goto(idx - 1);
    };

    self.link_custom = function(e) {
      e.preventDefault();
      var link = $(this).attr('data-orbit-link');
      if ((typeof link === 'string') && (link = $.trim(link)) != "") {
        var slide = container.find('[data-orbit-slide='+link+']');
        if (slide.index() != -1) {self._goto(slide.index());}
      }
    };

    self.link_bullet = function(e) {
      var index = $(this).attr('data-orbit-slide');
      if ((typeof index === 'string') && (index = $.trim(index)) != "") {
        self._goto(parseInt(index));
      }
    }

    self.timer_callback = function() {
      self._goto(idx + 1, true);
    }
    
    self.compute_dimensions = function() {
      var current = $(slides_container.children().get(idx));
      var h = current.height();
      if (!settings.variable_height) {
        slides_container.children().each(function(){
          if ($(this).height() > h) { h = $(this).height(); }
        });
      }
      slides_container.height(h);
    };

    self.create_timer = function() {
      var t = new Timer(
        container.find('.'+settings.timer_container_class), 
        settings, 
        self.timer_callback
      );
      return t;
    };

    self.stop_timer = function() {
      if (typeof timer === 'object') timer.stop();
    };

    self.toggle_timer = function() {
      var t = container.find('.'+settings.timer_container_class);
      if (t.hasClass(settings.timer_paused_class)) {
        if (typeof timer === 'undefined') {timer = self.create_timer();}
        timer.start();     
      }
      else {
        if (typeof timer === 'object') {timer.stop();}
      }
    };

    self.init = function() {
      self.build_markup();
      if (settings.timer) {timer = self.create_timer(); timer.start();}
      animate = new FadeAnimation(settings, slides_container);
      if (settings.animation === 'slide') 
        animate = new SlideAnimation(settings, slides_container);        
      container.on('click', '.'+settings.next_class, self.next);
      container.on('click', '.'+settings.prev_class, self.prev);
      container.on('click', '[data-orbit-slide]', self.link_bullet);
      container.on('click', self.toggle_timer);
      if (settings.swipe) {
        container.on('touchstart.fndtn.orbit', function(e) {
          if (!e.touches) {e = e.originalEvent;}
          var data = {
            start_page_x: e.touches[0].pageX,
            start_page_y: e.touches[0].pageY,
            start_time: (new Date()).getTime(),
            delta_x: 0,
            is_scrolling: undefined
          };
          container.data('swipe-transition', data);
          e.stopPropagation();
        })
        .on('touchmove.fndtn.orbit', function(e) {
          if (!e.touches) { e = e.originalEvent; }
          // Ignore pinch/zoom events
          if(e.touches.length > 1 || e.scale && e.scale !== 1) return;

          var data = container.data('swipe-transition');
          if (typeof data === 'undefined') {data = {};}

          data.delta_x = e.touches[0].pageX - data.start_page_x;

          if ( typeof data.is_scrolling === 'undefined') {
            data.is_scrolling = !!( data.is_scrolling || Math.abs(data.delta_x) < Math.abs(e.touches[0].pageY - data.start_page_y) );
          }

          if (!data.is_scrolling && !data.active) {
            e.preventDefault();
            var direction = (data.delta_x < 0) ? (idx+1) : (idx-1);
            data.active = true;
            self._goto(direction);
          }
        })
        .on('touchend.fndtn.orbit', function(e) {
          container.data('swipe-transition', {});
          e.stopPropagation();
        })
      }
      container.on('mouseenter.fndtn.orbit', function(e) {
        if (settings.timer && settings.pause_on_hover) {
          self.stop_timer();
        }
      })
      .on('mouseleave.fndtn.orbit', function(e) {
        if (settings.timer && settings.resume_on_mouseout) {
          timer.start();
        }
      });
      
      $(document).on('click', '[data-orbit-link]', self.link_custom);
      $(window).on('resize', self.compute_dimensions);
      $(window).on('load', self.compute_dimensions);
      $(window).on('load', function(){
        container.prev('.preloader').css('display', 'none');
      });
      slides_container.trigger('orbit:ready');
    };

    self.init();
  };

  var Timer = function(el, settings, callback) {
    var self = this,
        duration = settings.timer_speed,
        progress = el.find('.'+settings.timer_progress_class),
        start, 
        timeout,
        left = -1;

    this.update_progress = function(w) {
      var new_progress = progress.clone();
      new_progress.attr('style', '');
      new_progress.css('width', w+'%');
      progress.replaceWith(new_progress);
      progress = new_progress;
    };

    this.restart = function() {
      clearTimeout(timeout);
      el.addClass(settings.timer_paused_class);
      left = -1;
      self.update_progress(0);
    };

    this.start = function() {
      if (!el.hasClass(settings.timer_paused_class)) {return true;}
      left = (left === -1) ? duration : left;
      el.removeClass(settings.timer_paused_class);
      start = new Date().getTime();
      progress.animate({'width': '100%'}, left, 'linear');
      timeout = setTimeout(function() {
        self.restart();
        callback();
      }, left);
      el.trigger('orbit:timer-started')
    };

    this.stop = function() {
      if (el.hasClass(settings.timer_paused_class)) {return true;}
      clearTimeout(timeout);
      el.addClass(settings.timer_paused_class);
      var end = new Date().getTime();
      left = left - (end - start);
      var w = 100 - ((left / duration) * 100);
      self.update_progress(w);
      el.trigger('orbit:timer-stopped');
    };
  };
  
  var SlideAnimation = function(settings, container) {
    var duration = settings.animation_speed;
    var is_rtl = ($('html[dir=rtl]').length === 1);
    var margin = is_rtl ? 'marginRight' : 'marginLeft';
    var animMargin = {};
    animMargin[margin] = '0%';

    this.next = function(current, next, callback) {
      next.animate(animMargin, duration, 'linear', function() {
        current.css(margin, '100%');
        callback();
      });
    };

    this.prev = function(current, prev, callback) {
      prev.css(margin, '-100%');
      prev.animate(animMargin, duration, 'linear', function() {
        current.css(margin, '100%');
        callback();
      });
    };
  };

  var FadeAnimation = function(settings, container) {
    var duration = settings.animation_speed;
    var is_rtl = ($('html[dir=rtl]').length === 1);
    var margin = is_rtl ? 'marginRight' : 'marginLeft';

    this.next = function(current, next, callback) {
      next.css({'margin':'0%', 'opacity':'0.01'});
      next.animate({'opacity':'1'}, duration, 'linear', function() {
        current.css('margin', '100%');
        callback();
      });
    };

    this.prev = function(current, prev, callback) {
      prev.css({'margin':'0%', 'opacity':'0.01'});
      prev.animate({'opacity':'1'}, duration, 'linear', function() {
        current.css('margin', '100%');
        callback();
      });
    };
  };


  Foundation.libs = Foundation.libs || {};

  Foundation.libs.orbit = {
    name: 'orbit',

    version: '4.3.2',

    settings: {
      animation: 'slide',
      timer_speed: 10000,
      pause_on_hover: true,
      resume_on_mouseout: false,
      animation_speed: 500,
      stack_on_small: false,
      navigation_arrows: true,
      slide_number: true,
      slide_number_text: 'of',
      container_class: 'orbit-container',
      stack_on_small_class: 'orbit-stack-on-small',
      next_class: 'orbit-next',
      prev_class: 'orbit-prev',
      timer_container_class: 'orbit-timer',
      timer_paused_class: 'paused',
      timer_progress_class: 'orbit-progress',
      slides_container_class: 'orbit-slides-container',
      bullets_container_class: 'orbit-bullets',
      bullets_active_class: 'active',
      slide_number_class: 'orbit-slide-number',
      caption_class: 'orbit-caption',
      active_slide_class: 'active',
      orbit_transition_class: 'orbit-transitioning',
      bullets: true,
      timer: true,
      variable_height: false,
      swipe: true,
      before_slide_change: noop,
      after_slide_change: noop
    },

    init: function (scope, method, options) {
      var self = this;
      Foundation.inherit(self, 'data_options');

      if (typeof method === 'object') {
        $.extend(true, self.settings, method);
      }

      if ($(scope).is('[data-orbit]')) {
        var $el = $(scope);
        var opts = self.data_options($el);
        new Orbit($el, $.extend({},self.settings, opts));
      }

      $('[data-orbit]', scope).each(function(idx, el) {
        var $el = $(el);
        var opts = self.data_options($el);
        new Orbit($el, $.extend({},self.settings, opts));
      });
    }
  };

    
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.reveal = {
    name : 'reveal',

    version : '4.3.2',

    locked : false,

    settings : {
      animation: 'fadeAndPop',
      animationSpeed: 250,
      closeOnBackgroundClick: true,
      closeOnEsc: true,
      dismissModalClass: 'close-reveal-modal',
      bgClass: 'reveal-modal-bg',
      open: function(){},
      opened: function(){},
      close: function(){},
      closed: function(){},
      bg : $('.reveal-modal-bg'),
      css : {
        open : {
          'opacity': 0,
          'visibility': 'visible',
          'display' : 'block'
        },
        close : {
          'opacity': 1,
          'visibility': 'hidden',
          'display': 'none'
        }
      }
    },

    init : function (scope, method, options) {
      Foundation.inherit(this, 'data_options delay');

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      } else if (typeof options !== 'undefined') {
        $.extend(true, this.settings, options);
      }

      if (typeof method !== 'string') {
        this.events();

        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;

      $(this.scope)
        .off('.fndtn.reveal')
        .on('click.fndtn.reveal', '[data-reveal-id]', function (e) {
          e.preventDefault();

          if (!self.locked) {
            var element = $(this),
                ajax = element.data('reveal-ajax');

            self.locked = true;

            if (typeof ajax === 'undefined') {
              self.open.call(self, element);
            } else {
              var url = ajax === true ? element.attr('href') : ajax;

              self.open.call(self, element, {url: url});
            }
          }
        })
        .on('click.fndtn.reveal touchend', this.close_targets(), function (e) {
          e.preventDefault();
          if (!self.locked) {
            var settings = $.extend({}, self.settings, self.data_options($('.reveal-modal.open'))),
              bgClicked = $(e.target)[0] === $('.' + settings.bgClass)[0];
            if (bgClicked && !settings.closeOnBackgroundClick) {
              return;
            }

            self.locked = true;
            self.close.call(self, bgClicked ? $('.reveal-modal.open') : $(this).closest('.reveal-modal'));
          }
        });

      if($(this.scope).hasClass('reveal-modal')) {
        $(this.scope)
          .on('open.fndtn.reveal', this.settings.open)
          .on('opened.fndtn.reveal', this.settings.opened)
          .on('opened.fndtn.reveal', this.open_video)
          .on('close.fndtn.reveal', this.settings.close)
          .on('closed.fndtn.reveal', this.settings.closed)
          .on('closed.fndtn.reveal', this.close_video);
      } else {
        $(this.scope)
          .on('open.fndtn.reveal', '.reveal-modal', this.settings.open)
          .on('opened.fndtn.reveal', '.reveal-modal', this.settings.opened)
          .on('opened.fndtn.reveal', '.reveal-modal', this.open_video)
          .on('close.fndtn.reveal', '.reveal-modal', this.settings.close)
          .on('closed.fndtn.reveal', '.reveal-modal', this.settings.closed)
          .on('closed.fndtn.reveal', '.reveal-modal', this.close_video);
      }

      $( 'body' ).bind( 'keyup.reveal', function ( event ) {
        var open_modal = $('.reveal-modal.open'),
            settings = $.extend({}, self.settings, self.data_options(open_modal));
        if ( event.which === 27  && settings.closeOnEsc) { // 27 is the keycode for the Escape key
          open_modal.foundation('reveal', 'close');
        }
      });

      return true;
    },

    open : function (target, ajax_settings) {
      if (target) {
        if (typeof target.selector !== 'undefined') {
          var modal = $('#' + target.data('reveal-id'));
        } else {
          var modal = $(this.scope);

          ajax_settings = target;
        }
      } else {
        var modal = $(this.scope);
      }

      if (!modal.hasClass('open')) {
        var open_modal = $('.reveal-modal.open');

        if (typeof modal.data('css-top') === 'undefined') {
          modal.data('css-top', parseInt(modal.css('top'), 10))
            .data('offset', this.cache_offset(modal));
        }

        modal.trigger('open');

        if (open_modal.length < 1) {
          this.toggle_bg();
        }

        if (typeof ajax_settings === 'undefined' || !ajax_settings.url) {
          this.hide(open_modal, this.settings.css.close);
          this.show(modal, this.settings.css.open);
        } else {
          var self = this,
              old_success = typeof ajax_settings.success !== 'undefined' ? ajax_settings.success : null;

          $.extend(ajax_settings, {
            success: function (data, textStatus, jqXHR) {
              if ( $.isFunction(old_success) ) {
                old_success(data, textStatus, jqXHR);
              }

              modal.html(data);
              $(modal).foundation('section', 'reflow');

              self.hide(open_modal, self.settings.css.close);
              self.show(modal, self.settings.css.open);
            }
          });

          $.ajax(ajax_settings);
        }
      }
    },

    close : function (modal) {

      var modal = modal && modal.length ? modal : $(this.scope),
          open_modals = $('.reveal-modal.open');

      if (open_modals.length > 0) {
        this.locked = true;
        modal.trigger('close');
        this.toggle_bg();
        this.hide(open_modals, this.settings.css.close);
      }
    },

    close_targets : function () {
      var base = '.' + this.settings.dismissModalClass;

      if (this.settings.closeOnBackgroundClick) {
        return base + ', .' + this.settings.bgClass;
      }

      return base;
    },

    toggle_bg : function () {
      if ($('.' + this.settings.bgClass).length === 0) {
        this.settings.bg = $('<div />', {'class': this.settings.bgClass})
          .appendTo('body');
      }

      if (this.settings.bg.filter(':visible').length > 0) {
        this.hide(this.settings.bg);
      } else {
        this.show(this.settings.bg);
      }
    },

    show : function (el, css) {
      // is modal
      if (css) {
        if (el.parent('body').length === 0) {
          var placeholder = el.wrap('<div style="display: none;" />').parent();
          el.on('closed.fndtn.reveal.wrapped', function() {
            el.detach().appendTo(placeholder);
            el.unwrap().unbind('closed.fndtn.reveal.wrapped');
          });

          el.detach().appendTo('body');
        }

        if (/pop/i.test(this.settings.animation)) {
          css.top = $(window).scrollTop() - el.data('offset') + 'px';
          var end_css = {
            top: $(window).scrollTop() + el.data('css-top') + 'px',
            opacity: 1
          };

          return this.delay(function () {
            return el
              .css(css)
              .animate(end_css, this.settings.animationSpeed, 'linear', function () {
                this.locked = false;
                el.trigger('opened');
              }.bind(this))
              .addClass('open');
          }.bind(this), this.settings.animationSpeed / 2);
        }

        if (/fade/i.test(this.settings.animation)) {
          var end_css = {opacity: 1};

          return this.delay(function () {
            return el
              .css(css)
              .animate(end_css, this.settings.animationSpeed, 'linear', function () {
                this.locked = false;
                el.trigger('opened');
              }.bind(this))
              .addClass('open');
          }.bind(this), this.settings.animationSpeed / 2);
        }

        return el.css(css).show().css({opacity: 1}).addClass('open').trigger('opened');
      }

      // should we animate the background?
      if (/fade/i.test(this.settings.animation)) {
        return el.fadeIn(this.settings.animationSpeed / 2);
      }

      return el.show();
    },

    hide : function (el, css) {
      // is modal
      if (css) {
        if (/pop/i.test(this.settings.animation)) {
          var end_css = {
            top: - $(window).scrollTop() - el.data('offset') + 'px',
            opacity: 0
          };

          return this.delay(function () {
            return el
              .animate(end_css, this.settings.animationSpeed, 'linear', function () {
                this.locked = false;
                el.css(css).trigger('closed');
              }.bind(this))
              .removeClass('open');
          }.bind(this), this.settings.animationSpeed / 2);
        }

        if (/fade/i.test(this.settings.animation)) {
          var end_css = {opacity: 0};

          return this.delay(function () {
            return el
              .animate(end_css, this.settings.animationSpeed, 'linear', function () {
                this.locked = false;
                el.css(css).trigger('closed');
              }.bind(this))
              .removeClass('open');
          }.bind(this), this.settings.animationSpeed / 2);
        }

        return el.hide().css(css).removeClass('open').trigger('closed');
      }

      // should we animate the background?
      if (/fade/i.test(this.settings.animation)) {
        return el.fadeOut(this.settings.animationSpeed / 2);
      }

      return el.hide();
    },

    close_video : function (e) {
      var video = $(this).find('.flex-video'),
          iframe = video.find('iframe');

      if (iframe.length > 0) {
        iframe.attr('data-src', iframe[0].src);
        iframe.attr('src', 'about:blank');
        video.hide();
      }
    },

    open_video : function (e) {
      var video = $(this).find('.flex-video'),
          iframe = video.find('iframe');

      if (iframe.length > 0) {
        var data_src = iframe.attr('data-src');
        if (typeof data_src === 'string') {
          iframe[0].src = iframe.attr('data-src');
        } else {
          var src = iframe[0].src;
          iframe[0].src = undefined;
          iframe[0].src = src;
        }
        video.show();
      }
    },

    cache_offset : function (modal) {
      var offset = modal.show().height() + parseInt(modal.css('top'), 10);

      modal.hide();

      return offset;
    },

    off : function () {
      $(this.scope).off('.fndtn.reveal');
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;
(function($, window, document) {
  'use strict';

  Foundation.libs.section = {
    name : 'section',

    version : '4.3.2',

    settings: {
      deep_linking: false,
      small_breakpoint: 768,
      one_up: true,
      multi_expand: false,
      section_selector: '[data-section]',
      region_selector: 'section, .section, [data-section-region]',
      title_selector: '.title, [data-section-title]',
      //marker: container is resized
      resized_data_attr: 'data-section-resized',
      //marker: container should apply accordion style
      small_style_data_attr: 'data-section-small-style',
      content_selector: '.content, [data-section-content]',
      nav_selector: '[data-section="vertical-nav"], [data-section="horizontal-nav"]',
      active_class: 'active',
      callback: function() {}
    },

    init: function(scope, method, options) {
      var self = this;
      Foundation.inherit(this, 'throttle data_options position_right offset_right');

      if (typeof method === 'object') {
        $.extend(true, self.settings, method);
      }

      if (typeof method !== 'string') {
        this.events();
        return true;
      } else {
        return this[method].call(this, options);
      }
    },

    events: function() {
      var self = this;

      //combine titles selector from settings for click event binding
      var click_title_selectors = [],
          section_selector = self.settings.section_selector,
          region_selectors = self.settings.region_selector.split(","),
          title_selectors = self.settings.title_selector.split(",");

      for (var i = 0, len = region_selectors.length; i < len; i++) {
        var region_selector = region_selectors[i];

        for (var j = 0, len1 = title_selectors.length; j < len1; j++) {
          var title_selector = section_selector + ">" + region_selector + ">" + title_selectors[j];

          click_title_selectors.push(title_selector + " a"); //or we can not do preventDefault for click event of <a>
          click_title_selectors.push(title_selector);
        }
      }

      $(self.scope)
        .on('click.fndtn.section', click_title_selectors.join(","), function(e) {
          var title = $(this).closest(self.settings.title_selector);

          self.close_navs(title);
          if (title.siblings(self.settings.content_selector).length > 0) {
            self.toggle_active.call(title[0], e);
          }
        });

      $(window)
        .on('resize.fndtn.section', self.throttle(function() { self.resize(); }, 30))
        .on('hashchange.fndtn.section', self.set_active_from_hash);

      $(document).on('click.fndtn.section', function (e) {
        if (e.isPropagationStopped && e.isPropagationStopped()) return;
        if (e.target === document) return;
        self.close_navs($(e.target).closest(self.settings.title_selector));
      });

      $(window).triggerHandler('resize.fndtn.section');
      $(window).triggerHandler('hashchange.fndtn.section');
    },
    
    //close nav !one_up on click elsewhere
    close_navs: function(except_nav_with_title) {
      var self = Foundation.libs.section,
          navsToClose = $(self.settings.nav_selector)
            .filter(function() { return !$.extend({}, 
              self.settings, self.data_options($(this))).one_up; });

      if (except_nav_with_title.length > 0) {
        var section = except_nav_with_title.parent().parent();

        if (self.is_horizontal_nav(section) || self.is_vertical_nav(section)) {
          //exclude current nav from list
          navsToClose = navsToClose.filter(function() { return this !== section[0]; });
        }
      }
      //close navs on click on title
      navsToClose.children(self.settings.region_selector).removeClass(self.settings.active_class);
    },

    toggle_active: function(e) {
      var $this = $(this),
          self = Foundation.libs.section,
          region = $this.parent(),
          content = $this.siblings(self.settings.content_selector),
          section = region.parent(),
          settings = $.extend({}, self.settings, self.data_options(section)),
          prev_active_region = section.children(self.settings.region_selector).filter("." + self.settings.active_class);

      //for anchors inside [data-section-title]
      if (!settings.deep_linking && content.length > 0) {
        e.preventDefault();
      }

      e.stopPropagation(); //do not catch same click again on parent

      if (!region.hasClass(self.settings.active_class)) {
        if (!self.is_accordion(section) || (self.is_accordion(section) && !self.settings.multi_expand)) {
          prev_active_region.removeClass(self.settings.active_class);
          prev_active_region.trigger('closed.fndtn.section');
        }
        region.addClass(self.settings.active_class);
        //force resize for better performance (do not wait timer)
        self.resize(region.find(self.settings.section_selector).not("[" + self.settings.resized_data_attr + "]"), true);
        region.trigger('opened.fndtn.section');
      } else if (region.hasClass(self.settings.active_class) && self.is_accordion(section) || !settings.one_up && (self.small(section) || self.is_vertical_nav(section) || self.is_horizontal_nav(section) || self.is_accordion(section))) {
        region.removeClass(self.settings.active_class);
        region.trigger('closed.fndtn.section');
      }
      settings.callback(section);
    },

    check_resize_timer: null,

    //main function that sets title and content positions; runs for :not(.resized) and :visible once when window width is medium up
    //sections:
    //  selected sections to resize, are defined on resize forced by visibility changes
    //ensure_has_active_region:
    //  is true when we force resize for no resized sections that were hidden and became visible, 
    //  these sections can have no selected region, because all regions were hidden along with section on executing set_active_from_hash
    resize: function(sections, ensure_has_active_region) {

      var self = Foundation.libs.section,
          section_container = $(self.settings.section_selector),
          is_small_window = self.small(section_container),
          //filter for section resize
          should_be_resized = function (section, now_is_hidden) {
            return !self.is_accordion(section) && 
              !section.is("[" + self.settings.resized_data_attr + "]") && 
              (!is_small_window || self.is_horizontal_tabs(section)) && 
              now_is_hidden === (section.css('display') === 'none' || 
              !section.parent().is(':visible'));
          };

      sections = sections || $(self.settings.section_selector);

      clearTimeout(self.check_resize_timer);

      if (!is_small_window) {
        sections.removeAttr(self.settings.small_style_data_attr);
      }

      //resize
      sections.filter(function() { return should_be_resized($(this), false); })
        .each(function() {
          var section = $(this),
            regions = section.children(self.settings.region_selector),
            titles = regions.children(self.settings.title_selector),
            content = regions.children(self.settings.content_selector),
            titles_max_height = 0;

          if (ensure_has_active_region && 
            section.children(self.settings.region_selector).filter("." + self.settings.active_class).length == 0) {
            var settings = $.extend({}, self.settings, self.data_options(section));

            if (!settings.deep_linking && (settings.one_up || !self.is_horizontal_nav(section) &&
              !self.is_vertical_nav(section) && !self.is_accordion(section))) {
                regions.filter(":visible").first().addClass(self.settings.active_class);
            }
          }

          if (self.is_horizontal_tabs(section) || self.is_auto(section)) {
            //    region: position relative
            //    title: position absolute
            //    content: position static
            var titles_sum_width = 0;

            titles.each(function() {
              var title = $(this);

              if (title.is(":visible")) {
                title.css(!self.rtl ? 'left' : 'right', titles_sum_width);
                var title_h_border_width = parseInt(title.css("border-" + (self.rtl ? 'left' : 'right') + "-width"), 10);

                if (title_h_border_width.toString() === 'Nan') {
                  title_h_border_width = 0;
                }

                titles_sum_width += self.outerWidth(title) - title_h_border_width;
                titles_max_height = Math.max(titles_max_height, self.outerHeight(title));
              }
            });
            titles.css('height', titles_max_height);
            regions.each(function() {
              var region = $(this),
                  region_content = region.children(self.settings.content_selector),
                  content_top_border_width = parseInt(region_content.css("border-top-width"), 10);

              if (content_top_border_width.toString() === 'Nan') {
                content_top_border_width = 0;
              }

              region.css('padding-top', titles_max_height - content_top_border_width);
            });

            section.css("min-height", titles_max_height);
          } else if (self.is_horizontal_nav(section)) {
            var first = true;
            //    region: positon relative, float left
            //    title: position static
            //    content: position absolute
            titles.each(function() {
              titles_max_height = Math.max(titles_max_height, self.outerHeight($(this)));
            });

            regions.each(function() {
              var region = $(this);

              region.css("margin-left", "-" + (first ? section : region.children(self.settings.title_selector)).css("border-left-width"));
              first = false;
            });

            regions.css("margin-top", "-" + section.css("border-top-width"));
            titles.css('height', titles_max_height);
            content.css('top', titles_max_height);
            section.css("min-height", titles_max_height);
          } else if (self.is_vertical_tabs(section)) {
            var titles_sum_height = 0;
            //    region: position relative, for .active: fixed padding==title.width
            //    title: fixed width, position absolute
            //    content: position static
            titles.each(function() {
              var title = $(this);

              if (title.is(":visible")) {
                title.css('top', titles_sum_height);
                var title_top_border_width = parseInt(title.css("border-top-width"), 10);

                if (title_top_border_width.toString() === 'Nan') {
                  title_top_border_width = 0;
                }

                titles_sum_height += self.outerHeight(title) - title_top_border_width;
              }
            });

            content.css('min-height', titles_sum_height + 1);
          } else if (self.is_vertical_nav(section)) {
            var titles_max_width = 0,
                first1 = true;
            //    region: positon relative
            //    title: position static
            //    content: position absolute
            titles.each(function() {
              titles_max_width = Math.max(titles_max_width, self.outerWidth($(this)));
            });

            regions.each(function () {
              var region = $(this);

              region.css("margin-top", "-" + (first1 ? section : region.children(self.settings.title_selector)).css("border-top-width"));
              first1 = false;
            });

            titles.css('width', titles_max_width);
            content.css(!self.rtl ? 'left' : 'right', titles_max_width);
            section.css('width', titles_max_width);
          }

          section.attr(self.settings.resized_data_attr, true);
        });

      //wait elements to become visible then resize
      if ($(self.settings.section_selector).filter(function() { return should_be_resized($(this), true); }).length > 0)
        self.check_resize_timer = setTimeout(function() {
          self.resize(sections.filter(function() { return should_be_resized($(this), false); }), true);
        }, 700);

      if (is_small_window) {
        sections.attr(self.settings.small_style_data_attr, true);
      }
    },

    is_vertical_nav: function(el) {
      return /vertical-nav/i.test(el.data('section'));
    },

    is_horizontal_nav: function(el) {
      return /horizontal-nav/i.test(el.data('section'));
    },

    is_accordion: function(el) {
      return /accordion/i.test(el.data('section'));
    },

    is_horizontal_tabs: function(el) {
      return /^tabs$/i.test(el.data('section'));
    },

    is_vertical_tabs: function(el) {
      return /vertical-tabs/i.test(el.data('section'));
    },
    
    is_auto: function (el) {
      var data_section = el.data('section');
      return data_section === '' || /auto/i.test(data_section);
    },

    set_active_from_hash: function() {
      var self = Foundation.libs.section,
          hash = window.location.hash.substring(1),
          sections = $(self.settings.section_selector);

      var selectedSection;
      
      sections.each(function() {
          var section = $(this),
          regions = section.children(self.settings.region_selector);
          regions.each(function() {
            var region = $(this),
            data_slug = region.children(self.settings.content_selector).data('slug');
            if (new RegExp(data_slug, 'i').test(hash)) {
              selectedSection=section;
              return false;
              }
          });
          
          if (selectedSection != null) {
            return false;
          }
      });
      
      if (selectedSection != null) {
        sections.each(function() {
          if (selectedSection == $(this)) {
            var section = $(this),
                settings = $.extend({}, self.settings, self.data_options(section)),
                regions = section.children(self.settings.region_selector),
                set_active_from_hash = settings.deep_linking && hash.length > 0,
                selected = false;
    
            regions.each(function() {
              var region = $(this);
    
              if (selected) {
                region.removeClass(self.settings.active_class);
              } else if (set_active_from_hash) {
                var data_slug = region.children(self.settings.content_selector).data('slug');
    
                if (data_slug && new RegExp(data_slug, 'i').test(hash)) {
                  if (!region.hasClass(self.settings.active_class))
                    region.addClass(self.settings.active_class);
                  selected = true;
                } else {
                  region.removeClass(self.settings.active_class);
                }
              } else if (region.hasClass(self.settings.active_class)) {
                selected = true;
              }
            });
    
            if (!selected && (settings.one_up || !self.is_horizontal_nav(section) &&
             !self.is_vertical_nav(section) && !self.is_accordion(section)))
              regions.filter(":visible").first().addClass(self.settings.active_class);
          }
        });
      }
    },

    reflow: function() {
      var self = Foundation.libs.section;

      $(self.settings.section_selector).removeAttr(self.settings.resized_data_attr);
      self.throttle(function() { self.resize(); }, 30)();
    },

    small: function(el) {
      var settings = $.extend({}, this.settings, this.data_options(el));

      if (this.is_horizontal_tabs(el)) {
        return false;
      }
      if (el && this.is_accordion(el)) {
        return true;
      }
      if ($('html').hasClass('lt-ie9')) {
        return true;
      }
      if ($('html').hasClass('ie8compat')) {
        return true;
      }
      return $(this.scope).width() < settings.small_breakpoint;
    },

    off: function() {
      $(this.scope).off('.fndtn.section');
      $(window).off('.fndtn.section');
      $(document).off('.fndtn.section');
    }
  };

  //resize selected sections
  $.fn.reflow_section = function(ensure_has_active_region) {
    var section = this,
        self = Foundation.libs.section;

    section.removeAttr(self.settings.resized_data_attr);
    self.throttle(function() { self.resize(section, ensure_has_active_region); }, 30)();
    return this;
  };

}(Foundation.zj, window, document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.tooltips = {
    name : 'tooltips',

    version : '4.3.2',

    settings : {
      selector : '.has-tip',
      additionalInheritableClasses : [],
      tooltipClass : '.tooltip',
      touchCloseText: 'tap to close',
      appendTo: 'body',
      'disable-for-touch': false,
      tipTemplate : function (selector, content) {
        return '<span data-selector="' + selector + '" class="' 
          + Foundation.libs.tooltips.settings.tooltipClass.substring(1) 
          + '">' + content + '<span class="nub"></span></span>';
      }
    },

    cache : {},

    init : function (scope, method, options) {
      Foundation.inherit(this, 'data_options');
      var self = this;

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      } else if (typeof options !== 'undefined') {
        $.extend(true, this.settings, options);
      }

      if (typeof method !== 'string') {
        if (Modernizr.touch) {
          $(this.scope)
            .on('click.fndtn.tooltip touchstart.fndtn.tooltip touchend.fndtn.tooltip', 
              '[data-tooltip]', function (e) {
              var settings = $.extend({}, self.settings, self.data_options($(this)));
              if (!settings['disable-for-touch']) {
                e.preventDefault();
                $(settings.tooltipClass).hide();
                self.showOrCreateTip($(this));
              }
            })
            .on('click.fndtn.tooltip touchstart.fndtn.tooltip touchend.fndtn.tooltip', 
              this.settings.tooltipClass, function (e) {
              e.preventDefault();
              $(this).fadeOut(150);
            });
        } else {
          $(this.scope)
            .on('mouseenter.fndtn.tooltip mouseleave.fndtn.tooltip', 
              '[data-tooltip]', function (e) {
              var $this = $(this);

              if (/enter|over/i.test(e.type)) {
                self.showOrCreateTip($this);
              } else if (e.type === 'mouseout' || e.type === 'mouseleave') {
                self.hide($this);
              }
            });
        }

        // $(this.scope).data('fndtn-tooltips', true);
      } else {
        return this[method].call(this, options);
      }

    },

    showOrCreateTip : function ($target) {
      var $tip = this.getTip($target);

      if ($tip && $tip.length > 0) {
        return this.show($target);
      }

      return this.create($target);
    },

    getTip : function ($target) {
      var selector = this.selector($target),
          tip = null;

      if (selector) {
        tip = $('span[data-selector="' + selector + '"]' + this.settings.tooltipClass);
      }

      return (typeof tip === 'object') ? tip : false;
    },

    selector : function ($target) {
      var id = $target.attr('id'),
          dataSelector = $target.attr('data-tooltip') || $target.attr('data-selector');

      if ((id && id.length < 1 || !id) && typeof dataSelector != 'string') {
        dataSelector = 'tooltip' + Math.random().toString(36).substring(7);
        $target.attr('data-selector', dataSelector);
      }

      return (id && id.length > 0) ? id : dataSelector;
    },

    create : function ($target) {
      var $tip = $(this.settings.tipTemplate(this.selector($target), $('<div></div>').html($target.attr('title')).html())),
          classes = this.inheritable_classes($target);

      $tip.addClass(classes).appendTo(this.settings.appendTo);
      if (Modernizr.touch) {
        $tip.append('<span class="tap-to-close">'+this.settings.touchCloseText+'</span>');
      }
      $target.removeAttr('title').attr('title','');
      this.show($target);
    },

    reposition : function (target, tip, classes) {
      var width, nub, nubHeight, nubWidth, column, objPos;

      tip.css('visibility', 'hidden').show();

      width = target.data('width');
      nub = tip.children('.nub');
      nubHeight = this.outerHeight(nub);
      nubWidth = this.outerHeight(nub);

      objPos = function (obj, top, right, bottom, left, width) {
        return obj.css({
          'top' : (top) ? top : 'auto',
          'bottom' : (bottom) ? bottom : 'auto',
          'left' : (left) ? left : 'auto',
          'right' : (right) ? right : 'auto',
          'width' : (width) ? width : 'auto'
        }).end();
      };

      objPos(tip, (target.offset().top + this.outerHeight(target) + 10), 'auto', 'auto', target.offset().left, width);

      if ($(window).width() < 767) {
        objPos(tip, (target.offset().top + this.outerHeight(target) + 10), 'auto', 'auto', 12.5, $(this.scope).width());
        tip.addClass('tip-override');
        objPos(nub, -nubHeight, 'auto', 'auto', target.offset().left);
      } else {
        var left = target.offset().left;
        if (Foundation.rtl) {
          left = target.offset().left + target.offset().width - this.outerWidth(tip);
        }
        objPos(tip, (target.offset().top + this.outerHeight(target) + 10), 'auto', 'auto', left, width);
        tip.removeClass('tip-override');
        if (classes && classes.indexOf('tip-top') > -1) {
          objPos(tip, (target.offset().top - this.outerHeight(tip)), 'auto', 'auto', left, width)
            .removeClass('tip-override');
        } else if (classes && classes.indexOf('tip-left') > -1) {
          objPos(tip, (target.offset().top + (this.outerHeight(target) / 2) - nubHeight*2.5), 'auto', 'auto', (target.offset().left - this.outerWidth(tip) - nubHeight), width)
            .removeClass('tip-override');
        } else if (classes && classes.indexOf('tip-right') > -1) {
          objPos(tip, (target.offset().top + (this.outerHeight(target) / 2) - nubHeight*2.5), 'auto', 'auto', (target.offset().left + this.outerWidth(target) + nubHeight), width)
            .removeClass('tip-override');
        }
      }

      tip.css('visibility', 'visible').hide();
    },

    inheritable_classes : function (target) {
      var inheritables = ['tip-top', 'tip-left', 'tip-bottom', 'tip-right', 'noradius'].concat(this.settings.additionalInheritableClasses),
          classes = target.attr('class'),
          filtered = classes ? $.map(classes.split(' '), function (el, i) {
            if ($.inArray(el, inheritables) !== -1) {
              return el;
            }
          }).join(' ') : '';

      return $.trim(filtered);
    },

    show : function ($target) {
      var $tip = this.getTip($target);

      this.reposition($target, $tip, $target.attr('class'));
      $tip.fadeIn(150);
    },

    hide : function ($target) {
      var $tip = this.getTip($target);

      $tip.fadeOut(150);
    },

    // deprecate reload
    reload : function () {
      var $self = $(this);

      return ($self.data('fndtn-tooltips')) ? $self.foundationTooltips('destroy').foundationTooltips('init') : $self.foundationTooltips('init');
    },

    off : function () {
      $(this.scope).off('.fndtn.tooltip');
      $(this.settings.tooltipClass).each(function (i) {
        $('[data-tooltip]').get(i).attr('title', $(this).text());
      }).remove();
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.topbar = {
    name : 'topbar',

    version: '4.3.2',

    settings : {
      index : 0,
      stickyClass : 'sticky',
      custom_back_text: true,
      back_text: 'Back',
      is_hover: true,
      mobile_show_parent_link: false,
      scrolltop : true, // jump to top when sticky nav menu toggle is clicked
      init : false
    },

    init : function (section, method, options) {
      Foundation.inherit(this, 'data_options addCustomRule');
      var self = this;

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      } else if (typeof options !== 'undefined') {
        $.extend(true, this.settings, options);
      }

      if (typeof method !== 'string') {

        $('.top-bar, [data-topbar]').each(function () {
          $.extend(true, self.settings, self.data_options($(this)));
          self.settings.$w = $(window);
          self.settings.$topbar = $(this);
          self.settings.$section = self.settings.$topbar.find('section');
          self.settings.$titlebar = self.settings.$topbar.children('ul').first();
          self.settings.$topbar.data('index', 0);

          var topbarContainer = self.settings.$topbar.parent();
          if(topbarContainer.hasClass('fixed') || topbarContainer.hasClass(self.settings.stickyClass)) {
            self.settings.$topbar.data('height', self.outerHeight(topbarContainer));
            self.settings.$topbar.data('stickyoffset', topbarContainer.offset().top);
          } else {
            self.settings.$topbar.data('height', self.outerHeight(self.settings.$topbar));
          }

          var breakpoint = $("<div class='top-bar-js-breakpoint'/>").insertAfter(self.settings.$topbar);
          self.settings.breakPoint = breakpoint.width();
          breakpoint.remove();

          self.assemble();

          if (self.settings.is_hover) {
            self.settings.$topbar.find('.has-dropdown').addClass('not-click');
          }

          // Pad body when sticky (scrolled) or fixed.
          self.addCustomRule('.f-topbar-fixed { padding-top: ' + self.settings.$topbar.data('height') + 'px }');

          if (self.settings.$topbar.parent().hasClass('fixed')) {
            $('body').addClass('f-topbar-fixed');
          }
        });

        if (!self.settings.init) {
          this.events();
        }

        return this.settings.init;
      } else {
        // fire method
        return this[method].call(this, options);
      }
    },

    toggle: function() {
      var self = this;
      var topbar = $('.top-bar, [data-topbar]'),
          section = topbar.find('section, .section');

      if (self.breakpoint()) {
        if (!self.rtl) {
          section.css({left: '0%'});
          section.find('>.name').css({left: '100%'});
        } else {
          section.css({right: '0%'});
          section.find('>.name').css({right: '100%'});
        }

        section.find('li.moved').removeClass('moved');
        topbar.data('index', 0);

        topbar
          .toggleClass('expanded')
          .css('height', '');
      }

      if(self.settings.scrolltop)
      {
        if (!topbar.hasClass('expanded')) {
          if (topbar.hasClass('fixed')) {
            topbar.parent().addClass('fixed');
            topbar.removeClass('fixed');
            $('body').addClass('f-topbar-fixed');
          }
        } else if (topbar.parent().hasClass('fixed')) {
          if (self.settings.scrolltop) {
            topbar.parent().removeClass('fixed');
            topbar.addClass('fixed');
            $('body').removeClass('f-topbar-fixed');

            window.scrollTo(0,0);
          } else {
              topbar.parent().removeClass('expanded');
          }
        }
      } else {
        if(topbar.parent().hasClass(self.settings.stickyClass)) {
          topbar.parent().addClass('fixed');
        }

        if(topbar.parent().hasClass('fixed')) {
          if (!topbar.hasClass('expanded')) {
            topbar.removeClass('fixed');
            topbar.parent().removeClass('expanded');
            self.updateStickyPositioning();
          } else {
            topbar.addClass('fixed');
            topbar.parent().addClass('expanded');
          }
        }
      }
    },

    timer : null,

    events : function () {
      var self = this;
      $(this.scope)
        .off('.fndtn.topbar')
        .on('click.fndtn.topbar', '.top-bar .toggle-topbar, [data-topbar] .toggle-topbar', function (e) {
          e.preventDefault();
          self.toggle();
        })

        .on('click.fndtn.topbar', '.top-bar li.has-dropdown', function (e) {
          var li = $(this),
              target = $(e.target),
              topbar = li.closest('[data-topbar], .top-bar'),
              is_hover = topbar.data('topbar');

          if(target.data('revealId')) {
            self.toggle();
            return;
          }

          if (self.breakpoint()) return;
          if (self.settings.is_hover && !Modernizr.touch) return;

          e.stopImmediatePropagation();

          if (target[0].nodeName === 'A' && target.parent().hasClass('has-dropdown')) {
            e.preventDefault();
          }

          if (li.hasClass('hover')) {
            li
              .removeClass('hover')
              .find('li')
              .removeClass('hover');

            li.parents('li.hover')
              .removeClass('hover');
          } else {
            li.addClass('hover');
          }
        })

        .on('click.fndtn.topbar', '.top-bar .has-dropdown>a, [data-topbar] .has-dropdown>a', function (e) {
          if (self.breakpoint() && $(window).width() != self.settings.breakPoint) {

            e.preventDefault();

            var $this = $(this),
                topbar = $this.closest('.top-bar, [data-topbar]'),
                section = topbar.find('section, .section'),
                dropdownHeight = $this.next('.dropdown').outerHeight(),
                $selectedLi = $this.closest('li');

            topbar.data('index', topbar.data('index') + 1);
            $selectedLi.addClass('moved');

            if (!self.rtl) {
              section.css({left: -(100 * topbar.data('index')) + '%'});
              section.find('>.name').css({left: 100 * topbar.data('index') + '%'});
            } else {
              section.css({right: -(100 * topbar.data('index')) + '%'});
              section.find('>.name').css({right: 100 * topbar.data('index') + '%'});
            }

            topbar.css('height', self.outerHeight($this.siblings('ul'), true) + self.settings.$topbar.data('height'));
          }
        });

      $(window).on('resize.fndtn.topbar', function () {
        if (typeof self.settings.$topbar === 'undefined') { return; }
        var stickyContainer = self.settings.$topbar.parent('.' + this.settings.stickyClass);
        var stickyOffset;

        if (!self.breakpoint()) {
          var doToggle = self.settings.$topbar.hasClass('expanded');
          $('.top-bar, [data-topbar]')
            .css('height', '')
            .removeClass('expanded')
            .find('li')
            .removeClass('hover');

            if(doToggle) {
              self.toggle();
            }
        }

        if(stickyContainer.length > 0) {
          if(stickyContainer.hasClass('fixed')) {
            // Remove the fixed to allow for correct calculation of the offset.
            stickyContainer.removeClass('fixed');

            stickyOffset = stickyContainer.offset().top;
            if($(document.body).hasClass('f-topbar-fixed')) {
              stickyOffset -= self.settings.$topbar.data('height');
            }

            self.settings.$topbar.data('stickyoffset', stickyOffset);
            stickyContainer.addClass('fixed');
          } else {
            stickyOffset = stickyContainer.offset().top;
            self.settings.$topbar.data('stickyoffset', stickyOffset);
          }
        }
      }.bind(this));

      $('body').on('click.fndtn.topbar', function (e) {
        var parent = $(e.target).closest('li').closest('li.hover');

        if (parent.length > 0) {
          return;
        }

        $('.top-bar li, [data-topbar] li').removeClass('hover');
      });

      // Go up a level on Click
      $(this.scope).on('click.fndtn', '.top-bar .has-dropdown .back, [data-topbar] .has-dropdown .back', function (e) {
        e.preventDefault();

        var $this = $(this),
            topbar = $this.closest('.top-bar, [data-topbar]'),
            section = topbar.find('section, .section'),
            $movedLi = $this.closest('li.moved'),
            $previousLevelUl = $movedLi.parent();

        topbar.data('index', topbar.data('index') - 1);

        if (!self.rtl) {
          section.css({left: -(100 * topbar.data('index')) + '%'});
          section.find('>.name').css({left: 100 * topbar.data('index') + '%'});
        } else {
          section.css({right: -(100 * topbar.data('index')) + '%'});
          section.find('>.name').css({right: 100 * topbar.data('index') + '%'});
        }

        if (topbar.data('index') === 0) {
          topbar.css('height', '');
        } else {
          topbar.css('height', self.outerHeight($previousLevelUl, true) + self.settings.$topbar.data('height'));
        }

        setTimeout(function () {
          $movedLi.removeClass('moved');
        }, 300);
      });
    },

    breakpoint : function () {
      return $(document).width() <= this.settings.breakPoint || $('html').hasClass('lt-ie9');
    },

    assemble : function () {
      var self = this;
      // Pull element out of the DOM for manipulation
      this.settings.$section.detach();

      this.settings.$section.find('.has-dropdown>a').each(function () {
        var $link = $(this),
            $dropdown = $link.siblings('.dropdown'),
            url = $link.attr('href');

        if (self.settings.mobile_show_parent_link && url && url.length > 1) {
          var $titleLi = $('<li class="title back js-generated"><h5><a href="#"></a></h5></li><li><a class="parent-link js-generated" href="' + url + '">' + $link.text() +'</a></li>');
        } else {
          var $titleLi = $('<li class="title back js-generated"><h5><a href="#"></a></h5></li>');
        }

        // Copy link to subnav
        if (self.settings.custom_back_text == true) {
          $titleLi.find('h5>a').html(self.settings.back_text);
        } else {
          $titleLi.find('h5>a').html('&laquo; ' + $link.html());
        }
        $dropdown.prepend($titleLi);
      });

      // Put element back in the DOM
      this.settings.$section.appendTo(this.settings.$topbar);

      // check for sticky
      this.sticky();
    },

    height : function (ul) {
      var total = 0,
          self = this;

      ul.find('> li').each(function () { total += self.outerHeight($(this), true); });

      return total;
    },

    sticky : function () {
      var $window = $(window),
          self = this;

      $window.scroll(function() {
        self.updateStickyPositioning();
      });
    },

    updateStickyPositioning: function() {
      var klass = '.' + this.settings.stickyClass;
      var $window = $(window);

      if ($(klass).length > 0) {
        var distance = this.settings.$topbar.data('stickyoffset');
        if (!$(klass).hasClass('expanded')) {
          if ($window.scrollTop() > (distance)) {
            if (!$(klass).hasClass('fixed')) {
              $(klass).addClass('fixed');
              $('body').addClass('f-topbar-fixed');
            }
          } else if ($window.scrollTop() <= distance) {
            if ($(klass).hasClass('fixed')) {
              $(klass).removeClass('fixed');
              $('body').removeClass('f-topbar-fixed');
            }
          }
        }
      }
    },

    off : function () {
      $(this.scope).off('.fndtn.topbar');
      $(window).off('.fndtn.topbar');
    },

    reflow : function () {}
  };
}(Foundation.zj, this, this.document));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.interchange = {
    name : 'interchange',

    version : '4.2.4',

    cache : {},

    images_loaded : false,

    settings : {
      load_attr : 'interchange',

      named_queries : {
        'default' : 'only screen and (min-width: 1px)',
        small : 'only screen and (min-width: 768px)',
        medium : 'only screen and (min-width: 1280px)',
        large : 'only screen and (min-width: 1440px)',
        landscape : 'only screen and (orientation: landscape)',
        portrait : 'only screen and (orientation: portrait)',
        retina : 'only screen and (-webkit-min-device-pixel-ratio: 2),' + 
          'only screen and (min--moz-device-pixel-ratio: 2),' + 
          'only screen and (-o-min-device-pixel-ratio: 2/1),' + 
          'only screen and (min-device-pixel-ratio: 2),' + 
          'only screen and (min-resolution: 192dpi),' + 
          'only screen and (min-resolution: 2dppx)'
      },

      directives : {
        replace: function (el, path) {
          if (/IMG/.test(el[0].nodeName)) {
            var orig_path = el[0].src;

            if (new RegExp(path, 'i').test(orig_path)) return;

            el[0].src = path;

            return el.trigger('replace', [el[0].src, orig_path]);
          }
        }
      }
    },

    init : function (scope, method, options) {
      Foundation.inherit(this, 'throttle');

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      this.events();
      this.images();

      if (typeof method !== 'string') {
        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;

      $(window).on('resize.fndtn.interchange', self.throttle(function () {
        self.resize.call(self);
      }, 50));
    },

    resize : function () {
      var cache = this.cache;

      if(!this.images_loaded) {
        setTimeout($.proxy(this.resize, this), 50);
        return;
      }

      for (var uuid in cache) {
        if (cache.hasOwnProperty(uuid)) {
          var passed = this.results(uuid, cache[uuid]);

          if (passed) {
            this.settings.directives[passed
              .scenario[1]](passed.el, passed.scenario[0]);
          }
        }
      }

    },

    results : function (uuid, scenarios) {
      var count = scenarios.length;

      if (count > 0) {
        var el = $('[data-uuid="' + uuid + '"]');

        for (var i = count - 1; i >= 0; i--) {
          var mq, rule = scenarios[i][2];
          if (this.settings.named_queries.hasOwnProperty(rule)) {
            mq = matchMedia(this.settings.named_queries[rule]);
          } else {
            mq = matchMedia(rule);
          }
          if (mq.matches) {
            return {el: el, scenario: scenarios[i]};
          }
        }
      }

      return false;
    },

    images : function (force_update) {
      if (typeof this.cached_images === 'undefined' || force_update) {
        return this.update_images();
      }

      return this.cached_images;
    },

    update_images : function () {
      var images = document.getElementsByTagName('img'),
          count = images.length,
          loaded_count = 0,
          data_attr = 'data-' + this.settings.load_attr;

      this.cached_images = [];
      this.images_loaded = false;

      for (var i = count - 1; i >= 0; i--) {
        this.loaded($(images[i]), function (image) {
          loaded_count++;
          if (image) {
            var str = image.getAttribute(data_attr) || '';

            if (str.length > 0) {
              this.cached_images.push(image);
            }
          }

          if(loaded_count === count) {
            this.images_loaded = true;
            this.enhance();
          }
        }.bind(this));
      }

      return 'deferred';
    },

    // based on jquery.imageready.js
    // @weblinc, @jsantell, (c) 2012

    loaded : function (image, callback) {
      function loaded () {
        callback(image[0]);
      }

      function bindLoad () {
        this.one('load', loaded);

        if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
          var src = this.attr( 'src' ),
              param = src.match( /\?/ ) ? '&' : '?';

          param += 'random=' + (new Date()).getTime();
          this.attr('src', src + param);
        }
      }

      if (!image.attr('src')) {
        loaded();
        return;
      }

      if (image[0].complete || image[0].readyState === 4) {
        loaded();
      } else {
        bindLoad.call(image);
      }
    },

    enhance : function () {
      var count = this.images().length;

      for (var i = count - 1; i >= 0; i--) {
        this._object($(this.images()[i]));
      }

      return $(window).trigger('resize');
    },

    parse_params : function (path, directive, mq) {
      return [this.trim(path), this.convert_directive(directive), this.trim(mq)];
    },

    convert_directive : function (directive) {
      var trimmed = this.trim(directive);

      if (trimmed.length > 0) {
        return trimmed;
      }

      return 'replace';
    },

    _object : function(el) {
      var raw_arr = this.parse_data_attr(el),
          scenarios = [], count = raw_arr.length;

      if (count > 0) {
        for (var i = count - 1; i >= 0; i--) {
          var split = raw_arr[i].split(/\((.*?)(\))$/);

          if (split.length > 1) {
            var cached_split = split[0].split(','),
                params = this.parse_params(cached_split[0],
                  cached_split[1], split[1]);

            scenarios.push(params);
          }
        }
      }

      return this.store(el, scenarios);
    },

    uuid : function (separator) {
      var delim = separator || "-";

      function S4() {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
      }

      return (S4() + S4() + delim + S4() + delim + S4()
        + delim + S4() + delim + S4() + S4() + S4());
    },

    store : function (el, scenarios) {
      var uuid = this.uuid(),
          current_uuid = el.data('uuid');

      if (current_uuid) return this.cache[current_uuid];

      el.attr('data-uuid', uuid);

      return this.cache[uuid] = scenarios;
    },

    trim : function(str) {
      if (typeof str === 'string') {
        return $.trim(str);
      }

      return str;
    },

    parse_data_attr : function (el) {
      var raw = el.data(this.settings.load_attr).split(/\[(.*?)\]/),
          count = raw.length, output = [];

      for (var i = count - 1; i >= 0; i--) {
        if (raw[i].replace(/[\W\d]+/, '').length > 4) {
          output.push(raw[i]);
        }
      }

      return output;
    },

    reflow : function () {
      this.images(true);
    }

  };

}(Foundation.zj, this, this.document));
/* 
 * The MIT License
 *
 * Copyright (c) 2012 James Allardice
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), 
 * to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

// Defines the global Placeholders object along with various utility methods
(function (global) {

    "use strict";

    // Cross-browser DOM event binding
    function addEventListener(elem, event, fn) {
        if (elem.addEventListener) {
            return elem.addEventListener(event, fn, false);
        }
        if (elem.attachEvent) {
            return elem.attachEvent("on" + event, fn);
        }
    }

    // Check whether an item is in an array (we don't use Array.prototype.indexOf so we don't clobber any existing polyfills - this is a really simple alternative)
    function inArray(arr, item) {
        var i, len;
        for (i = 0, len = arr.length; i < len; i++) {
            if (arr[i] === item) {
                return true;
            }
        }
        return false;
    }

    // Move the caret to the index position specified. Assumes that the element has focus
    function moveCaret(elem, index) {
        var range;
        if (elem.createTextRange) {
            range = elem.createTextRange();
            range.move("character", index);
            range.select();
        } else if (elem.selectionStart) {
            elem.focus();
            elem.setSelectionRange(index, index);
        }
    }

    // Attempt to change the type property of an input element
    function changeType(elem, type) {
        try {
            elem.type = type;
            return true;
        } catch (e) {
            // You can't change input type in IE8 and below
            return false;
        }
    }

    // Expose public methods
    global.Placeholders = {
        Utils: {
            addEventListener: addEventListener,
            inArray: inArray,
            moveCaret: moveCaret,
            changeType: changeType
        }
    };

}(this));

(function (global) {

    "use strict";

    var validTypes = [
            "text",
            "search",
            "url",
            "tel",
            "email",
            "password",
            "number",
            "textarea"
        ],

        // The list of keycodes that are not allowed when the polyfill is configured to hide-on-input
        badKeys = [

            // The following keys all cause the caret to jump to the end of the input value
            27, // Escape
            33, // Page up
            34, // Page down
            35, // End
            36, // Home

            // Arrow keys allow you to move the caret manually, which should be prevented when the placeholder is visible
            37, // Left
            38, // Up
            39, // Right
            40, // Down

            // The following keys allow you to modify the placeholder text by removing characters, which should be prevented when the placeholder is visible
            8, // Backspace
            46 // Delete
        ],

        // Styling variables
        placeholderStyleColor = "#ccc",
        placeholderClassName = "placeholdersjs",
        classNameRegExp = new RegExp("(?:^|\\s)" + placeholderClassName + "(?!\\S)"),

        // These will hold references to all elements that can be affected. NodeList objects are live, so we only need to get those references once
        inputs, textareas,

        // The various data-* attributes used by the polyfill
        ATTR_CURRENT_VAL = "data-placeholder-value",
        ATTR_ACTIVE = "data-placeholder-active",
        ATTR_INPUT_TYPE = "data-placeholder-type",
        ATTR_FORM_HANDLED = "data-placeholder-submit",
        ATTR_EVENTS_BOUND = "data-placeholder-bound",
        ATTR_OPTION_FOCUS = "data-placeholder-focus",
        ATTR_OPTION_LIVE = "data-placeholder-live",

        // Various other variables used throughout the rest of the script
        test = document.createElement("input"),
        head = document.getElementsByTagName("head")[0],
        root = document.documentElement,
        Placeholders = global.Placeholders,
        Utils = Placeholders.Utils,
        hideOnInput, liveUpdates, keydownVal, styleElem, styleRules, placeholder, timer, form, elem, len, i;

    // No-op (used in place of public methods when native support is detected)
    function noop() {}

    // Hide the placeholder value on a single element. Returns true if the placeholder was hidden and false if it was not (because it wasn't visible in the first place)
    function hidePlaceholder(elem) {
        var type;
        if (elem.value === elem.getAttribute(ATTR_CURRENT_VAL) && elem.getAttribute(ATTR_ACTIVE) === "true") {
            elem.setAttribute(ATTR_ACTIVE, "false");
            elem.value = "";
            elem.className = elem.className.replace(classNameRegExp, "");

            // If the polyfill has changed the type of the element we need to change it back
            type = elem.getAttribute(ATTR_INPUT_TYPE);
            if (type) {
                elem.type = type;
            }
            return true;
        }
        return false;
    }

    // Show the placeholder value on a single element. Returns true if the placeholder was shown and false if it was not (because it was already visible)
    function showPlaceholder(elem) {
        var type,
            val = elem.getAttribute(ATTR_CURRENT_VAL);
        if (elem.value === "" && val) {
            elem.setAttribute(ATTR_ACTIVE, "true");
            elem.value = val;
            elem.className += " " + placeholderClassName;

            // If the type of element needs to change, change it (e.g. password inputs)
            type = elem.getAttribute(ATTR_INPUT_TYPE);
            if (type) {
                elem.type = "text";
            } else if (elem.type === "password") {
                if (Utils.changeType(elem, "text")) {
                    elem.setAttribute(ATTR_INPUT_TYPE, "password");
                }
            }
            return true;
        }
        return false;
    }

    function handleElem(node, callback) {

        var handleInputs, handleTextareas, elem, len, i;

        // Check if the passed in node is an input/textarea (in which case it can't have any affected descendants)
        if (node && node.getAttribute(ATTR_CURRENT_VAL)) {
            callback(node);
        } else {

            // If an element was passed in, get all affected descendants. Otherwise, get all affected elements in document
            handleInputs = node ? node.getElementsByTagName("input") : inputs;
            handleTextareas = node ? node.getElementsByTagName("textarea") : textareas;

            // Run the callback for each element
            for (i = 0, len = handleInputs.length + handleTextareas.length; i < len; i++) {
                elem = i < handleInputs.length ? handleInputs[i] : handleTextareas[i - handleInputs.length];
                callback(elem);
            }
        }
    }

    // Return all affected elements to their normal state (remove placeholder value if present)
    function disablePlaceholders(node) {
        handleElem(node, hidePlaceholder);
    }

    // Show the placeholder value on all appropriate elements
    function enablePlaceholders(node) {
        handleElem(node, showPlaceholder);
    }

    // Returns a function that is used as a focus event handler
    function makeFocusHandler(elem) {
        return function () {

            // Only hide the placeholder value if the (default) hide-on-focus behaviour is enabled
            if (hideOnInput && elem.value === elem.getAttribute(ATTR_CURRENT_VAL) && elem.getAttribute(ATTR_ACTIVE) === "true") {

                // Move the caret to the start of the input (this mimics the behaviour of all browsers that do not hide the placeholder on focus)
                Utils.moveCaret(elem, 0);

            } else {

                // Remove the placeholder
                hidePlaceholder(elem);
            }
        };
    }

    // Returns a function that is used as a blur event handler
    function makeBlurHandler(elem) {
        return function () {
            showPlaceholder(elem);
        };
    }

    // Functions that are used as a event handlers when the hide-on-input behaviour has been activated - very basic implementation of the "input" event
    function makeKeydownHandler(elem) {
        return function (e) {
            keydownVal = elem.value;

            //Prevent the use of the arrow keys (try to keep the cursor before the placeholder)
            if (elem.getAttribute(ATTR_ACTIVE) === "true") {
                if (keydownVal === elem.getAttribute(ATTR_CURRENT_VAL) && Utils.inArray(badKeys, e.keyCode)) {
                    if (e.preventDefault) {
                        e.preventDefault();
                    }
                    return false;
                }
            }
        };
    }
    function makeKeyupHandler(elem) {
        return function () {
            var type;

            if (elem.getAttribute(ATTR_ACTIVE) === "true" && elem.value !== keydownVal) {

                // Remove the placeholder
                elem.className = elem.className.replace(classNameRegExp, "");
                elem.value = elem.value.replace(elem.getAttribute(ATTR_CURRENT_VAL), "");
                elem.setAttribute(ATTR_ACTIVE, false);

                // If the type of element needs to change, change it (e.g. password inputs)
                type = elem.getAttribute(ATTR_INPUT_TYPE);
                if (type) {
                    elem.type = type;
                }
            }

            // If the element is now empty we need to show the placeholder
            if (elem.value === "") {
                elem.blur();
                Utils.moveCaret(elem, 0);
            }
        };
    }
    function makeClickHandler(elem) {
        return function () {
            if (elem === document.activeElement && elem.value === elem.getAttribute(ATTR_CURRENT_VAL) && elem.getAttribute(ATTR_ACTIVE) === "true") {
                Utils.moveCaret(elem, 0);
            }
        };
    }

    // Returns a function that is used as a submit event handler on form elements that have children affected by this polyfill
    function makeSubmitHandler(form) {
        return function () {

            // Turn off placeholders on all appropriate descendant elements
            disablePlaceholders(form);
        };
    }

    // Bind event handlers to an element that we need to affect with the polyfill
    function newElement(elem) {

        // If the element is part of a form, make sure the placeholder string is not submitted as a value
        if (elem.form) {
            form = elem.form;

            // Set a flag on the form so we know it's been handled (forms can contain multiple inputs)
            if (!form.getAttribute(ATTR_FORM_HANDLED)) {
                Utils.addEventListener(form, "submit", makeSubmitHandler(form));
                form.setAttribute(ATTR_FORM_HANDLED, "true");
            }
        }

        // Bind event handlers to the element so we can hide/show the placeholder as appropriate
        Utils.addEventListener(elem, "focus", makeFocusHandler(elem));
        Utils.addEventListener(elem, "blur", makeBlurHandler(elem));

        // If the placeholder should hide on input rather than on focus we need additional event handlers
        if (hideOnInput) {
            Utils.addEventListener(elem, "keydown", makeKeydownHandler(elem));
            Utils.addEventListener(elem, "keyup", makeKeyupHandler(elem));
            Utils.addEventListener(elem, "click", makeClickHandler(elem));
        }

        // Remember that we've bound event handlers to this element
        elem.setAttribute(ATTR_EVENTS_BOUND, "true");
        elem.setAttribute(ATTR_CURRENT_VAL, placeholder);

        // If the element doesn't have a value, set it to the placeholder string
        showPlaceholder(elem);
    }

    Placeholders.nativeSupport = test.placeholder !== void 0;

    if (!Placeholders.nativeSupport) {

        // Get references to all the input and textarea elements currently in the DOM (live NodeList objects to we only need to do this once)
        inputs = document.getElementsByTagName("input");
        textareas = document.getElementsByTagName("textarea");

        // Get any settings declared as data-* attributes on the root element (currently the only options are whether to hide the placeholder on focus or input and whether to auto-update)
        hideOnInput = root.getAttribute(ATTR_OPTION_FOCUS) === "false";
        liveUpdates = root.getAttribute(ATTR_OPTION_LIVE) !== "false";

        // Create style element for placeholder styles (instead of directly setting style properties on elements - allows for better flexibility alongside user-defined styles)
        styleElem = document.createElement("style");
        styleElem.type = "text/css";

        // Create style rules as text node
        styleRules = document.createTextNode("." + placeholderClassName + " { color:" + placeholderStyleColor + "; }");

        // Append style rules to newly created stylesheet
        if (styleElem.styleSheet) {
            styleElem.styleSheet.cssText = styleRules.nodeValue;
        } else {
            styleElem.appendChild(styleRules);
        }

        // Prepend new style element to the head (before any existing stylesheets, so user-defined rules take precedence)
        head.insertBefore(styleElem, head.firstChild);

        // Set up the placeholders
        for (i = 0, len = inputs.length + textareas.length; i < len; i++) {
            elem = i < inputs.length ? inputs[i] : textareas[i - inputs.length];

            // Get the value of the placeholder attribute, if any. IE10 emulating IE7 fails with getAttribute, hence the use of the attributes node
            placeholder = elem.attributes.placeholder;
            if (placeholder) {

                // IE returns an empty object instead of undefined if the attribute is not present
                placeholder = placeholder.nodeValue;

                // Only apply the polyfill if this element is of a type that supports placeholders, and has a placeholder attribute with a non-empty value
                if (placeholder && Utils.inArray(validTypes, elem.type)) {
                    newElement(elem);
                }
            }
        }

        // If enabled, the polyfill will repeatedly check for changed/added elements and apply to those as well
        timer = setInterval(function () {
            for (i = 0, len = inputs.length + textareas.length; i < len; i++) {
                elem = i < inputs.length ? inputs[i] : textareas[i - inputs.length];

                // Only apply the polyfill if this element is of a type that supports placeholders, and has a placeholder attribute with a non-empty value
                placeholder = elem.attributes.placeholder;
                if (placeholder) {
                    placeholder = placeholder.nodeValue;
                    if (placeholder && Utils.inArray(validTypes, elem.type)) {

                        // If the element hasn't had event handlers bound to it then add them
                        if (!elem.getAttribute(ATTR_EVENTS_BOUND)) {
                            newElement(elem);
                        }

                        // If the placeholder value has changed or not been initialised yet we need to update the display
                        if (placeholder !== elem.getAttribute(ATTR_CURRENT_VAL) || (elem.type === "password" && !elem.getAttribute(ATTR_INPUT_TYPE))) {

                            // Attempt to change the type of password inputs (fails in IE < 9)
                            if (elem.type === "password" && !elem.getAttribute(ATTR_INPUT_TYPE) && Utils.changeType(elem, "text")) {
                                elem.setAttribute(ATTR_INPUT_TYPE, "password");
                            }

                            // If the placeholder value has changed and the placeholder is currently on display we need to change it
                            if (elem.value === elem.getAttribute(ATTR_CURRENT_VAL)) {
                                elem.value = placeholder;
                            }

                            // Keep a reference to the current placeholder value in case it changes via another script
                            elem.setAttribute(ATTR_CURRENT_VAL, placeholder);
                        }
                    }
                }
            }

            // If live updates are not enabled cancel the timer
            if (!liveUpdates) {
                clearInterval(timer);
            }
        }, 100);
    }

    // Expose public methods
    Placeholders.disable = Placeholders.nativeSupport ? noop : disablePlaceholders;
    Placeholders.enable = Placeholders.nativeSupport ? noop : enablePlaceholders;

}(this));
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.abide = {
    name : 'abide',

    version : '4.3.2',

    settings : {
      live_validate : true,
      focus_on_invalid : true,
      timeout : 1000,
      patterns : {
        alpha: /[a-zA-Z]+/,
        alpha_numeric : /[a-zA-Z0-9]+/,
        integer: /-?\d+/,
        number: /-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?/,

        // generic password: upper-case, lower-case, number/special character, and min 8 characters
        password : /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/,

        // amex, visa, diners
        card : /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/,
        cvv : /^([0-9]){3,4}$/,

        // http://www.whatwg.org/specs/web-apps/current-work/multipage/states-of-the-type-attribute.html#valid-e-mail-address
        email : /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,

        url: /(https?|ftp|file|ssh):\/\/(((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?/,
        // abc.de
        domain: /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$/,

        datetime: /([0-2][0-9]{3})\-([0-1][0-9])\-([0-3][0-9])T([0-5][0-9])\:([0-5][0-9])\:([0-5][0-9])(Z|([\-\+]([0-1][0-9])\:00))/,
        // YYYY-MM-DD
        date: /(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))/,
        // HH:MM:SS
        time : /(0[0-9]|1[0-9]|2[0-3])(:[0-5][0-9]){2}/,
        dateISO: /\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/,
        // MM/DD/YYYY
        month_day_year : /(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.](19|20)\d\d/,

        // #FFF or #FFFFFF
        color: /^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/
      }
    },

    timer : null,

    init : function (scope, method, options) {
      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      if (typeof method !== 'string') {
        if (!this.settings.init) { this.events(); }

      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this,
          forms = $('form[data-abide]', this.scope).attr('novalidate', 'novalidate');

      forms
        .on('submit validate', function (e) {
          return self.validate($(this).find('input, textarea, select').get(), e);
        });

      this.settings.init = true;

      if (!this.settings.live_validate) return;

      forms
        .find('input, textarea, select')
        .on('blur change', function (e) {
          self.validate([this], e);
        })
        .on('keydown', function (e) {
          clearTimeout(self.timer);
          self.timer = setTimeout(function () {
            self.validate([this], e);
          }.bind(this), self.settings.timeout);
        });
    },

    validate : function (els, e) {
      var validations = this.parse_patterns(els),
          validation_count = validations.length,
          form = $(els[0]).closest('form');

      for (var i=0; i < validation_count; i++) {
        if (!validations[i] && /submit/.test(e.type)) {
          if (this.settings.focus_on_invalid) els[i].focus();
          form.trigger('invalid');
          $(els[i]).closest('form').attr('data-invalid', '');
          return false;
        }
      }

      if (/submit/.test(e.type)) {
        form.trigger('valid');
      }

      form.removeAttr('data-invalid');

      return true;
    },

    parse_patterns : function (els) {
      var count = els.length,
          el_patterns = [];

      for (var i = count - 1; i >= 0; i--) {
        el_patterns.push(this.pattern(els[i]));
      }

      return this.check_validation_and_apply_styles(el_patterns);
    },

    pattern : function (el) {
      var type = el.getAttribute('type'),
          required = typeof el.getAttribute('required') === 'string';

      if (this.settings.patterns.hasOwnProperty(type)) {
        return [el, this.settings.patterns[type], required];
      }

      var pattern = el.getAttribute('pattern') || '';

      if (this.settings.patterns.hasOwnProperty(pattern) && pattern.length > 0) {
        return [el, this.settings.patterns[pattern], required];
      } else if (pattern.length > 0) {
        return [el, new RegExp(pattern), required];
      }

      pattern = /.*/;

      return [el, pattern, required];
    },

    check_validation_and_apply_styles : function (el_patterns) {
      var count = el_patterns.length,
          validations = [];

      for (var i = count - 1; i >= 0; i--) {
        var el = el_patterns[i][0],
            required = el_patterns[i][2],
            value = el.value,
            is_radio = el.type === "radio",
            valid_length = (required) ? (el.value.length > 0) : true;

        if (is_radio && required) {
          validations.push(this.valid_radio(el, required));
        } else {
          if (el_patterns[i][1].test(value) && valid_length ||
            !required && el.value.length < 1) {
            $(el).removeAttr('data-invalid').parent().removeClass('error');
            validations.push(true);
          } else {
            $(el).attr('data-invalid', '').parent().addClass('error');
            validations.push(false);
          }
        }
      }

      return validations;
    },

    valid_radio : function (el, required) {
      var name = el.getAttribute('name'),
          group = document.getElementsByName(name),
          count = group.length,
          valid = false;

      for (var i=0; i < count; i++) {
        if (group[i].checked) valid = true;
      }

      for (var i=0; i < count; i++) {
        if (valid) {
          $(group[i]).removeAttr('data-invalid').parent().removeClass('error');
        } else {
          $(group[i]).attr('data-invalid', '').parent().addClass('error');
        }
      }

      return valid;
    }
  };
}(Foundation.zj, this, this.document));
/*
















*/
;
/*jslint unparam: true, browser: true, indent: 2 */


;(function ($, window, document, undefined) {
  'use strict';

  Foundation.libs.interchange = {
    name : 'interchange',

    version : '4.2.1',

    cache : {},

    settings : {
      load_attr : 'interchange',

      named_queries : {
        'default' : 'only screen and (min-width: 1px)',
        small : 'only screen and (min-width: 768px)',
        medium : 'only screen and (min-width: 1280px)',
        large : 'only screen and (min-width: 1440px)',
        landscape : 'only screen and (orientation: landscape)',
        portrait : 'only screen and (orientation: portrait)',
        retina : 'only screen and (-webkit-min-device-pixel-ratio: 2),'
          + 'only screen and (min--moz-device-pixel-ratio: 2),'
          + 'only screen and (-o-min-device-pixel-ratio: 2/1),'
          + 'only screen and (min-device-pixel-ratio: 2),'
          + 'only screen and (min-resolution: 192dpi),'
          + 'only screen and (min-resolution: 2dppx)'
      },

      directives : {
        replace : function (el, path) {
          if (/IMG/.test(el[0].nodeName)) {
            var path_parts = path.split('/'),
                path_file = path_parts[path_parts.length - 1],
                orig_path = el[0].src;

            if (new RegExp(path_file, 'i').test(el[0].src)) return;

            el[0].src = path;

            return el.trigger('replace', [el[0].src, orig_path]);
          }
        }
      }
    },

    init : function (scope, method, options) {
      Foundation.inherit(this, 'throttle');

      if (typeof method === 'object') {
        $.extend(true, this.settings, method);
      }

      this.events();
      this.images();

      if (typeof method != 'string') {
        return this.settings.init;
      } else {
        return this[method].call(this, options);
      }
    },

    events : function () {
      var self = this;

      $(window).on('resize.fndtn.interchange', self.throttle(function () {
        self.resize.call(self);
      }, 50));
    },

    resize : function () {
      var cache = this.cache;

      for (var uuid in cache) {
        if (cache.hasOwnProperty(uuid)) {
          var passed = this.results(uuid, cache[uuid]);

          if (passed) {
            this.settings.directives[passed
              .scenario[1]](passed.el, passed.scenario[0]);
          }
        }
      }

    },

    results : function (uuid, scenarios) {
      var count = scenarios.length,
          results_arr = [];

      if (count > 0) {
        var el = $('[data-uuid="' + uuid + '"]');

        for (var i = count - 1; i >= 0; i--) {
          var rule = scenarios[i][2];
          if (this.settings.named_queries.hasOwnProperty(rule)) {
            var mq = matchMedia(this.settings.named_queries[rule]);
          } else {
            var mq = matchMedia(scenarios[i][2]);
          }
          if (mq.matches) {
            return {el: el, scenario: scenarios[i]};
          }
        }
      }

      return false;
    },

    images : function (force_update) {
      if (typeof this.cached_images === 'undefined' || force_update) {
        return this.update_images();
      }

      return this.cached_images;
    },

    update_images : function () {
      var images = document.getElementsByTagName('img'),
          count = images.length,
          data_attr = 'data-' + this.settings.load_attr;

      this.cached_images = [];

      for (var i = count - 1; i >= 0; i--) {
        this.loaded($(images[i]), (i === 0), function (image, last) {
          if (image) {
            var str = image.getAttribute(data_attr) || '';

            if (str.length > 0) {
              this.cached_images.push(image);
            }
          }

          if (last) this.enhance();

        }.bind(this));
      }

      return 'deferred';
    },

    // based on jquery.imageready.js
    // @weblinc, @jsantell, (c) 2012

    loaded : function (image, last, callback) {
      function loaded () {
        callback(image[0], last);
      }

      function bindLoad () {
        this.one('load', loaded);

        if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
          var src = this.attr( 'src' ),
              param = src.match( /\?/ ) ? '&' : '?';

          param += 'random=' + (new Date()).getTime();
          this.attr('src', src + param);
        }
      }

      if (!image.attr('src')) {
        loaded();
        return;
      }

      if (image[0].complete || image[0].readyState === 4) {
        loaded();
      } else {
        bindLoad.call(image);
      }
    },

    enhance : function () {
      var count = this.images().length;

      for (var i = count - 1; i >= 0; i--) {
        this._object($(this.images()[i]));
      }

      return $(window).trigger('resize');
    },

    parse_params : function (path, directive, mq) {
      return [this.trim(path), this.convert_directive(directive), this.trim(mq)];
    },

    convert_directive : function (directive) {
      var trimmed = this.trim(directive);

      if (trimmed.length > 0) {
        return trimmed;
      }

      return 'replace';
    },

    _object : function(el) {
      var raw_arr = this.parse_data_attr(el),
          scenarios = [], count = raw_arr.length;

      if (count > 0) {
        for (var i = count - 1; i >= 0; i--) {
          var split = raw_arr[i].split(/\((.*?)(\))$/);

          if (split.length > 1) {
            var cached_split = split[0].split(','),
                params = this.parse_params(cached_split[0],
                  cached_split[1], split[1]);

            scenarios.push(params);
          }
        }
      }

      return this.store(el, scenarios);
    },

    uuid : function (separator) {
      var delim = separator || "-";

      function S4() {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
      }

      return (S4() + S4() + delim + S4() + delim + S4()
        + delim + S4() + delim + S4() + S4() + S4());
    },

    store : function (el, scenarios) {
      var uuid = this.uuid(),
          current_uuid = el.data('uuid');

      if (current_uuid) return this.cache[current_uuid];

      el.attr('data-uuid', uuid);

      return this.cache[uuid] = scenarios;
    },

    trim : function(str) {
      if (typeof str === 'string') {
        return $.trim(str);
      }

      return str;
    },

    parse_data_attr : function (el) {
      var raw = el.data(this.settings.load_attr).split(/\[(.*?)\]/),
          count = raw.length, output = [];

      for (var i = count - 1; i >= 0; i--) {
        if (raw[i].replace(/[\W\d]+/, '').length > 4) {
          output.push(raw[i]);
        }
      }

      return output;
    },

    reflow : function () {
      this.images(true);
    }

  };

}(Foundation.zj, this, this.document));
String.prototype.rightChars = function(n){
  if (n <= 0) {
    return "";
  }
  else if (n > this.length) {
    return this;
  }
  else {
    return this.substring(this.length, this.length - n);
  }
};

(function($) {
  var
    options = {
      highlightSpeed    : 20,
      typeSpeed         : 100,
      clearDelay        : 500,
      typeDelay         : 200,
      clearOnHighlight  : true,
      typerDataAttr     : 'data-typer-targets',
      typerInterval     : 2000
    },
    highlight,
    clearText,
    backspace,
    type,
    spanWithColor,
    clearDelay,
    typeDelay,
    clearData,
    isNumber,
    typeWithAttribute,
    getHighlightInterval,
    getTypeInterval,
    typerInterval;

  spanWithColor = function(color, backgroundColor) {
    if (color === 'rgba(0, 0, 0, 0)') {
      color = 'rgb(255, 255, 255)';
    }

    return $('<span></span>')
      .css('color', color)
      .css('background-color', backgroundColor);
  };

  isNumber = function (n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  };

  clearData = function ($e) {
    $e.removeData([
      'typePosition',
      'highlightPosition',
      'leftStop',
      'rightStop',
      'primaryColor',
      'backgroundColor',
      'text',
      'typing'
    ]);
  };

  type = function ($e) {
    var
      // position = $e.data('typePosition'),
      text = $e.data('text'),
      oldLeft = $e.data('oldLeft'),
      oldRight = $e.data('oldRight');

    // if (!isNumber(position)) {
      // position = $e.data('leftStop');
    // }

    if (!text || text.length === 0) {
      clearData($e);
      return;
    }


    $e.text(
      oldLeft +
      text.charAt(0) +
      oldRight
    ).data({
      oldLeft: oldLeft + text.charAt(0),
      text: text.substring(1)
    });

    // $e.text($e.text() + text.substring(position, position + 1));

    // $e.data('typePosition', position + 1);

    setTimeout(function () {
      type($e);
    }, getTypeInterval());
  };

  clearText = function ($e) {
    $e.find('span').remove();

    setTimeout(function () {
      type($e);
    }, typeDelay());
  };

  highlight = function ($e) {
    var
      position = $e.data('highlightPosition'),
      leftText,
      highlightedText,
      rightText;

    if (!isNumber(position)) {
      position = $e.data('rightStop') + 1;
    }

    if (position <= $e.data('leftStop')) {
      setTimeout(function () {
        clearText($e);
      }, clearDelay());
      return;
    }

    leftText = $e.text().substring(0, position - 1);
    highlightedText = $e.text().substring(position - 1, $e.data('rightStop') + 1);
    rightText = $e.text().substring($e.data('rightStop') + 1);

    $e.html(leftText)
      .append(
        spanWithColor(
            $e.data('backgroundColor'),
            $e.data('primaryColor')
          )
          .append(highlightedText)
      )
      .append(rightText);

    $e.data('highlightPosition', position - 1);

    setTimeout(function () {
      return highlight($e);
    }, getHighlightInterval());
  };

  typeWithAttribute = function ($e) {
    var targets;

    if ($e.data('typing')) {
      return;
    }

    try {
      targets = JSON.parse($e.attr($.typer.options.typerDataAttr)).targets;
    } catch (e) {}

    if (typeof targets === "undefined") {
      targets = $.map($e.attr($.typer.options.typerDataAttr).split(','), function (e) {
        return $.trim(e);
      });
    }

    $e.typeTo(targets[Math.floor(Math.random()*targets.length)]);
  };

  // Expose our options to the world.
  $.typer = (function () {
    return { options: options };
  })();

  $.extend($.typer, {
    options: options
  });

  //-- Methods to attach to jQuery sets

  $.fn.typer = function() {
    var $elements = $(this);

    return $elements.each(function () {
      var $e = $(this);

      if (typeof $e.attr($.typer.options.typerDataAttr) === "undefined") {
        return;
      }

      typeWithAttribute($e);
      setInterval(function () {
        typeWithAttribute($e);
      }, typerInterval());
    });
  };

  $.fn.typeTo = function (newString) {
    var
      $e = $(this),
      currentText = $e.text(),
      i = 0,
      j = 0;

    if (currentText === newString) {
      console.log("Our strings our equal, nothing to type");
      return $e;
    }

    if (currentText !== $e.html()) {
      console.error("Typer does not work on elements with child elements.");
      return $e;
    }

    $e.data('typing', true);

    while (currentText.charAt(i) === newString.charAt(i)) {
      i++;
    }

    while (currentText.rightChars(j) === newString.rightChars(j)) {
      j++;
    }

    newString = newString.substring(i, newString.length - j + 1);

    $e.data({
      oldLeft: currentText.substring(0, i),
      oldRight: currentText.rightChars(j - 1),
      leftStop: i,
      rightStop: currentText.length - j,
      primaryColor: $e.css('color'),
      backgroundColor: $e.css('background-color'),
      text: newString
    });

    highlight($e);

    return $e;
  };

  //-- Helper methods. These can one day be customized further to include things like ranges of delays.

  getHighlightInterval = function () {
    return $.typer.options.highlightSpeed;
  };

  getTypeInterval = function () {
    return $.typer.options.typeSpeed;
  },

  clearDelay = function () {
    return $.typer.options.clearDelay;
  },

  typeDelay = function () {
    return $.typer.options.typeDelay;
  };

  typerInterval = function () {
    return $.typer.options.typerInterval;
  };
})(jQuery);
(function() {
  $(document).ready(function() {
    return $('h1[data-typer-targets]', '.pages.show .headliner').typer() != null;
  });

  /*! Until I figure it out later this year*/


  $(document).ready(function() {
    return $('h1[data-typer-targets]', '.pages.show .headliner').typer() != null;
  });

}).call(this);
(function() {
  $(function() {
    var $bar_chart_height, $innerRadius, $outerRadius, $pie_chart_height, $width, arc, arcs, color, dataset, individual_keys, key, legend_keys, legend_keys_container, pie, svg;
    $pie_chart_height = 250;
    $bar_chart_height = 400;
    $width = 250;
    console.log("Width is " + $width);
    $outerRadius = $width / 2;
    $innerRadius = $width / 3.14;
    dataset = [
      {
        id: 1,
        name: "Money",
        percentage: 5
      }, {
        id: 2,
        name: "Working on new projects throughout the calendar year",
        percentage: 40
      }, {
        id: 4,
        name: "Opportunities to learn new skills",
        percentage: 15
      }, {
        id: 5,
        name: "Opportunities to justify work with clients directly",
        percentage: 10
      }, {
        id: 6,
        name: "Cross-functional teamwork between developers and designers",
        percentage: 20
      }, {
        id: 7,
        name: "A workflow that emphasizes mobile-first development",
        percentage: 10
      }
    ];
    console.log("The data set is " + dataset);
    svg = d3.select(".personal_influencers .data", ".pages").append("svg");
    svg.attr({
      "class": 'pie_chart',
      width: $width,
      height: $pie_chart_height
    });
    color = d3.scale.category20();
    pie = d3.layout.pie().value(function(d) {
      return d.percentage;
    });
    console.log(dataset);
    key = function(d) {
      return d.id;
    };
    arc = d3.svg.arc().innerRadius($innerRadius).outerRadius($outerRadius);
    arcs = svg.selectAll("g.arc").data(pie(dataset, key)).enter().append("g").attr({
      "class": "arc",
      transform: "translate(" + $outerRadius + ", " + $outerRadius + ")"
    });
    arcs.append("path").attr({
      fill: function(d, i) {
        return color(i);
      },
      d: arc
    });
    legend_keys_container = d3.select('.personal_influencers .legend .keys');
    legend_keys = legend_keys_container.selectAll("div.key").data(dataset, key).enter().append('div').attr({
      "class": 'key'
    }).append('div').attr({
      "class": 'colorblock',
      style: function(d, i) {
        return "background-color: " + (color(i));
      }
    });
    individual_keys = d3.selectAll('.key');
    individual_keys.append('span').text(function(d) {
      return "" + d.name + " (" + d.percentage + "%)";
    });
    return $('.legend').fadeIn('400');
  });

}).call(this);
(function() {


}).call(this);
